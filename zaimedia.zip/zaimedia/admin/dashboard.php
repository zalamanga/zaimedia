<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireRole('admin');

$user = getCurrentUser();
$conn = getDBConnection();

// Get statistics
$stats = [];

// Total Books
$stmt = $conn->query("SELECT COUNT(*) FROM books");
$stats['total_books'] = $stmt->fetchColumn();

$stmt = $conn->query("SELECT COUNT(*) FROM books WHERE status = 'pending'");
$stats['pending_books'] = $stmt->fetchColumn();

$stmt = $conn->query("SELECT COUNT(*) FROM books WHERE status = 'approved'");
$stats['approved_books'] = $stmt->fetchColumn();

// Total Users
$stmt = $conn->query("SELECT COUNT(*) FROM users");
$stats['total_users'] = $stmt->fetchColumn();

$stmt = $conn->query("SELECT COUNT(*) FROM users WHERE role = 'writer'");
$stats['total_writers'] = $stmt->fetchColumn();

$stmt = $conn->query("SELECT COUNT(*) FROM users WHERE role = 'customer'");
$stats['total_customers'] = $stmt->fetchColumn();

// Total Orders
$stmt = $conn->query("SELECT COUNT(*) FROM orders");
$stats['total_orders'] = $stmt->fetchColumn();

$stmt = $conn->query("SELECT COUNT(*) FROM orders WHERE payment_status = 'paid'");
$stats['paid_orders'] = $stmt->fetchColumn();

$stmt = $conn->query("SELECT SUM(total) FROM orders WHERE payment_status = 'paid'");
$stats['total_revenue'] = $stmt->fetchColumn() ?? 0;

// Withdrawals
$stmt = $conn->query("SELECT COUNT(*) FROM withdrawals WHERE status = 'pending'");
$stats['pending_withdrawals'] = $stmt->fetchColumn();

// Recent activities
$stmt = $conn->query("
    SELECT b.*, u.full_name, u.username 
    FROM books b
    JOIN users u ON b.writer_id = u.id
    WHERE b.status = 'pending'
    ORDER BY b.created_at DESC
    LIMIT 5
");
$recentBooks = $stmt->fetchAll();

$stmt = $conn->query("
    SELECT o.*, u.full_name 
    FROM orders o
    JOIN users u ON o.customer_id = u.id
    ORDER BY o.created_at DESC
    LIMIT 5
");
$recentOrders = $stmt->fetchAll();

// Monthly revenue chart (last 6 months)
$stmt = $conn->query("
    SELECT 
        DATE_FORMAT(created_at, '%Y-%m') as month,
        SUM(total) as revenue,
        COUNT(*) as order_count
    FROM orders
    WHERE payment_status = 'paid' 
    AND created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
    GROUP BY DATE_FORMAT(created_at, '%Y-%m')
    ORDER BY month ASC
");
$monthlyRevenue = $stmt->fetchAll();

// Top selling books
$stmt = $conn->query("
    SELECT 
        b.title,
        SUM(oi.quantity) as total_sold,
        SUM(oi.subtotal) as total_revenue
    FROM order_items oi
    JOIN books b ON oi.book_id = b.id
    JOIN orders o ON oi.order_id = o.id
    WHERE o.payment_status = 'paid'
    GROUP BY b.id
    ORDER BY total_sold DESC
    LIMIT 5
");
$topBooks = $stmt->fetchAll();

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: white;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            position: fixed;
            width: 250px;
        }
        .sidebar-header {
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .menu-item {
            padding: 12px 20px;
            color: #333;
            text-decoration: none;
            display: block;
            transition: all 0.3s;
        }
        .menu-item:hover,
        .menu-item.active {
            background: #f8f9fa;
            color: #667eea;
            border-left: 3px solid #667eea;
        }
        .content-area {
            margin-left: 250px;
            padding: 30px;
        }
        .stats-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .stats-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 30px rgba(0,0,0,0.15);
        }
        .stats-icon {
            width: 60px;
            height: 60px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
        }
        .chart-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .activity-item {
            padding: 15px;
            border-bottom: 1px solid #eee;
            transition: background 0.3s;
        }
        .activity-item:hover {
            background: #f8f9fa;
        }
        .activity-item:last-child {
            border-bottom: none;
        }
        .welcome-banner {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0">Admin</h4>
            <small>Administrator</small>
        </div>
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item active">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a href="books-manage.php" class="menu-item">
                <i class="bi bi-book me-2"></i> Books
            </a>
            <a href="users-manage.php" class="menu-item">
                <i class="bi bi-people me-2"></i> Users
            </a>
            <a href="withdrawals-manage.php" class="menu-item">
                <i class="bi bi-cash-stack me-2"></i> Withdrawals
            </a>
            <a href="orders-manage.php" class="menu-item">
                <i class="bi bi-cart me-2"></i> Orders
            </a>
            <a href="categories-manage.php" class="menu-item">
                <i class="bi bi-tags me-2"></i> Categories
            </a>
        </div>
        <div style="position: absolute; bottom: 20px; width: 100%;">
            <a href="../index.php" class="menu-item">
                <i class="bi bi-house me-2"></i> Homepage
            </a>
            <a href="../logout.php" class="menu-item">
                <i class="bi bi-box-arrow-left me-2"></i> LogOut
            </a>
        </div>
    </div>

    <!-- Content Area -->
    <div class="content-area">
        <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
            <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Welcome Banner -->
        <div class="welcome-banner">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h2 class="mb-2">Welcome back, Admin! 👋</h2>
                    <p class="mb-0 opacity-75">Here's what's happening with ZaiMedia today.</p>
                </div>
                <div class="col-md-4 text-end">
                    <h5><?= date('l, d F Y') ?></h5>
                    <p class="mb-0" id="currentTime"></p>
                </div>
            </div>
        </div>

        <!-- Stats Row 1 -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="d-flex align-items-center">
                        <div class="stats-icon bg-primary bg-opacity-10 text-primary me-3">
                            <i class="bi bi-book"></i>
                        </div>
                        <div>
                            <h6 class="text-muted mb-0">Total Books</h6>
                            <h3 class="mb-0"><?= $stats['total_books'] ?></h3>
                            <small class="text-muted"><?= $stats['pending_books'] ?> pending</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="d-flex align-items-center">
                        <div class="stats-icon bg-success bg-opacity-10 text-success me-3">
                            <i class="bi bi-people"></i>
                        </div>
                        <div>
                            <h6 class="text-muted mb-0">Total Users</h6>
                            <h3 class="mb-0"><?= $stats['total_users'] ?></h3>
                            <small class="text-muted"><?= $stats['total_writers'] ?> writers, <?= $stats['total_customers'] ?> customers</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="d-flex align-items-center">
                        <div class="stats-icon bg-info bg-opacity-10 text-info me-3">
                            <i class="bi bi-cart"></i>
                        </div>
                        <div>
                            <h6 class="text-muted mb-0">Total Orders</h6>
                            <h3 class="mb-0"><?= $stats['total_orders'] ?></h3>
                            <small class="text-muted"><?= $stats['paid_orders'] ?> paid</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="d-flex align-items-center">
                        <div class="stats-icon bg-warning bg-opacity-10 text-warning me-3">
                            <i class="bi bi-cash-stack"></i>
                        </div>
                        <div>
                            <h6 class="text-muted mb-0">Total Revenue</h6>
                            <h3 class="mb-0 text-success"><?= formatRupiah($stats['total_revenue']) ?></h3>
                            <small class="text-muted">All time</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Alerts -->
        <div class="row mb-4">
            <?php if ($stats['pending_books'] > 0): ?>
            <div class="col-md-6">
                <div class="alert alert-warning d-flex align-items-center">
                    <i class="bi bi-exclamation-triangle fs-3 me-3"></i>
                    <div>
                        <strong><?= $stats['pending_books'] ?> books</strong> waiting for review
                        <a href="books-manage.php?status=pending" class="alert-link ms-2">Review now →</a>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($stats['pending_withdrawals'] > 0): ?>
            <div class="col-md-6">
                <div class="alert alert-info d-flex align-items-center">
                    <i class="bi bi-wallet2 fs-3 me-3"></i>
                    <div>
                        <strong><?= $stats['pending_withdrawals'] ?> withdrawal requests</strong> pending
                        <a href="withdrawals-manage.php?status=pending" class="alert-link ms-2">Process now →</a>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <div class="row">
            <!-- Revenue Chart -->
            <div class="col-md-8">
                <div class="chart-card">
                    <h5 class="mb-4">
                        <i class="bi bi-graph-up me-2"></i>Revenue Overview (Last 6 Months)
                    </h5>
                    <canvas id="revenueChart" height="100"></canvas>
                </div>

                <!-- Recent Orders -->
                <div class="chart-card">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="mb-0">
                            <i class="bi bi-cart me-2"></i>Recent Orders
                        </h5>
                        <a href="orders-manage.php" class="btn btn-sm btn-outline-primary">View All</a>
                    </div>
                    
                    <?php if (empty($recentOrders)): ?>
                        <div class="alert alert-info">No orders yet</div>
                    <?php else: ?>
                        <?php foreach ($recentOrders as $order): ?>
                        <div class="activity-item">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <strong><?= htmlspecialchars($order['order_number']) ?></strong>
                                    <br>
                                    <small class="text-muted">
                                        <i class="bi bi-person me-1"></i>
                                        <?= htmlspecialchars($order['full_name']) ?>
                                    </small>
                                </div>
                                <div class="text-end">
                                    <strong class="text-primary"><?= formatRupiah($order['total']) ?></strong>
                                    <br>
                                    <small class="text-muted"><?= timeAgo($order['created_at']) ?></small>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <div class="col-md-4">
                <!-- Top Selling Books -->
                <div class="chart-card">
                    <h5 class="mb-4">
                        <i class="bi bi-trophy me-2"></i>Top Selling Books
                    </h5>
                    
                    <?php if (empty($topBooks)): ?>
                        <div class="alert alert-info">No sales yet</div>
                    <?php else: ?>
                        <div class="list-group list-group-flush">
                            <?php foreach ($topBooks as $index => $book): ?>
                            <div class="list-group-item px-0">
                                <div class="d-flex align-items-center">
                                    <div class="me-3">
                                        <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center" 
                                             style="width: 35px; height: 35px;">
                                            <strong>#<?= $index + 1 ?></strong>
                                        </div>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h6 class="mb-0"><?= htmlspecialchars(truncateText($book['title'], 30)) ?></h6>
                                        <small class="text-muted"><?= $book['total_sold'] ?> sold</small>
                                    </div>
                                    <div class="text-end">
                                        <small class="text-success"><?= formatRupiah($book['total_revenue']) ?></small>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Pending Books -->
                <div class="chart-card">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="mb-0">
                            <i class="bi bi-clock-history me-2"></i>Pending Books
                        </h5>
                        <a href="books-manage.php?status=pending" class="btn btn-sm btn-outline-primary">View All</a>
                    </div>
                    
                    <?php if (empty($recentBooks)): ?>
                        <div class="alert alert-info">No pending books</div>
                    <?php else: ?>
                        <?php foreach ($recentBooks as $book): ?>
                        <div class="activity-item">
                            <h6 class="mb-1"><?= htmlspecialchars(truncateText($book['title'], 40)) ?></h6>
                            <small class="text-muted">
                                <i class="bi bi-person me-1"></i>
                                <?= htmlspecialchars($book['full_name']) ?>
                            </small>
                            <br>
                            <small class="text-muted">
                                <i class="bi bi-clock me-1"></i>
                                <?= timeAgo($book['created_at']) ?>
                            </small>
                            <div class="mt-2">
                                <a href="book-review.php?id=<?= $book['id'] ?>" class="btn btn-sm btn-primary">
                                    <i class="bi bi-eye me-1"></i> Review
                                </a>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Update clock
        function updateTime() {
            const now = new Date();
            const timeString = now.toLocaleTimeString('id-ID');
            document.getElementById('currentTime').textContent = timeString;
        }
        setInterval(updateTime, 1000);
        updateTime();

        // Revenue Chart
        const ctx = document.getElementById('revenueChart').getContext('2d');
        const revenueChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [
                    <?php foreach ($monthlyRevenue as $mr): ?>
                        '<?= date('M Y', strtotime($mr['month'] . '-01')) ?>',
                    <?php endforeach; ?>
                ],
                datasets: [{
                    label: 'Revenue',
                    data: [
                        <?php foreach ($monthlyRevenue as $mr): ?>
                            <?= $mr['revenue'] ?>,
                        <?php endforeach; ?>
                    ],
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return 'Rp ' + context.parsed.y.toLocaleString('id-ID');
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'Rp ' + (value/1000) + 'k';
                            }
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>