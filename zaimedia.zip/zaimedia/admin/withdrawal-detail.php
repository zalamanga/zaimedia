<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireRole('admin');

$user = getCurrentUser();
$conn = getDBConnection();
$withdrawalId = $_GET['id'] ?? 0;

// Get withdrawal details
$stmt = $conn->prepare("
    SELECT w.*, u.full_name, u.email, u.username, u.phone,
           wb.available_balance, wb.pending_balance, wb.total_withdrawn
    FROM withdrawals w
    JOIN users u ON w.writer_id = u.id
    LEFT JOIN writer_balance wb ON w.writer_id = wb.writer_id
    WHERE w.id = ?
");
$stmt->execute([$withdrawalId]);
$withdrawal = $stmt->fetch();

if (!$withdrawal) {
    setFlash('error', 'Withdrawal request not found');
    redirect('withdrawals-manage.php');
}

// Get writer's other withdrawals
$stmt = $conn->prepare("
    SELECT * FROM withdrawals 
    WHERE writer_id = ? AND id != ?
    ORDER BY created_at DESC
    LIMIT 5
");
$stmt->execute([$withdrawal['writer_id'], $withdrawalId]);
$otherWithdrawals = $stmt->fetchAll();

// Get writer's books
$stmt = $conn->prepare("
    SELECT COUNT(*) as total_books,
           SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved_books
    FROM books
    WHERE writer_id = ?
");
$stmt->execute([$withdrawal['writer_id']]);
$writerBooks = $stmt->fetch();

// Get writer's total sales
$stmt = $conn->prepare("
    SELECT COUNT(*) as total_sales,
           SUM(royalty_amount) as total_royalty
    FROM sales
    WHERE writer_id = ?
");
$stmt->execute([$withdrawal['writer_id']]);
$writerSales = $stmt->fetch();

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Withdrawal Detail - Admin ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: white;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            position: fixed;
            width: 250px;
        }
        .sidebar-header {
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .content-area {
            margin-left: 250px;
            padding: 30px;
        }
        .info-card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .status-badge {
            font-size: 1.1rem;
            padding: 10px 20px;
        }
        .info-row {
            padding: 15px 0;
            border-bottom: 1px solid #eee;
        }
        .info-row:last-child {
            border-bottom: none;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0">Admin Panel</h4>
            <small><?= htmlspecialchars($user['full_name']) ?></small>
        </div>
        <div class="p-3">
            <a href="dashboard.php" class="btn btn-outline-primary w-100 mb-2">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a href="books-manage.php" class="btn btn-outline-primary w-100 mb-2">
                <i class="bi bi-book me-2"></i> Books
            </a>
            <a href="users-manage.php" class="btn btn-outline-primary w-100 mb-2">
                <i class="bi bi-people me-2"></i> Users
            </a>
            <a href="withdrawals-manage.php" class="btn btn-primary w-100 mb-2">
                <i class="bi bi-cash-stack me-2"></i> Withdrawals
            </a>
            <a href="../index.php" class="btn btn-outline-secondary w-100 mb-2">
                <i class="bi bi-house me-2"></i> Homepage
            </a>
            <a href="../logout.php" class="btn btn-outline-danger w-100">
                <i class="bi bi-box-arrow-left me-2"></i> Logout
            </a>
        </div>
    </div>

    <!-- Content -->
    <div class="content-area">
        <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
            <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Withdrawal Detail #<?= $withdrawal['id'] ?></h2>
            <a href="withdrawals-manage.php" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left me-2"></i> Back
            </a>
        </div>

        <div class="row">
            <div class="col-md-8">
                <!-- Withdrawal Info -->
                <div class="info-card">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5>Withdrawal Information</h5>
                        <?php
                        $badgeClass = [
                            'pending' => 'warning',
                            'approved' => 'info',
                            'completed' => 'success',
                            'rejected' => 'danger'
                        ];
                        ?>
                        <span class="badge bg-<?= $badgeClass[$withdrawal['status']] ?> status-badge">
                            <?= ucfirst($withdrawal['status']) ?>
                        </span>
                    </div>

                    <div class="info-row">
                        <div class="row">
                            <div class="col-md-4"><strong>Withdrawal Code:</strong></div>
                            <div class="col-md-8"><?= htmlspecialchars($withdrawal['withdrawal_code']) ?></div>
                        </div>
                    </div>

                    <div class="info-row">
                        <div class="row">
                            <div class="col-md-4"><strong>Amount:</strong></div>
                            <div class="col-md-8">
                                <h4 class="text-primary mb-0"><?= formatRupiah($withdrawal['amount']) ?></h4>
                            </div>
                        </div>
                    </div>

                    <div class="info-row">
                        <div class="row">
                            <div class="col-md-4"><strong>Bank Name:</strong></div>
                            <div class="col-md-8"><?= htmlspecialchars($withdrawal['bank_name']) ?></div>
                        </div>
                    </div>

                    <div class="info-row">
                        <div class="row">
                            <div class="col-md-4"><strong>Account Number:</strong></div>
                            <div class="col-md-8"><?= htmlspecialchars($withdrawal['account_number']) ?></div>
                        </div>
                    </div>

                    <div class="info-row">
                        <div class="row">
                            <div class="col-md-4"><strong>Account Name:</strong></div>
                            <div class="col-md-8"><?= htmlspecialchars($withdrawal['account_name']) ?></div>
                        </div>
                    </div>

                    <div class="info-row">
                        <div class="row">
                            <div class="col-md-4"><strong>Requested At:</strong></div>
                            <div class="col-md-8"><?= formatDateTimeIndo($withdrawal['created_at']) ?></div>
                        </div>
                    </div>

                    <?php if ($withdrawal['processed_at']): ?>
                    <div class="info-row">
                        <div class="row">
                            <div class="col-md-4"><strong>Processed At:</strong></div>
                            <div class="col-md-8"><?= formatDateTimeIndo($withdrawal['processed_at']) ?></div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if ($withdrawal['notes']): ?>
                    <div class="info-row">
                        <div class="row">
                            <div class="col-md-4"><strong>Notes:</strong></div>
                            <div class="col-md-8"><?= nl2br(htmlspecialchars($withdrawal['notes'])) ?></div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if ($withdrawal['rejection_reason']): ?>
                    <div class="info-row">
                        <div class="row">
                            <div class="col-md-4"><strong>Rejection Reason:</strong></div>
                            <div class="col-md-8">
                                <div class="alert alert-danger mb-0">
                                    <?= nl2br(htmlspecialchars($withdrawal['rejection_reason'])) ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- Actions -->
                    <?php if ($withdrawal['status'] === 'pending'): ?>
                    <div class="mt-4">
                        <form method="POST" action="withdrawal-process.php" class="d-inline">
                            <input type="hidden" name="withdrawal_id" value="<?= $withdrawal['id'] ?>">
                            <input type="hidden" name="action" value="approve">
                            <button type="submit" class="btn btn-success" 
                                    onclick="return confirm('Approve this withdrawal request?')">
                                <i class="bi bi-check-circle me-2"></i> Approve Withdrawal
                            </button>
                        </form>
                        <button type="button" class="btn btn-danger" 
                                data-bs-toggle="modal" data-bs-target="#rejectModal">
                            <i class="bi bi-x-circle me-2"></i> Reject Withdrawal
                        </button>
                    </div>
                    <?php elseif ($withdrawal['status'] === 'approved'): ?>
                    <div class="mt-4">
                        <form method="POST" action="withdrawal-process.php" class="d-inline">
                            <input type="hidden" name="withdrawal_id" value="<?= $withdrawal['id'] ?>">
                            <input type="hidden" name="action" value="complete">
                            <button type="submit" class="btn btn-info" 
                                    onclick="return confirm('Mark this withdrawal as completed?')">
                                <i class="bi bi-check2-circle me-2"></i> Mark as Completed
                            </button>
                        </form>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Writer Info -->
                <div class="info-card">
                    <h5 class="mb-4">Writer Information</h5>
                    
                    <div class="info-row">
                        <div class="row">
                            <div class="col-md-4"><strong>Full Name:</strong></div>
                            <div class="col-md-8"><?= htmlspecialchars($withdrawal['full_name']) ?></div>
                        </div>
                    </div>

                    <div class="info-row">
                        <div class="row">
                            <div class="col-md-4"><strong>Username:</strong></div>
                            <div class="col-md-8">@<?= htmlspecialchars($withdrawal['username']) ?></div>
                        </div>
                    </div>

                    <div class="info-row">
                        <div class="row">
                            <div class="col-md-4"><strong>Email:</strong></div>
                            <div class="col-md-8"><?= htmlspecialchars($withdrawal['email']) ?></div>
                        </div>
                    </div>

                    <?php if ($withdrawal['phone']): ?>
                    <div class="info-row">
                        <div class="row">
                            <div class="col-md-4"><strong>Phone:</strong></div>
                            <div class="col-md-8"><?= htmlspecialchars($withdrawal['phone']) ?></div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <div class="mt-3">
                        <a href="users-manage.php?id=<?= $withdrawal['writer_id'] ?>" class="btn btn-sm btn-outline-primary">
                            <i class="bi bi-eye me-2"></i> View Writer Profile
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <!-- Balance Info -->
                <div class="info-card">
                    <h5 class="mb-4">Writer Balance</h5>
                    
                    <div class="mb-3">
                        <small class="text-muted">Available Balance</small>
                        <h4 class="text-success"><?= formatRupiah($withdrawal['available_balance'] ?? 0) ?></h4>
                    </div>

                    <div class="mb-3">
                        <small class="text-muted">Pending Balance</small>
                        <h5><?= formatRupiah($withdrawal['pending_balance'] ?? 0) ?></h5>
                    </div>

                    <div class="mb-3">
                        <small class="text-muted">Total Withdrawn</small>
                        <h5><?= formatRupiah($withdrawal['total_withdrawn'] ?? 0) ?></h5>
                    </div>
                </div>

                <!-- Statistics -->
                <div class="info-card">
                    <h5 class="mb-4">Writer Statistics</h5>
                    
                    <div class="mb-3">
                        <div class="d-flex justify-content-between">
                            <span>Total Books:</span>
                            <strong><?= $writerBooks['total_books'] ?? 0 ?></strong>
                        </div>
                    </div>

                    <div class="mb-3">
                        <div class="d-flex justify-content-between">
                            <span>Approved Books:</span>
                            <strong><?= $writerBooks['approved_books'] ?? 0 ?></strong>
                        </div>
                    </div>

                    <div class="mb-3">
                        <div class="d-flex justify-content-between">
                            <span>Total Sales:</span>
                            <strong><?= $writerSales['total_sales'] ?? 0 ?></strong>
                        </div>
                    </div>

                    <div class="mb-3">
                        <div class="d-flex justify-content-between">
                            <span>Total Royalty:</span>
                            <strong class="text-success"><?= formatRupiah($writerSales['total_royalty'] ?? 0) ?></strong>
                        </div>
                    </div>
                </div>

                <!-- Other Withdrawals -->
                <?php if (!empty($otherWithdrawals)): ?>
                <div class="info-card">
                    <h5 class="mb-4">Recent Withdrawals</h5>
                    <?php foreach ($otherWithdrawals as $ow): ?>
                    <div class="mb-3 pb-3 border-bottom">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <strong><?= formatRupiah($ow['amount']) ?></strong><br>
                                <small class="text-muted"><?= timeAgo($ow['created_at']) ?></small>
                            </div>
                            <span class="badge bg-<?= $badgeClass[$ow['status']] ?>">
                                <?= ucfirst($ow['status']) ?>
                            </span>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Reject Modal -->
    <div class="modal fade" id="rejectModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" action="withdrawal-process.php">
                    <div class="modal-header">
                        <h5 class="modal-title">Reject Withdrawal</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="withdrawal_id" value="<?= $withdrawal['id'] ?>">
                        <input type="hidden" name="action" value="reject">
                        <label class="form-label">Rejection Reason <span class="text-danger">*</span></label>
                        <textarea class="form-control" name="reason" rows="4" required 
                                  placeholder="Please provide a clear reason for rejection..."></textarea>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger">Reject Withdrawal</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>