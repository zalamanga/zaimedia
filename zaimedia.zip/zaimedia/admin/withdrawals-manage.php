<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireRole('admin');

$user = getCurrentUser();
$conn = getDBConnection();

// Get filter
$statusFilter = $_GET['status'] ?? 'all';

// Get withdrawals
$sql = "
    SELECT w.*, u.full_name, u.email, u.username
    FROM withdrawals w
    JOIN users u ON w.writer_id = u.id
    WHERE 1=1
";

$params = [];
if ($statusFilter !== 'all') {
    $sql .= " AND w.status = ?";
    $params[] = $statusFilter;
}

$sql .= " ORDER BY w.created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$withdrawals = $stmt->fetchAll();

// Get statistics
$stmt = $conn->query("SELECT COUNT(*) FROM withdrawals WHERE status = 'pending'");
$pendingCount = $stmt->fetchColumn();

$stmt = $conn->query("SELECT COUNT(*) FROM withdrawals WHERE status = 'approved'");
$approvedCount = $stmt->fetchColumn();

$stmt = $conn->query("SELECT COUNT(*) FROM withdrawals WHERE status = 'completed'");
$completedCount = $stmt->fetchColumn();

$stmt = $conn->query("SELECT COUNT(*) FROM withdrawals WHERE status = 'rejected'");
$rejectedCount = $stmt->fetchColumn();

$stmt = $conn->query("SELECT SUM(amount) FROM withdrawals WHERE status = 'completed'");
$totalPaid = $stmt->fetchColumn() ?? 0;

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Withdrawals Management - Admin ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: white;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            position: fixed;
            width: 250px;
        }
        .sidebar-header {
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .menu-item {
            padding: 12px 20px;
            color: #333;
            text-decoration: none;
            display: block;
            transition: all 0.3s;
        }
        .menu-item:hover,
        .menu-item.active {
            background: #f8f9fa;
            color: #667eea;
            border-left: 3px solid #667eea;
        }
        .content-area {
            margin-left: 250px;
            padding: 30px;
        }
        .stats-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .table-card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0">Admin Panel</h4>
            <small><?= htmlspecialchars($user['full_name']) ?></small>
        </div>
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a href="books-manage.php" class="menu-item">
                <i class="bi bi-book me-2"></i> Books
            </a>
            <a href="users-manage.php" class="menu-item">
                <i class="bi bi-people me-2"></i> Users
            </a>
            <a href="withdrawals-manage.php" class="menu-item active">
                <i class="bi bi-cash-stack me-2"></i> Withdrawals
            </a>
            <a href="orders-manage.php" class="menu-item">
                <i class="bi bi-cart me-2"></i> Orders
            </a>
            <a href="categories-manage.php" class="menu-item">
                <i class="bi bi-tags me-2"></i> Categories
            </a>
        </div>
        <div style="position: absolute; bottom: 20px; width: 100%;">
            <a href="../index.php" class="menu-item">
                <i class="bi bi-house me-2"></i> Homepage
            </a>
            <a href="../logout.php" class="menu-item">
                <i class="bi bi-box-arrow-left me-2"></i> LogOut
            </a>
        </div>
    </div>

    <!-- Content Area -->
    <div class="content-area">
        <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
            <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <h2 class="mb-4">Withdrawal Management</h2>

        <!-- Stats Row -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="bi bi-clock-history fs-1 text-warning"></i>
                        </div>
                        <div>
                            <h6 class="text-muted mb-0">Pending</h6>
                            <h3 class="mb-0"><?= $pendingCount ?></h3>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="bi bi-check-circle fs-1 text-info"></i>
                        </div>
                        <div>
                            <h6 class="text-muted mb-0">Approved</h6>
                            <h3 class="mb-0"><?= $approvedCount ?></h3>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="bi bi-check2-circle fs-1 text-success"></i>
                        </div>
                        <div>
                            <h6 class="text-muted mb-0">Completed</h6>
                            <h3 class="mb-0"><?= $completedCount ?></h3>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="bi bi-cash-stack fs-1 text-primary"></i>
                        </div>
                        <div>
                            <h6 class="text-muted mb-0">Total Paid</h6>
                            <h5 class="mb-0 text-success"><?= formatRupiah($totalPaid) ?></h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filter -->
        <div class="table-card">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="mb-0">Withdrawal Requests</h5>
                <div class="btn-group">
                    <a href="?status=all" class="btn btn-sm <?= $statusFilter === 'all' ? 'btn-primary' : 'btn-outline-primary' ?>">
                        All
                    </a>
                    <a href="?status=pending" class="btn btn-sm <?= $statusFilter === 'pending' ? 'btn-warning' : 'btn-outline-warning' ?>">
                        Pending
                    </a>
                    <a href="?status=approved" class="btn btn-sm <?= $statusFilter === 'approved' ? 'btn-info' : 'btn-outline-info' ?>">
                        Approved
                    </a>
                    <a href="?status=completed" class="btn btn-sm <?= $statusFilter === 'completed' ? 'btn-success' : 'btn-outline-success' ?>">
                        Completed
                    </a>
                    <a href="?status=rejected" class="btn btn-sm <?= $statusFilter === 'rejected' ? 'btn-danger' : 'btn-outline-danger' ?>">
                        Rejected
                    </a>
                </div>
            </div>

            <?php if (empty($withdrawals)): ?>
                <div class="alert alert-info">
                    No withdrawal requests found.
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Writer</th>
                                <th>Amount</th>
                                <th>Bank Info</th>
                                <th>Status</th>
                                <th>Requested</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($withdrawals as $w): ?>
                            <tr>
                                <td><?= $w['id'] ?></td>
                                <td>
                                    <strong><?= htmlspecialchars($w['full_name']) ?></strong><br>
                                    <small class="text-muted"><?= htmlspecialchars($w['email']) ?></small>
                                </td>
                                <td>
                                    <strong class="text-primary"><?= formatRupiah($w['amount']) ?></strong>
                                </td>
                                <td>
                                    <small>
                                        <?= htmlspecialchars($w['bank_name']) ?><br>
                                        <?= htmlspecialchars($w['account_number']) ?><br>
                                        <?= htmlspecialchars($w['account_name']) ?>
                                    </small>
                                </td>
                                <td>
                                    <?php
                                    $badgeClass = [
                                        'pending' => 'warning',
                                        'approved' => 'info',
                                        'completed' => 'success',
                                        'rejected' => 'danger'
                                    ];
                                    ?>
                                    <span class="badge bg-<?= $badgeClass[$w['status']] ?>">
                                        <?= ucfirst($w['status']) ?>
                                    </span>
                                </td>
                                <td>
                                    <small><?= formatDateIndo($w['created_at']) ?></small>
                                </td>
                                <td>
                                    <?php if ($w['status'] === 'pending'): ?>
                                        <form method="POST" action="withdrawal-process.php" class="d-inline">
                                            <input type="hidden" name="withdrawal_id" value="<?= $w['id'] ?>">
                                            <input type="hidden" name="action" value="approve">
                                            <button type="submit" class="btn btn-sm btn-success" 
                                                    onclick="return confirm('Approve this withdrawal?')">
                                                <i class="bi bi-check-circle"></i>
                                            </button>
                                        </form>
                                        <button type="button" class="btn btn-sm btn-danger" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#rejectModal<?= $w['id'] ?>">
                                            <i class="bi bi-x-circle"></i>
                                        </button>
                                    <?php elseif ($w['status'] === 'approved'): ?>
                                        <form method="POST" action="withdrawal-process.php" class="d-inline">
                                            <input type="hidden" name="withdrawal_id" value="<?= $w['id'] ?>">
                                            <input type="hidden" name="action" value="complete">
                                            <button type="submit" class="btn btn-sm btn-info" 
                                                    onclick="return confirm('Mark as completed?')">
                                                <i class="bi bi-check2-circle"></i> Complete
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                    
                                    <a href="withdrawal-detail.php?id=<?= $w['id'] ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                </td>
                            </tr>

                            <!-- Reject Modal -->
                            <div class="modal fade" id="rejectModal<?= $w['id'] ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form method="POST" action="withdrawal-process.php">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Reject Withdrawal</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <input type="hidden" name="withdrawal_id" value="<?= $w['id'] ?>">
                                                <input type="hidden" name="action" value="reject">
                                                <label class="form-label">Rejection Reason:</label>
                                                <textarea class="form-control" name="reason" rows="3" required></textarea>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                <button type="submit" class="btn btn-danger">Reject</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>