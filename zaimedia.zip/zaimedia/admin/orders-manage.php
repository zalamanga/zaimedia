<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireRole('admin');

$user = getCurrentUser();
$conn = getDBConnection();

// Get filters
$status = $_GET['status'] ?? 'all';
$search = $_GET['search'] ?? '';

// Build query
$sql = "SELECT o.*, u.username, u.full_name,
        (SELECT COUNT(*) FROM order_items WHERE order_id = o.id) as item_count
        FROM orders o
        JOIN users u ON o.customer_id = u.id
        WHERE 1=1";
$params = [];

if ($status !== 'all') {
    if ($status === 'payment_pending') {
        $sql .= " AND o.payment_status = 'pending'";
    } elseif ($status === 'payment_paid') {
        $sql .= " AND o.payment_status = 'paid'";
    } else {
        $sql .= " AND o.order_status = ?";
        $params[] = $status;
    }
}

if (!empty($search)) {
    $sql .= " AND (o.order_number LIKE ? OR u.username LIKE ? OR u.full_name LIKE ?)";
    $search_param = '%' . $search . '%';
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
}

$sql .= " ORDER BY o.created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();

// Get stats
$stmt = $conn->query("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN payment_status = 'pending' THEN 1 ELSE 0 END) as payment_pending,
        SUM(CASE WHEN payment_status = 'paid' THEN 1 ELSE 0 END) as payment_paid,
        SUM(CASE WHEN order_status = 'pending' THEN 1 ELSE 0 END) as order_pending,
        SUM(CASE WHEN order_status = 'processing' THEN 1 ELSE 0 END) as processing,
        SUM(CASE WHEN order_status = 'delivered' THEN 1 ELSE 0 END) as delivered,
        SUM(CASE WHEN payment_status = 'paid' THEN total ELSE 0 END) as total_revenue
    FROM orders
");
$stats = $stmt->fetch();

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $orderId = (int)$_POST['order_id'];
    $newStatus = $_POST['new_status'];
    
    $stmt = $conn->prepare("UPDATE orders SET order_status = ? WHERE id = ?");
    if ($stmt->execute([$newStatus, $orderId])) {
        setFlash('success', 'Order status updated successfully');
    } else {
        setFlash('error', 'Failed to update order status');
    }
    
    redirect('orders-manage.php?status=' . $status);
}

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: white;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            position: fixed;
            width: 250px;
        }
        .sidebar-header {
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .menu-item {
            padding: 12px 20px;
            color: #333;
            text-decoration: none;
            display: block;
            transition: all 0.3s;
        }
        .menu-item:hover,
        .menu-item.active {
            background: #f8f9fa;
            color: #667eea;
            border-left: 3px solid #667eea;
        }
        .content-area {
            margin-left: 250px;
            padding: 30px;
        }
        .stats-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .order-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: all 0.3s;
        }
        .order-card:hover {
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }
        .stats-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0">Admin</h4>
            <small>Administrator</small>
        </div>
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a href="books-manage.php" class="menu-item">
                <i class="bi bi-book me-2"></i> Books
            </a>
            <a href="users-manage.php" class="menu-item">
                <i class="bi bi-people me-2"></i> Users
            </a>
            <a href="withdrawals-manage.php" class="menu-item">
                <i class="bi bi-cash-stack me-2"></i> Withdrawals
            </a>
            <a href="orders-manage.php" class="menu-item active">
                <i class="bi bi-cart me-2"></i> Orders
            </a>
            <a href="categories-manage.php" class="menu-item">
                <i class="bi bi-tags me-2"></i> Categories
            </a>
        </div>
        <div style="position: absolute; bottom: 20px; width: 100%;">
            <a href="../index.php" class="menu-item">
                <i class="bi bi-house me-2"></i> Homepage
            </a>
            <a href="../logout.php" class="menu-item">
                <i class="bi bi-box-arrow-left me-2"></i> LogOut
            </a>
        </div>
    </div>

    <!-- Content Area -->
    <div class="content-area">
        <h2 class="mb-4">Manage Orders</h2>

        <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
            <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Stats -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="d-flex align-items-center">
                        <div class="stats-icon bg-primary bg-opacity-10 text-primary me-3">
                            <i class="bi bi-cart"></i>
                        </div>
                        <div>
                            <h6 class="text-muted mb-0">Total Orders</h6>
                            <h3 class="mb-0"><?= $stats['total'] ?></h3>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="d-flex align-items-center">
                        <div class="stats-icon bg-warning bg-opacity-10 text-warning me-3">
                            <i class="bi bi-clock"></i>
                        </div>
                        <div>
                            <h6 class="text-muted mb-0">Payment Pending</h6>
                            <h3 class="mb-0"><?= $stats['payment_pending'] ?></h3>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="d-flex align-items-center">
                        <div class="stats-icon bg-info bg-opacity-10 text-info me-3">
                            <i class="bi bi-arrow-repeat"></i>
                        </div>
                        <div>
                            <h6 class="text-muted mb-0">Processing</h6>
                            <h3 class="mb-0"><?= $stats['processing'] ?></h3>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="d-flex align-items-center">
                        <div class="stats-icon bg-success bg-opacity-10 text-success me-3">
                            <i class="bi bi-cash-stack"></i>
                        </div>
                        <div>
                            <h6 class="text-muted mb-0">Total Revenue</h6>
                            <h3 class="mb-0 text-success"><?= formatRupiah($stats['total_revenue']) ?></h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="stats-card">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <ul class="nav nav-pills">
                        <li class="nav-item">
                            <a class="nav-link <?= $status === 'all' ? 'active' : '' ?>" 
                               href="?status=all">
                                All (<?= $stats['total'] ?>)
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= $status === 'payment_pending' ? 'active' : '' ?>" 
                               href="?status=payment_pending">
                                Payment Pending (<?= $stats['payment_pending'] ?>)
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= $status === 'processing' ? 'active' : '' ?>" 
                               href="?status=processing">
                                Processing (<?= $stats['processing'] ?>)
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= $status === 'delivered' ? 'active' : '' ?>" 
                               href="?status=delivered">
                                Delivered (<?= $stats['delivered'] ?>)
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <form method="GET" class="d-flex">
                        <input type="hidden" name="status" value="<?= $status ?>">
                        <input type="text" class="form-control me-2" name="search" 
                               placeholder="Search orders..." value="<?= htmlspecialchars($search) ?>">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-search"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Orders List -->
        <?php if (empty($orders)): ?>
            <div class="stats-card text-center py-5">
                <i class="bi bi-inbox display-1 text-muted"></i>
                <h4 class="mt-3">No Orders Found</h4>
            </div>
        <?php else: ?>
            <?php foreach ($orders as $order): ?>
            <div class="order-card">
                <div class="row align-items-center">
                    <div class="col-md-3">
                        <h6 class="mb-1">
                            <i class="bi bi-receipt me-2"></i>
                            <?= htmlspecialchars($order['order_number']) ?>
                        </h6>
                        <small class="text-muted">
                            <i class="bi bi-person me-1"></i>
                            <?= htmlspecialchars($order['full_name']) ?>
                        </small>
                        <br>
                        <small class="text-muted">
                            <i class="bi bi-calendar me-1"></i>
                            <?= formatDateTimeIndo($order['created_at']) ?>
                        </small>
                    </div>
                    
                    <div class="col-md-2 text-center">
                        <strong class="text-primary d-block"><?= formatRupiah($order['total']) ?></strong>
                        <small class="text-muted"><?= $order['item_count'] ?> items</small>
                    </div>
                    
                    <div class="col-md-2 text-center">
                        <i class="bi bi-credit-card text-muted me-1"></i>
                        <small><?= ucwords(str_replace('_', ' ', $order['payment_method'])) ?></small>
                        <br>
                        <?php
                        $paymentBadge = [
                            'pending' => 'warning',
                            'paid' => 'success',
                            'failed' => 'danger'
                        ];
                        ?>
                        <span class="badge bg-<?= $paymentBadge[$order['payment_status']] ?>">
                            <?= ucfirst($order['payment_status']) ?>
                        </span>
                    </div>
                    
                    <div class="col-md-2 text-center">
                        <?php
                        $statusBadge = [
                            'pending' => 'secondary',
                            'processing' => 'info',
                            'shipped' => 'primary',
                            'delivered' => 'success',
                            'cancelled' => 'danger'
                        ];
                        ?>
                        <span class="badge bg-<?= $statusBadge[$order['order_status']] ?>">
                            <?= ucfirst($order['order_status']) ?>
                        </span>
                    </div>
                    
                    <div class="col-md-3 text-end">
                        <div class="btn-group btn-group-sm">
                            <button class="btn btn-outline-primary" 
                                    onclick="viewOrder(<?= $order['id'] ?>)">
                                <i class="bi bi-eye"></i>
                            </button>
                            <div class="btn-group btn-group-sm" role="group">
                                <button class="btn btn-outline-secondary dropdown-toggle" 
                                        data-bs-toggle="dropdown">
                                    <i class="bi bi-gear"></i>
                                </button>
                                <ul class="dropdown-menu">
                                    <li><h6 class="dropdown-header">Update Status</h6></li>
                                    <li>
                                        <a class="dropdown-item" href="#" 
                                           onclick="updateStatus(<?= $order['id'] ?>, 'pending')">
                                            <i class="bi bi-circle text-secondary me-2"></i>Pending
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item" href="#" 
                                           onclick="updateStatus(<?= $order['id'] ?>, 'processing')">
                                            <i class="bi bi-arrow-repeat text-info me-2"></i>Processing
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item" href="#" 
                                           onclick="updateStatus(<?= $order['id'] ?>, 'shipped')">
                                            <i class="bi bi-truck text-primary me-2"></i>Shipped
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item" href="#" 
                                           onclick="updateStatus(<?= $order['id'] ?>, 'delivered')">
                                            <i class="bi bi-check-circle text-success me-2"></i>Delivered
                                        </a>
                                    </li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li>
                                        <a class="dropdown-item text-danger" href="#" 
                                           onclick="updateStatus(<?= $order['id'] ?>, 'cancelled')">
                                            <i class="bi bi-x-circle me-2"></i>Cancelled
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Order Detail Modal -->
    <div class="modal fade" id="orderDetailModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Order Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="orderDetailContent">
                    <div class="text-center py-5">
                        <div class="spinner-border text-primary" role="status"></div>
                        <p class="mt-3">Loading...</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function viewOrder(orderId) {
            const modal = new bootstrap.Modal(document.getElementById('orderDetailModal'));
            modal.show();
            
            // Load order details via AJAX
            fetch('order-detail-ajax.php?id=' + orderId)
                .then(response => response.text())
                .then(html => {
                    document.getElementById('orderDetailContent').innerHTML = html;
                })
                .catch(error => {
                    document.getElementById('orderDetailContent').innerHTML = 
                        '<div class="alert alert-danger">Failed to load order details</div>';
                });
        }

        function updateStatus(orderId, newStatus) {
            if (confirm('Update order status to "' + newStatus + '"?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="update_status" value="1">
                    <input type="hidden" name="order_id" value="${orderId}">
                    <input type="hidden" name="new_status" value="${newStatus}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>
</body>
</html>