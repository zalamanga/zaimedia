<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireRole('admin');

$user = getCurrentUser();
$conn = getDBConnection();
$bookId = $_GET['id'] ?? 0;

// Get book details
$stmt = $conn->prepare("
    SELECT b.*, c.name as category_name, u.full_name as writer_name, u.email as writer_email
    FROM books b
    LEFT JOIN categories c ON b.category_id = c.id
    LEFT JOIN users u ON b.writer_id = u.id
    WHERE b.id = ?
");
$stmt->execute([$bookId]);
$book = $stmt->fetch();

if (!$book) {
    setFlash('error', 'Buku tidak ditemukan');
    redirect('books-manage.php');
}

// Get book reviews
$stmt = $conn->prepare("
    SELECT r.*, u.full_name, u.username
    FROM reviews r
    JOIN users u ON r.customer_id = u.id
    WHERE r.book_id = ?
    ORDER BY r.created_at DESC
");
$stmt->execute([$bookId]);
$reviews = $stmt->fetchAll();

// Get sales statistics
$stmt = $conn->prepare("
    SELECT 
        COUNT(*) as total_sales,
        SUM(quantity) as books_sold,
        SUM(book_price * quantity) as total_revenue
    FROM sales
    WHERE book_id = ?
");
$stmt->execute([$bookId]);
$salesStats = $stmt->fetch();

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Detail - Admin ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: white;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            position: fixed;
            width: 250px;
        }
        .sidebar-header {
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .content-area {
            margin-left: 250px;
            padding: 30px;
        }
        .book-cover-large {
            max-width: 300px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .info-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .status-badge {
            font-size: 1rem;
            padding: 8px 16px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0">Admin Panel</h4>
            <small><?= htmlspecialchars($user['full_name']) ?></small>
        </div>
        <div class="p-3">
            <a href="dashboard.php" class="btn btn-outline-primary w-100 mb-2">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a href="books-manage.php" class="btn btn-primary w-100 mb-2">
                <i class="bi bi-book me-2"></i> Books
            </a>
            <a href="users-manage.php" class="btn btn-outline-primary w-100 mb-2">
                <i class="bi bi-people me-2"></i> Users
            </a>
            <a href="withdrawals-manage.php" class="btn btn-outline-primary w-100 mb-2">
                <i class="bi bi-wallet2 me-2"></i> Withdrawals
            </a>
            <a href="../index.php" class="btn btn-outline-secondary w-100 mb-2">
                <i class="bi bi-house me-2"></i> Homepage
            </a>
            <a href="../logout.php" class="btn btn-outline-danger w-100">
                <i class="bi bi-box-arrow-left me-2"></i> Logout
            </a>
        </div>
    </div>

    <!-- Content -->
    <div class="content-area">
        <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
            <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Book Details</h2>
            <a href="books-manage.php" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left me-2"></i> Back to Books
            </a>
        </div>

        <div class="row">
            <div class="col-md-4">
                <div class="info-card text-center">
                    <?php if ($book['cover_image']): ?>
                        <img src="<?= BOOK_COVER_URL . $book['cover_image'] ?>" 
                             class="book-cover-large mb-3" 
                             alt="<?= htmlspecialchars($book['title']) ?>">
                    <?php else: ?>
                        <div class="bg-secondary text-white p-5 mb-3 rounded">No Image</div>
                    <?php endif; ?>
                    
                    <h5>Status</h5>
                    <?php
                    $statusClass = [
                        'pending' => 'warning',
                        'approved' => 'success',
                        'rejected' => 'danger'
                    ];
                    ?>
                    <span class="badge bg-<?= $statusClass[$book['status']] ?> status-badge mb-3">
                        <?= ucfirst($book['status']) ?>
                    </span>

                    <?php if ($book['status'] === 'pending'): ?>
                    <div class="d-grid gap-2">
                        <form method="POST" action="book-approve.php" onsubmit="return confirm('Approve this book?')">
                            <input type="hidden" name="book_id" value="<?= $book['id'] ?>">
                            <button type="submit" class="btn btn-success w-100">
                                <i class="bi bi-check-circle me-2"></i> Approve Book
                            </button>
                        </form>
                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#rejectModal">
                            <i class="bi bi-x-circle me-2"></i> Reject Book
                        </button>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="info-card">
                    <h5 class="mb-3">Sales Statistics</h5>
                    <div class="mb-2">
                        <strong>Total Sales:</strong> <?= $salesStats['total_sales'] ?? 0 ?> orders
                    </div>
                    <div class="mb-2">
                        <strong>Books Sold:</strong> <?= $salesStats['books_sold'] ?? 0 ?> copies
                    </div>
                    <div>
                        <strong>Revenue:</strong> <?= formatRupiah($salesStats['total_revenue'] ?? 0) ?>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <div class="info-card">
                    <h4 class="mb-4"><?= htmlspecialchars($book['title']) ?></h4>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Category:</strong> <?= htmlspecialchars($book['category_name']) ?>
                        </div>
                        <div class="col-md-6">
                            <strong>Author:</strong> <?= htmlspecialchars($book['author']) ?>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Writer:</strong> <?= htmlspecialchars($book['writer_name']) ?>
                        </div>
                        <div class="col-md-6">
                            <strong>Price:</strong> <?= formatRupiah($book['price']) ?>
                        </div>
                    </div>

                    <?php if (!empty($book['publisher'])): ?>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Publisher:</strong> <?= htmlspecialchars($book['publisher']) ?>
                        </div>
                        <div class="col-md-6">
                            <strong>Year:</strong> <?= htmlspecialchars($book['year'] ?? '-') ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if (!empty($book['pages'])): ?>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Pages:</strong> <?= $book['pages'] ?>
                        </div>
                        <div class="col-md-6">
                            <strong>ISBN:</strong> <?= htmlspecialchars($book['isbn'] ?? '-') ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Views:</strong> <?= number_format($book['views'] ?? 0) ?>
                        </div>
                        <div class="col-md-6">
                            <strong>Created:</strong> <?= formatDateIndo($book['created_at']) ?>
                        </div>
                    </div>

                    <hr>

                    <h5>Description</h5>
                    <p><?= nl2br(htmlspecialchars($book['long_description'] ?? $book['description'] ?? 'No description')) ?></p>

                    <?php if ($book['pdf_file']): ?>
                    <a href="<?= BOOK_PDF_URL . $book['pdf_file'] ?>" target="_blank" class="btn btn-info">
                        <i class="bi bi-file-pdf me-2"></i> View PDF
                    </a>
                    <?php endif; ?>
                </div>

                <?php if (!empty($reviews)): ?>
                <div class="info-card">
                    <h5 class="mb-4">Reviews (<?= count($reviews) ?>)</h5>
                    <?php foreach ($reviews as $review): ?>
                    <div class="border-bottom pb-3 mb-3">
                        <div class="d-flex justify-content-between">
                            <strong><?= htmlspecialchars($review['full_name']) ?></strong>
                            <div>
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <i class="bi bi-star-fill <?= $i <= $review['rating'] ? 'text-warning' : 'text-muted' ?>"></i>
                                <?php endfor; ?>
                            </div>
                        </div>
                        <small class="text-muted"><?= timeAgo($review['created_at']) ?></small>
                        <p class="mb-0 mt-2"><?= htmlspecialchars($review['comment']) ?></p>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Reject Modal -->
    <div class="modal fade" id="rejectModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" action="book-reject.php">
                    <div class="modal-header">
                        <h5 class="modal-title">Reject Book</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="book_id" value="<?= $book['id'] ?>">
                        <label class="form-label">Rejection Reason:</label>
                        <textarea class="form-control" name="reason" rows="3" required></textarea>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger">Reject Book</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>