<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
require_once '../api/books.php';

// Require admin role
requireRole('admin');

$user = getCurrentUser();
$bookId = $_GET['id'] ?? 0;

// Get book details
$book = getBook($bookId);

if (!$book) {
    setFlash('error', 'Buku tidak ditemukan');
    redirect('dashboard.php');
}

// Handle review action
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];
    $rejectionReason = $_POST['rejection_reason'] ?? null;
    
    if ($action === 'approve') {
        $result = reviewBook($bookId, 'approved');
    } elseif ($action === 'reject') {
        if (empty($rejectionReason)) {
            $error = 'Alasan penolakan harus diisi';
        } else {
            $result = reviewBook($bookId, 'rejected', $rejectionReason);
        }
    }
    
    if (isset($result) && $result['success']) {
        setFlash('success', $result['message']);
        redirect('books-manage.php');
    } elseif (isset($result)) {
        $error = $result['message'];
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review Book - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: white;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            position: fixed;
            width: 250px;
        }
        .sidebar-header {
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .menu-item {
            padding: 12px 20px;
            color: #333;
            text-decoration: none;
            display: block;
            transition: all 0.3s;
        }
        .menu-item:hover,
        .menu-item.active {
            background: #f8f9fa;
            color: #667eea;
            border-left: 3px solid #667eea;
        }
        .content-area {
            margin-left: 250px;
            padding: 30px;
        }
        .stats-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .book-cover {
            width: 100%;
            max-width: 300px;
            height: auto;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        }
        .info-row {
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }
        .info-label {
            color: #666;
            font-weight: 600;
            min-width: 150px;
            display: inline-block;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0">Admin</h4>
            <small>Administrator</small>
        </div>
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a href="books-manage.php" class="menu-item active">
                <i class="bi bi-book me-2"></i> Books
            </a>
            <a href="users-manage.php" class="menu-item">
                <i class="bi bi-people me-2"></i> Users
            </a>
            <a href="withdrawals-manage.php" class="menu-item">
                <i class="bi bi-cash-stack me-2"></i> Withdrawals
            </a>
            <a href="orders-manage.php" class="menu-item">
                <i class="bi bi-cart me-2"></i> Orders
            </a>
            <a href="categories-manage.php" class="menu-item">
                <i class="bi bi-tags me-2"></i> Categories
            </a>
        </div>
        <div style="position: absolute; bottom: 20px; width: 100%;">
            <a href="../index.php" class="menu-item">
                <i class="bi bi-house me-2"></i> Homepage
            </a>
            <a href="../logout.php" class="menu-item">
                <i class="bi bi-box-arrow-left me-2"></i> LogOut
            </a>
        </div>
    </div>

    <!-- Content Area -->
    <div class="content-area">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Review Book</h2>
            <a href="books-manage.php" class="btn btn-secondary">
                <i class="bi bi-arrow-left me-2"></i> Kembali
            </a>
        </div>

        <?php if (isset($error)): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?= $error ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-4">
                <!-- Book Cover -->
                <div class="stats-card text-center">
                    <?php if ($book['cover_image']): ?>
                        <img src="<?= BOOK_COVER_URL . $book['cover_image'] ?>" 
                             alt="<?= htmlspecialchars($book['title']) ?>"
                             class="book-cover">
                    <?php else: ?>
                        <div class="book-cover d-flex align-items-center justify-content-center bg-light">
                            <i class="bi bi-book fs-1 text-muted"></i>
                        </div>
                    <?php endif; ?>
                    
                    <div class="mt-3">
                        <span class="badge bg-warning">Pending Review</span>
                    </div>
                </div>

                <!-- Writer Info -->
                <div class="stats-card">
                    <h6 class="mb-3">Writer Information</h6>
                    <div class="info-row">
                        <div class="info-label">Name:</div>
                        <div><?= htmlspecialchars($book['writer_name'] ?? 'N/A') ?></div>
                    </div>
                    <div class="info-row">
                        <div class="info-label">Email:</div>
                        <div><?= htmlspecialchars($book['writer_email'] ?? 'N/A') ?></div>
                    </div>
                    <div class="info-row border-0">
                        <div class="info-label">Submitted:</div>
                        <div><?= formatDateTimeIndo($book['created_at']) ?></div>
                    </div>
                </div>

                <!-- PDF File -->
                <?php if ($book['pdf_file']): ?>
                <div class="stats-card">
                    <h6 class="mb-3">PDF File</h6>
                    <a href="<?= BOOK_PDF_URL . $book['pdf_file'] ?>" 
                       class="btn btn-outline-danger w-100" 
                       target="_blank">
                        <i class="bi bi-file-pdf me-2"></i> View PDF
                    </a>
                </div>
                <?php endif; ?>
            </div>

            <div class="col-md-8">
                <!-- Book Details -->
                <div class="stats-card">
                    <h5 class="mb-4">Book Details</h5>
                    
                    <div class="info-row">
                        <div class="info-label">Title:</div>
                        <div><strong><?= htmlspecialchars($book['title']) ?></strong></div>
                    </div>
                    
                    <div class="info-row">
                        <div class="info-label">Author:</div>
                        <div><?= htmlspecialchars($book['author']) ?></div>
                    </div>
                    
                    <div class="info-row">
                        <div class="info-label">Publisher:</div>
                        <div><?= htmlspecialchars($book['publisher']) ?></div>
                    </div>
                    
                    <div class="info-row">
                        <div class="info-label">Year:</div>
                        <div><?= $book['year'] ?></div>
                    </div>
                    
                    <div class="info-row">
                        <div class="info-label">Pages:</div>
                        <div><?= $book['pages'] ?> halaman</div>
                    </div>
                    
                    <div class="info-row">
                        <div class="info-label">Price:</div>
                        <div><strong class="text-primary"><?= formatRupiah($book['price']) ?></strong></div>
                    </div>
                    
                    <div class="info-row">
                        <div class="info-label">ISBN:</div>
                        <div><?= $book['isbn'] ?: '-' ?></div>
                    </div>
                    
                    <div class="info-row border-0">
                        <div class="info-label">Category:</div>
                        <div><span class="badge bg-secondary"><?= htmlspecialchars($book['category_name']) ?></span></div>
                    </div>
                </div>

                <!-- Description -->
                <div class="stats-card">
                    <h6 class="mb-3">Short Description</h6>
                    <p><?= nl2br(htmlspecialchars($book['short_description'])) ?></p>
                    
                    <h6 class="mb-3 mt-4">Long Description</h6>
                    <p><?= nl2br(htmlspecialchars($book['long_description'])) ?></p>
                </div>

                <!-- Review Actions -->
                <div class="stats-card">
                    <h5 class="mb-4">Review Decision</h5>
                    
                    <form method="POST" id="reviewForm">
                        <div class="row">
                            <div class="col-md-6">
                                <button type="button" class="btn btn-success btn-lg w-100" onclick="approveBook()">
                                    <i class="bi bi-check-circle me-2"></i> Approve Book
                                </button>
                            </div>
                            <div class="col-md-6">
                                <button type="button" class="btn btn-danger btn-lg w-100" data-bs-toggle="modal" data-bs-target="#rejectModal">
                                    <i class="bi bi-x-circle me-2"></i> Reject Book
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Reject Modal -->
    <div class="modal fade" id="rejectModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Reject Book</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <div class="alert alert-warning">
                            <i class="bi bi-exclamation-triangle me-2"></i>
                            Anda akan menolak buku ini. Writer akan menerima notifikasi.
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Alasan Penolakan <span class="text-danger">*</span></label>
                            <textarea class="form-control" name="rejection_reason" rows="4" 
                                      placeholder="Jelaskan alasan penolakan..." required></textarea>
                            <small class="text-muted">Alasan ini akan dikirim ke writer</small>
                        </div>
                        <input type="hidden" name="action" value="reject">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-danger">
                            <i class="bi bi-x-circle me-2"></i> Reject Book
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function approveBook() {
            if (confirm('Apakah Anda yakin ingin menyetujui buku ini?')) {
                const form = document.getElementById('reviewForm');
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'action';
                input.value = 'approve';
                form.appendChild(input);
                form.submit();
            }
        }
    </script>
</body>
</html>