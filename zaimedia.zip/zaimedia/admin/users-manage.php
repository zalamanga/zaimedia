<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireRole('admin');

$user = getCurrentUser();
$conn = getDBConnection();

// Get filters
$role = $_GET['role'] ?? 'all';
$search = $_GET['search'] ?? '';

// Build query
$sql = "SELECT * FROM users WHERE 1=1";
$params = [];

if ($role !== 'all') {
    $sql .= " AND role = ?";
    $params[] = $role;
}

if (!empty($search)) {
    $sql .= " AND (username LIKE ? OR full_name LIKE ? OR email LIKE ?)";
    $search_param = '%' . $search . '%';
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
}

$sql .= " ORDER BY created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll();

// Get stats
$stmt = $conn->query("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN role = 'admin' THEN 1 ELSE 0 END) as admins,
        SUM(CASE WHEN role = 'writer' THEN 1 ELSE 0 END) as writers,
        SUM(CASE WHEN role = 'customer' THEN 1 ELSE 0 END) as customers,
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
        SUM(CASE WHEN status = 'suspended' THEN 1 ELSE 0 END) as suspended
    FROM users
");
$stats = $stmt->fetch();

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $userId = (int)$_POST['user_id'];
    $action = $_POST['action'];
    
    // Don't allow admin to suspend themselves
    if ($userId === $_SESSION['user_id'] && $action === 'suspend') {
        setFlash('error', 'Tidak bisa suspend akun sendiri');
        redirect('users-manage.php');
    }
    
    if ($action === 'suspend') {
        $stmt = $conn->prepare("UPDATE users SET status = 'suspended' WHERE id = ?");
        $stmt->execute([$userId]);
        setFlash('success', 'User suspended');
        
    } elseif ($action === 'activate') {
        $stmt = $conn->prepare("UPDATE users SET status = 'active' WHERE id = ?");
        $stmt->execute([$userId]);
        setFlash('success', 'User activated');
        
    } elseif ($action === 'delete') {
        // Don't allow admin to delete themselves
        if ($userId === $_SESSION['user_id']) {
            setFlash('error', 'Tidak bisa delete akun sendiri');
            redirect('users-manage.php');
        }
        
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        setFlash('success', 'User deleted');
    }
    
    redirect('users-manage.php?role=' . $role);
}

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: white;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            position: fixed;
            width: 250px;
        }
        .sidebar-header {
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .menu-item {
            padding: 12px 20px;
            color: #333;
            text-decoration: none;
            display: block;
            transition: all 0.3s;
        }
        .menu-item:hover,
        .menu-item.active {
            background: #f8f9fa;
            color: #667eea;
            border-left: 3px solid #667eea;
        }
        .content-area {
            margin-left: 250px;
            padding: 30px;
        }
        .stats-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .user-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: #667eea;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1.2rem;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0">Admin</h4>
            <small>Administrator</small>
        </div>
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a href="books-manage.php" class="menu-item">
                <i class="bi bi-book me-2"></i> Books
            </a>
            <a href="users-manage.php" class="menu-item active">
                <i class="bi bi-people me-2"></i> Users
            </a>
            <a href="withdrawals-manage.php" class="menu-item">
                <i class="bi bi-cash-stack me-2"></i> Withdrawals
            </a>
            <a href="orders-manage.php" class="menu-item">
                <i class="bi bi-cart me-2"></i> Orders
            </a>
            <a href="categories-manage.php" class="menu-item">
                <i class="bi bi-tags me-2"></i> Categories
            </a>
        </div>
        <div style="position: absolute; bottom: 20px; width: 100%;">
            <a href="../index.php" class="menu-item">
                <i class="bi bi-house me-2"></i> Homepage
            </a>
            <a href="../logout.php" class="menu-item">
                <i class="bi bi-box-arrow-left me-2"></i> LogOut
            </a>
        </div>
    </div>

    <!-- Content Area -->
    <div class="content-area">
        <h2 class="mb-4">Manage Users</h2>

        <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
            <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Stats -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stats-card">
                    <h6 class="text-muted">Total Users</h6>
                    <h3><?= $stats['total'] ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <h6 class="text-muted">Writers</h6>
                    <h3 class="text-primary"><?= $stats['writers'] ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <h6 class="text-muted">Customers</h6>
                    <h3 class="text-success"><?= $stats['customers'] ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <h6 class="text-muted">Active Users</h6>
                    <h3 class="text-info"><?= $stats['active'] ?></h3>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="stats-card">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <ul class="nav nav-tabs border-0">
                        <li class="nav-item">
                            <a class="nav-link <?= $role === 'all' ? 'active' : '' ?>" href="?role=all">
                                All (<?= $stats['total'] ?>)
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= $role === 'admin' ? 'active' : '' ?>" href="?role=admin">
                                Admins (<?= $stats['admins'] ?>)
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= $role === 'writer' ? 'active' : '' ?>" href="?role=writer">
                                Writers (<?= $stats['writers'] ?>)
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= $role === 'customer' ? 'active' : '' ?>" href="?role=customer">
                                Customers (<?= $stats['customers'] ?>)
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <form method="GET" class="d-flex">
                        <input type="hidden" name="role" value="<?= $role ?>">
                        <input type="text" class="form-control me-2" name="search" 
                               placeholder="Search users..." value="<?= htmlspecialchars($search) ?>">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-search"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Users Table -->
        <div class="stats-card">
            <?php if (empty($users)): ?>
                <div class="alert alert-info mb-0">
                    <i class="bi bi-info-circle me-2"></i>
                    No users found
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Status</th>
                                <th>Joined</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $u): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="user-avatar me-3">
                                            <?= strtoupper(substr($u['username'], 0, 1)) ?>
                                        </div>
                                        <div>
                                            <strong><?= htmlspecialchars($u['full_name']) ?></strong><br>
                                            <small class="text-muted">@<?= htmlspecialchars($u['username']) ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td><?= htmlspecialchars($u['email']) ?></td>
                                <td>
                                    <?php
                                    $roleBadge = [
                                        'admin' => 'danger',
                                        'writer' => 'primary',
                                        'customer' => 'secondary'
                                    ];
                                    ?>
                                    <span class="badge bg-<?= $roleBadge[$u['role']] ?>">
                                        <?= ucfirst($u['role']) ?>
                                    </span>
                                </td>
                                <td>
                                    <?php
                                    $statusBadge = [
                                        'active' => 'success',
                                        'inactive' => 'warning',
                                        'suspended' => 'danger'
                                    ];
                                    ?>
                                    <span class="badge bg-<?= $statusBadge[$u['status']] ?>">
                                        <?= ucfirst($u['status']) ?>
                                    </span>
                                </td>
                                <td>
                                    <small><?= formatDateIndo($u['created_at']) ?></small>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <?php if ($u['status'] === 'active'): ?>
                                            <button class="btn btn-warning" onclick="suspendUser(<?= $u['id'] ?>)" 
                                                    <?= $u['id'] === $_SESSION['user_id'] ? 'disabled' : '' ?>>
                                                <i class="bi bi-pause-circle"></i>
                                            </button>
                                        <?php else: ?>
                                            <button class="btn btn-success" onclick="activateUser(<?= $u['id'] ?>)">
                                                <i class="bi bi-check-circle"></i>
                                            </button>
                                        <?php endif; ?>
                                        
                                        <button class="btn btn-danger" onclick="deleteUser(<?= $u['id'] ?>)"
                                                <?= $u['id'] === $_SESSION['user_id'] ? 'disabled' : '' ?>>
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                    
                                    <?php if ($u['role'] === 'writer'): ?>
                                    <a href="user-detail.php?id=<?= $u['id'] ?>" class="btn btn-sm btn-outline-primary ms-1">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function suspendUser(id) {
            if (confirm('Suspend user ini?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="user_id" value="${id}">
                    <input type="hidden" name="action" value="suspend">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        function activateUser(id) {
            if (confirm('Activate user ini?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="user_id" value="${id}">
                    <input type="hidden" name="action" value="activate">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        function deleteUser(id) {
            if (confirm('HAPUS user ini? Tindakan tidak bisa dibatalkan!')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="user_id" value="${id}">
                    <input type="hidden" name="action" value="delete">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>
</body>
</html>