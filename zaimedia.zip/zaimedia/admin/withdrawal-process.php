<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireRole('admin');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('withdrawals-manage.php');
}

$conn = getDBConnection();
$withdrawalId = $_POST['withdrawal_id'] ?? 0;
$action = $_POST['action'] ?? '';

// Get withdrawal data
$stmt = $conn->prepare("SELECT * FROM withdrawals WHERE id = ?");
$stmt->execute([$withdrawalId]);
$withdrawal = $stmt->fetch();

if (!$withdrawal) {
    setFlash('error', 'Withdrawal not found');
    redirect('withdrawals-manage.php');
}

try {
    $conn->beginTransaction();

    if ($action === 'approve') {
        // Approve withdrawal
        if ($withdrawal['status'] !== 'pending') {
            throw new Exception('Only pending withdrawals can be approved');
        }

        $stmt = $conn->prepare("
            UPDATE withdrawals 
            SET status = 'approved', 
                processed_at = NOW(),
                processed_by = ?
            WHERE id = ?
        ");
        $stmt->execute([$_SESSION['user_id'], $withdrawalId]);

        setFlash('success', 'Withdrawal approved successfully');

    } elseif ($action === 'complete') {
        // Complete withdrawal
        if ($withdrawal['status'] !== 'approved') {
            throw new Exception('Only approved withdrawals can be completed');
        }

        // Update withdrawal status
        $stmt = $conn->prepare("
            UPDATE withdrawals 
            SET status = 'completed',
                completed_at = NOW()
            WHERE id = ?
        ");
        $stmt->execute([$withdrawalId]);

        // Update writer balance - move from pending to withdrawn
        $stmt = $conn->prepare("
            UPDATE writer_balance 
            SET pending_balance = pending_balance - ?,
                withdrawn_balance = withdrawn_balance + ?
            WHERE writer_id = ?
        ");
        $stmt->execute([
            $withdrawal['amount'],
            $withdrawal['amount'],
            $withdrawal['writer_id']
        ]);

        setFlash('success', 'Withdrawal marked as completed');

    } elseif ($action === 'reject') {
        // Reject withdrawal
        if ($withdrawal['status'] !== 'pending') {
            throw new Exception('Only pending withdrawals can be rejected');
        }

        $reason = $_POST['reason'] ?? '';
        if (empty($reason)) {
            throw new Exception('Rejection reason is required');
        }

        // Update withdrawal status
        $stmt = $conn->prepare("
            UPDATE withdrawals 
            SET status = 'rejected',
                rejection_reason = ?,
                processed_at = NOW(),
                processed_by = ?
            WHERE id = ?
        ");
        $stmt->execute([$reason, $_SESSION['user_id'], $withdrawalId]);

        // Return amount to available balance
        $stmt = $conn->prepare("
            UPDATE writer_balance 
            SET pending_balance = pending_balance - ?,
                available_balance = available_balance + ?
            WHERE writer_id = ?
        ");
        $stmt->execute([
            $withdrawal['amount'],
            $withdrawal['amount'],
            $withdrawal['writer_id']
        ]);

        setFlash('success', 'Withdrawal rejected');

    } else {
        throw new Exception('Invalid action');
    }

    $conn->commit();

} catch (Exception $e) {
    $conn->rollBack();
    setFlash('error', 'Error: ' . $e->getMessage());
}

redirect('withdrawal-detail.php?id=' . $withdrawalId);