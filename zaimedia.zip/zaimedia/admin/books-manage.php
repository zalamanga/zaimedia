<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
require_once '../api/books.php';

// Require admin role
requireRole('admin');

$user = getCurrentUser();

// Get filter
$status = $_GET['status'] ?? 'all';
$search = $_GET['search'] ?? '';

// Build filters
$filters = [];
if ($status !== 'all') {
    $filters['status'] = $status;
}
if (!empty($search)) {
    $filters['search'] = $search;
}
$filters['order_by'] = 'b.created_at';
$filters['order_dir'] = 'DESC';

// Get books
$books = getBooks($filters);

// Get stats for tabs
$bookStats = getBookStats();

// Handle flash messages
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Books - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: white;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            position: fixed;
            width: 250px;
        }
        .sidebar-header {
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .menu-item {
            padding: 12px 20px;
            color: #333;
            text-decoration: none;
            display: block;
            transition: all 0.3s;
        }
        .menu-item:hover,
        .menu-item.active {
            background: #f8f9fa;
            color: #667eea;
            border-left: 3px solid #667eea;
        }
        .content-area {
            margin-left: 250px;
            padding: 30px;
        }
        .stats-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .nav-tabs .nav-link {
            color: #666;
        }
        .nav-tabs .nav-link.active {
            color: #667eea;
            font-weight: 600;
        }
        .book-thumb {
            width: 60px;
            height: 80px;
            object-fit: cover;
            border-radius: 5px;
        }
        .badge-pending {
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.7; }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0">Admin</h4>
            <small>Administrator</small>
        </div>
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a href="books-manage.php" class="menu-item active">
                <i class="bi bi-book me-2"></i> Books
            </a>
            <a href="users-manage.php" class="menu-item">
                <i class="bi bi-people me-2"></i> Users
            </a>
            <a href="withdrawals-manage.php" class="menu-item">
                <i class="bi bi-cash-stack me-2"></i> Withdrawals
            </a>
            <a href="orders-manage.php" class="menu-item">
                <i class="bi bi-cart me-2"></i> Orders
            </a>
            <a href="categories-manage.php" class="menu-item">
                <i class="bi bi-tags me-2"></i> Categories
            </a>
        </div>
        <div style="position: absolute; bottom: 20px; width: 100%;">
            <a href="../index.php" class="menu-item">
                <i class="bi bi-house me-2"></i> Homepage
            </a>
            <a href="../logout.php" class="menu-item">
                <i class="bi bi-box-arrow-left me-2"></i> LogOut
            </a>
        </div>
    </div>

    <!-- Content Area -->
    <div class="content-area">
        <h2 class="mb-4">Manage Books</h2>

        <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
            <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Filter & Search -->
        <div class="stats-card">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <ul class="nav nav-tabs border-0">
                        <li class="nav-item">
                            <a class="nav-link <?= $status === 'all' ? 'active' : '' ?>" href="?status=all">
                                All (<?= $bookStats['total'] ?>)
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= $status === 'pending' ? 'active' : '' ?>" href="?status=pending">
                                Pending (<?= $bookStats['pending'] ?>)
                                <?php if ($bookStats['pending'] > 0): ?>
                                <span class="badge bg-warning badge-pending"><?= $bookStats['pending'] ?></span>
                                <?php endif; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= $status === 'approved' ? 'active' : '' ?>" href="?status=approved">
                                Approved (<?= $bookStats['approved'] ?>)
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= $status === 'rejected' ? 'active' : '' ?>" href="?status=rejected">
                                Rejected (<?= $bookStats['rejected'] ?>)
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <form method="GET" class="d-flex">
                        <input type="hidden" name="status" value="<?= $status ?>">
                        <input type="text" class="form-control me-2" name="search" 
                               placeholder="Search books..." value="<?= htmlspecialchars($search) ?>">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-search"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Books Table -->
        <div class="stats-card">
            <?php if (empty($books)): ?>
                <div class="alert alert-info mb-0">
                    <i class="bi bi-info-circle me-2"></i>
                    Tidak ada buku ditemukan
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Cover</th>
                                <th>Title</th>
                                <th>Author</th>
                                <th>Writer</th>
                                <th>Price</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($books as $book): ?>
                            <tr>
                                <td>
                                    <?php if ($book['cover_image']): ?>
                                        <img src="<?= BOOK_COVER_URL . $book['cover_image'] ?>" 
                                             class="book-thumb" alt="Cover">
                                    <?php else: ?>
                                        <div class="book-thumb bg-light d-flex align-items-center justify-content-center">
                                            <i class="bi bi-book text-muted"></i>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <strong><?= htmlspecialchars($book['title']) ?></strong>
                                    <br><small class="text-muted"><?= htmlspecialchars($book['category_name']) ?></small>
                                </td>
                                <td><?= htmlspecialchars($book['author']) ?></td>
                                <td><?= htmlspecialchars($book['writer_name']) ?></td>
                                <td class="text-primary fw-bold"><?= formatRupiah($book['price']) ?></td>
                                <td>
                                    <?php
                                    $badges = [
                                        'pending' => 'warning',
                                        'approved' => 'success',
                                        'rejected' => 'danger'
                                    ];
                                    ?>
                                    <span class="badge bg-<?= $badges[$book['status']] ?>">
                                        <?= ucfirst($book['status']) ?>
                                    </span>
                                </td>
                                <td>
                                    <small><?= formatDateIndo($book['created_at']) ?></small>
                                </td>
                                <td>
                                    <?php if ($book['status'] === 'pending'): ?>
                                        <a href="book-review.php?id=<?= $book['id'] ?>" 
                                           class="btn btn-sm btn-primary">
                                            <i class="bi bi-eye"></i> Review
                                        </a>
                                    <?php else: ?>
                                        <a href="book-detail.php?id=<?= $book['id'] ?>" 
                                           class="btn btn-sm btn-outline-primary">
                                            <i class="bi bi-eye"></i> View
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>