<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireRole('admin');

$conn = getDBConnection();
$orderId = $_GET['id'] ?? 0;

// Get order details
$stmt = $conn->prepare("
    SELECT o.*, u.username, u.full_name, u.email
    FROM orders o
    JOIN users u ON o.customer_id = u.id
    WHERE o.id = ?
");
$stmt->execute([$orderId]);
$order = $stmt->fetch();

if (!$order) {
    echo '<div class="alert alert-danger">Order tidak ditemukan</div>';
    exit;
}

// Get order items
$stmt = $conn->prepare("
    SELECT oi.*, b.title, b.author, b.cover_image
    FROM order_items oi
    JOIN books b ON oi.book_id = b.id
    WHERE oi.order_id = ?
");
$stmt->execute([$orderId]);
$items = $stmt->fetchAll();
?>

<div class="row mb-3">
    <div class="col-md-6">
        <h6 class="text-muted">Order Number</h6>
        <p class="mb-0"><strong><?= htmlspecialchars($order['order_number']) ?></strong></p>
    </div>
    <div class="col-md-6">
        <h6 class="text-muted">Order Date</h6>
        <p class="mb-0"><?= formatDateTimeIndo($order['created_at']) ?></p>
    </div>
</div>

<hr>

<h6 class="mb-3">Customer Information</h6>
<div class="row mb-3">
    <div class="col-md-6">
        <p class="mb-1"><strong><?= htmlspecialchars($order['full_name']) ?></strong></p>
        <p class="mb-1 text-muted"><?= htmlspecialchars($order['email']) ?></p>
        <p class="mb-0 text-muted">@<?= htmlspecialchars($order['username']) ?></p>
    </div>
    <div class="col-md-6">
        <p class="mb-1"><?= htmlspecialchars($order['shipping_phone']) ?></p>
        <p class="mb-1"><?= htmlspecialchars($order['shipping_address']) ?></p>
        <p class="mb-0"><?= htmlspecialchars($order['shipping_city']) ?>, <?= htmlspecialchars($order['shipping_postal_code']) ?></p>
    </div>
</div>

<hr>

<h6 class="mb-3">Order Items (<?= count($items) ?>)</h6>
<?php foreach ($items as $item): ?>
<div class="d-flex align-items-center mb-3 pb-3 border-bottom">
    <div style="width: 50px; height: 70px; margin-right: 15px;">
        <?php if ($item['cover_image']): ?>
            <img src="<?= BOOK_COVER_URL . $item['cover_image'] ?>" 
                 style="width: 100%; height: 100%; object-fit: cover; border-radius: 5px;">
        <?php endif; ?>
    </div>
    <div class="flex-grow-1">
        <h6 class="mb-0"><?= htmlspecialchars($item['title']) ?></h6>
        <small class="text-muted"><?= htmlspecialchars($item['author']) ?></small>
        <br>
        <small class="text-muted">Qty: <?= $item['quantity'] ?> x <?= formatRupiah($item['price']) ?></small>
    </div>
    <div>
        <strong><?= formatRupiah($item['subtotal']) ?></strong>
    </div>
</div>
<?php endforeach; ?>

<div class="row mt-3">
    <div class="col-6">
        <p class="mb-1">Subtotal:</p>
        <p class="mb-1">Tax (<?= TAX_PERCENTAGE ?>%):</p>
        <p class="mb-1">Shipping:</p>
        <h6 class="mb-0 mt-2">Total:</h6>
    </div>
    <div class="col-6 text-end">
        <p class="mb-1"><?= formatRupiah($order['subtotal']) ?></p>
        <p class="mb-1"><?= formatRupiah($order['tax']) ?></p>
        <p class="mb-1"><span class="text-success">FREE</span></p>
        <h5 class="mb-0 mt-2 text-primary"><?= formatRupiah($order['total']) ?></h5>
    </div>
</div>

<hr>

<div class="row">
    <div class="col-6">
        <h6 class="text-muted">Payment Method</h6>
        <p class="mb-0"><?= ucwords(str_replace('_', ' ', $order['payment_method'])) ?></p>
    </div>
    <div class="col-6">
        <h6 class="text-muted">Payment Status</h6>
        <p class="mb-0">
            <?php
            $paymentBadge = [
                'pending' => 'warning',
                'paid' => 'success',
                'failed' => 'danger'
            ];
            ?>
            <span class="badge bg-<?= $paymentBadge[$order['payment_status']] ?>">
                <?= ucfirst($order['payment_status']) ?>
            </span>
        </p>
    </div>
</div>

<div class="row mt-3">
    <div class="col-6">
        <h6 class="text-muted">Order Status</h6>
        <p class="mb-0">
            <?php
            $statusBadge = [
                'pending' => 'secondary',
                'processing' => 'info',
                'shipped' => 'primary',
                'delivered' => 'success',
                'cancelled' => 'danger'
            ];
            ?>
            <span class="badge bg-<?= $statusBadge[$order['order_status']] ?>">
                <?= ucfirst($order['order_status']) ?>
            </span>
        </p>
    </div>
    <div class="col-6">
        <h6 class="text-muted">Delivery Method</h6>
        <p class="mb-0"><?= ucwords(str_replace('_', ' ', $order['shipping_method'])) ?></p>
    </div>
</div>

<?php if ($order['notes']): ?>
<hr>
<h6 class="text-muted">Order Notes</h6>
<p class="mb-0"><?= nl2br(htmlspecialchars($order['notes'])) ?></p>
<?php endif; ?>