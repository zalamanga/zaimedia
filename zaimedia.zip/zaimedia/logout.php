<?php
session_start();

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

logout(); // Ganti dari logoutUser() ke logout()

session_start(); // Start session baru untuk flash message
setFlash('success', 'Anda telah berhasil logout');
redirect('login.php');
?>