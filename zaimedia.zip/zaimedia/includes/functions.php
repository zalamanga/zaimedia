<?php

// ==========================================
// SESSION FUNCTIONS
// ==========================================

/**
 * Set flash message
 */
function setFlash($type, $message) {
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message
    ];
}

/**
 * Get and clear flash message
 */
function getFlash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}


/**
 * Register new user
 */
function registerUser($data) {
    $conn = getDBConnection();
    
    // Validate required fields
    if (empty($data['username']) || empty($data['email']) || empty($data['password'])) {
        return [
            'success' => false,
            'message' => 'Username, email, dan password harus diisi'
        ];
    }
    
    // Validate email format
    if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        return [
            'success' => false,
            'message' => 'Format email tidak valid'
        ];
    }
    
    // Validate password length
    if (strlen($data['password']) < 6) {
        return [
            'success' => false,
            'message' => 'Password minimal 6 karakter'
        ];
    }
    
    // Check if username already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$data['username']]);
    if ($stmt->fetch()) {
        return [
            'success' => false,
            'message' => 'Username sudah digunakan'
        ];
    }
    
    // Check if email already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$data['email']]);
    if ($stmt->fetch()) {
        return [
            'success' => false,
            'message' => 'Email sudah terdaftar'
        ];
    }
    
    // Hash password
    $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
    
    // Insert user
    try {
        $stmt = $conn->prepare("
            INSERT INTO users (username, email, password, full_name, phone, role, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $result = $stmt->execute([
            $data['username'],
            $data['email'],
            $hashedPassword,
            $data['full_name'],
            $data['phone'] ?? '',
            $data['role'] ?? 'customer'
        ]);
        
        if ($result) {
            return [
                'success' => true,
                'message' => 'Registrasi berhasil!',
                'user_id' => $conn->lastInsertId()
            ];
        } else {
            return [
                'success' => false,
                'message' => 'Gagal mendaftar. Silakan coba lagi'
            ];
        }
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => 'Error: ' . $e->getMessage()
        ];
    }
}
// ==========================================
// REDIRECT FUNCTION
// ==========================================

/**
 * Redirect to URL
 */
function redirect($url) {
    header('Location: ' . $url);
    exit;
}

// ==========================================
// SANITIZE INPUT
// ==========================================

/**
 * Sanitize user input
 */
function sanitize($input) {
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

// ==========================================
// FORMAT FUNCTIONS
// ==========================================

/**
 * Format number to Rupiah
 */
function formatRupiah($number) {
    // Handle null or empty values
    if ($number === null || $number === '') {
        $number = 0;
    }
    
    // Convert to float
    $number = (float)$number;
    
    return 'Rp ' . number_format($number, 0, ',', '.');
}

/**
 * Format date to Indonesian
 */
function formatDateIndo($date) {
    $months = [
        1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
        5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
        9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
    ];
    
    $timestamp = strtotime($date);
    $day = date('d', $timestamp);
    $month = $months[(int)date('m', $timestamp)];
    $year = date('Y', $timestamp);
    
    return $day . ' ' . $month . ' ' . $year;
}

/**
 * Format datetime to Indonesian
 */
function formatDateTimeIndo($datetime) {
    $months = [
        1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
        5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
        9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
    ];
    
    $timestamp = strtotime($datetime);
    $day = date('d', $timestamp);
    $month = $months[(int)date('m', $timestamp)];
    $year = date('Y', $timestamp);
    $time = date('H:i', $timestamp);
    
    return $day . ' ' . $month . ' ' . $year . ' ' . $time;
}

/**
 * Time ago function
 */
function timeAgo($datetime) {
    $timestamp = strtotime($datetime);
    $diff = time() - $timestamp;
    
    if ($diff < 60) {
        return $diff . ' detik yang lalu';
    } elseif ($diff < 3600) {
        $minutes = floor($diff / 60);
        return $minutes . ' menit yang lalu';
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . ' jam yang lalu';
    } elseif ($diff < 604800) {
        $days = floor($diff / 86400);
        return $days . ' hari yang lalu';
    } elseif ($diff < 2592000) {
        $weeks = floor($diff / 604800);
        return $weeks . ' minggu yang lalu';
    } elseif ($diff < 31536000) {
        $months = floor($diff / 2592000);
        return $months . ' bulan yang lalu';
    } else {
        $years = floor($diff / 31536000);
        return $years . ' tahun yang lalu';
    }
}

/**
 * Truncate text
 */
function truncateText($text, $length = 50, $suffix = '...') {
    if (strlen($text) <= $length) {
        return $text;
    }
    return substr($text, 0, $length) . $suffix;
}

// ==========================================
// CALCULATION FUNCTIONS
// ==========================================

/**
 * Calculate tax
 */
function calculateTax($amount) {
    return $amount * (TAX_PERCENTAGE / 100);
}

/**
 * Calculate royalty for writer
 */
function calculateRoyalty($bookPrice, $quantity = 1) {
    $subtotal = $bookPrice * $quantity;
    return $subtotal * (DEFAULT_ROYALTY_PERCENTAGE / 100);
}

/**
 * Calculate percentage
 */
function calculatePercentage($value, $total) {
    if ($total == 0) return 0;
    return round(($value / $total) * 100, 2);
}

// ==========================================
// GENERATE FUNCTIONS
// ==========================================

/**
 * Generate unique order number
 */
function generateOrderNumber() {
    return 'ORD-' . date('Ymd') . '-' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 6));
}

/**
 * Generate unique withdrawal code
 */
function generateWithdrawalCode() {
    return 'WD-' . date('Ymd') . '-' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 6));
}

/**
 * Generate unique withdrawal number (alias for generateWithdrawalCode)
 */
function generateWithdrawalNumber() {
    return generateWithdrawalCode();
}

/**
 * Generate random string
 */
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

// ==========================================
// FILE UPLOAD FUNCTIONS
// ==========================================

/**
 * Upload book cover image
 */
function uploadBookCover($file) {
    $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
    $maxSize = 5 * 1024 * 1024; // 5MB
    
    // Validate file type
    if (!in_array($file['type'], $allowedTypes)) {
        return [
            'success' => false,
            'error' => 'Invalid file type. Only JPG, PNG, and GIF are allowed.'
        ];
    }
    
    // Validate file size
    if ($file['size'] > $maxSize) {
        return [
            'success' => false,
            'error' => 'File size too large. Maximum 5MB.'
        ];
    }
    
    // Generate unique filename
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = 'cover_' . time() . '_' . uniqid() . '.' . $extension;
    $uploadPath = BOOK_COVER_PATH . $filename;
    
    // Create directory if not exists
    if (!file_exists(BOOK_COVER_PATH)) {
        mkdir(BOOK_COVER_PATH, 0755, true);
    }
    
    // Move uploaded file
    if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
        return [
            'success' => true,
            'filename' => $filename
        ];
    } else {
        return [
            'success' => false,
            'error' => 'Failed to upload file.'
        ];
    }
}

/**
 * Upload book PDF file
 */
function uploadBookPDF($file) {
    $allowedTypes = ['application/pdf'];
    $maxSize = 50 * 1024 * 1024; // 50MB
    
    // Validate file type
    if (!in_array($file['type'], $allowedTypes)) {
        return [
            'success' => false,
            'error' => 'Invalid file type. Only PDF is allowed.'
        ];
    }
    
    // Validate file size
    if ($file['size'] > $maxSize) {
        return [
            'success' => false,
            'error' => 'File size too large. Maximum 50MB.'
        ];
    }
    
    // Generate unique filename
    $filename = 'book_' . time() . '_' . uniqid() . '.pdf';
    $uploadPath = BOOK_PDF_PATH . $filename;
    
    // Create directory if not exists
    if (!file_exists(BOOK_PDF_PATH)) {
        mkdir(BOOK_PDF_PATH, 0755, true);
    }
    
    // Move uploaded file
    if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
        return [
            'success' => true,
            'filename' => $filename
        ];
    } else {
        return [
            'success' => false,
            'error' => 'Failed to upload file.'
        ];
    }
}

/**
 * Check if file is image
 */
function isImage($file) {
    $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
    return in_array($file['type'], $allowedTypes);
}

/**
 * Check if file is PDF
 */
function isPDF($file) {
    return $file['type'] === 'application/pdf';
}

// ==========================================
// USER FUNCTIONS
// ==========================================

/**
 * Get current user info
 */
function getCurrentUser() {
    if (!isset($_SESSION['user_id'])) {
        return null;
    }
    
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch();
}

/**
 * Check if user is logged in
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * Validate email format
 */
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Get user role badge class
 */
function getRoleBadgeClass($role) {
    $badges = [
        'admin' => 'danger',
        'writer' => 'primary',
        'customer' => 'secondary'
    ];
    return $badges[$role] ?? 'secondary';
}

// ==========================================
// ORDER & PAYMENT FUNCTIONS
// ==========================================

/**
 * Get order status badge class
 */
function getOrderStatusBadge($status) {
    $badges = [
        'pending' => 'secondary',
        'processing' => 'info',
        'shipped' => 'primary',
        'delivered' => 'success',
        'cancelled' => 'danger'
    ];
    return $badges[$status] ?? 'secondary';
}

/**
 * Get payment status badge class
 */
function getPaymentStatusBadge($status) {
    $badges = [
        'pending' => 'warning',
        'paid' => 'success',
        'failed' => 'danger'
    ];
    return $badges[$status] ?? 'secondary';
}

// ==========================================
// BOOK FUNCTIONS
// ==========================================

/**
 * Get books with filters
 */
function getBooks($filters = []) {
    $conn = getDBConnection();
    
    $sql = "
        SELECT b.*, c.name as category_name, u.full_name as writer_name, u.username as writer_username
        FROM books b
        LEFT JOIN categories c ON b.category_id = c.id
        LEFT JOIN users u ON b.writer_id = u.id
        WHERE 1=1
    ";
    
    $params = [];
    
    // Filter by status
    if (isset($filters['status'])) {
        $sql .= " AND b.status = ?";
        $params[] = $filters['status'];
    }
    
    // Filter by category
    if (isset($filters['category_id'])) {
        $sql .= " AND b.category_id = ?";
        $params[] = $filters['category_id'];
    }
    
    // Filter by writer
    if (isset($filters['writer_id'])) {
        $sql .= " AND b.writer_id = ?";
        $params[] = $filters['writer_id'];
    }
    
    // Search
    if (isset($filters['search']) && !empty($filters['search'])) {
        $sql .= " AND (b.title LIKE ? OR b.author LIKE ? OR b.publisher LIKE ?)";
        $searchTerm = '%' . $filters['search'] . '%';
        $params[] = $searchTerm;
        $params[] = $searchTerm;
        $params[] = $searchTerm;
    }
    
    // Order by
    $orderBy = $filters['order_by'] ?? 'b.created_at';
    $orderDir = $filters['order_dir'] ?? 'DESC';
    $sql .= " ORDER BY $orderBy $orderDir";
    
    // Limit
    if (isset($filters['limit'])) {
        $sql .= " LIMIT " . (int)$filters['limit'];
    }
    
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

/**
 * Get single book by ID
 */
function getBook($bookId) {
    $conn = getDBConnection();
    
    $stmt = $conn->prepare("
        SELECT b.*, 
               c.name as category_name,
               u.full_name as writer_name,
               u.username as writer_username,
               u.email as writer_email
        FROM books b
        LEFT JOIN categories c ON b.category_id = c.id
        LEFT JOIN users u ON b.writer_id = u.id
        WHERE b.id = ?
    ");
    
    $stmt->execute([$bookId]);
    return $stmt->fetch();
}

/**
 * Get book status label
 */
function getBookStatusLabel($status) {
    $labels = [
        'pending' => 'Pending Review',
        'approved' => 'Approved',
        'rejected' => 'Rejected'
    ];
    return $labels[$status] ?? $status;
}

/**
 * Get average rating
 */
function getAverageRating($bookId) {
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT AVG(rating) as avg_rating FROM reviews WHERE book_id = ?");
    $stmt->execute([$bookId]);
    $result = $stmt->fetch();
    return round($result['avg_rating'] ?? 0, 1);
}

/**
 * Get total reviews
 */
function getTotalReviews($bookId) {
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT COUNT(*) FROM reviews WHERE book_id = ?");
    $stmt->execute([$bookId]);
    return $stmt->fetchColumn();
}

// ==========================================
// WITHDRAWAL FUNCTIONS
// ==========================================

/**
 * Get withdrawal status label
 */
function getWithdrawalStatusLabel($status) {
    $labels = [
        'pending' => 'Pending',
        'approved' => 'Approved',
        'completed' => 'Completed',
        'rejected' => 'Rejected'
    ];
    return $labels[$status] ?? $status;
}

/**
 * Get withdrawal status badge
 */
function getWithdrawalStatusBadge($status) {
    $badges = [
        'pending' => 'warning',
        'approved' => 'info',
        'completed' => 'success',
        'rejected' => 'danger'
    ];
    return $badges[$status] ?? 'secondary';
}

// ==========================================
// UTILITY FUNCTIONS
// ==========================================

/**
 * Format file size
 */
function formatFileSize($bytes) {
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    } else {
        return $bytes . ' bytes';
    }
}

/**
 * Format number with separator
 */
function formatNumber($number) {
    return number_format($number, 0, ',', '.');
}

/**
 * Get month name in Indonesian
 */
function getMonthNameIndo($month) {
    $months = [
        1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
        5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
        9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
    ];
    return $months[(int)$month] ?? '';
}

/**
 * Get day name in Indonesian
 */
function getDayNameIndo($day) {
    $days = [
        'Sunday' => 'Minggu',
        'Monday' => 'Senin',
        'Tuesday' => 'Selasa',
        'Wednesday' => 'Rabu',
        'Thursday' => 'Kamis',
        'Friday' => 'Jumat',
        'Saturday' => 'Sabtu'
    ];
    return $days[$day] ?? $day;
}

/**
 * Clean old files (untuk maintenance)
 */
function cleanOldFiles($directory, $days = 30) {
    $files = glob($directory . '*');
    $now = time();
    $deleted = 0;
    
    foreach ($files as $file) {
        if (is_file($file)) {
            if ($now - filemtime($file) >= 60 * 60 * 24 * $days) {
                unlink($file);
                $deleted++;
            }
        }
    }
    
    return $deleted;
}

/**
 * Get pagination HTML
 */
function getPagination($currentPage, $totalPages, $url) {
    if ($totalPages <= 1) {
        return '';
    }
    
    $html = '<nav><ul class="pagination justify-content-center">';
    
    // Previous button
    if ($currentPage > 1) {
        $html .= '<li class="page-item"><a class="page-link" href="' . $url . '?page=' . ($currentPage - 1) . '">Previous</a></li>';
    } else {
        $html .= '<li class="page-item disabled"><span class="page-link">Previous</span></li>';
    }
    
    // Page numbers
    for ($i = 1; $i <= $totalPages; $i++) {
        if ($i == $currentPage) {
            $html .= '<li class="page-item active"><span class="page-link">' . $i . '</span></li>';
        } else {
            $html .= '<li class="page-item"><a class="page-link" href="' . $url . '?page=' . $i . '">' . $i . '</a></li>';
        }
    }
    
    // Next button
    if ($currentPage < $totalPages) {
        $html .= '<li class="page-item"><a class="page-link" href="' . $url . '?page=' . ($currentPage + 1) . '">Next</a></li>';
    } else {
        $html .= '<li class="page-item disabled"><span class="page-link">Next</span></li>';
    }
    
    $html .= '</ul></nav>';
    
    return $html;
}

// ==========================================
// EMAIL & NOTIFICATION FUNCTIONS
// ==========================================

/**
 * Send email notification (placeholder)
 */
function sendEmail($to, $subject, $message) {
    // TODO: Implement actual email sending using PHPMailer
    // For now, just log to file
    $logFile = __DIR__ . '/../logs/email.log';
    $logDir = dirname($logFile);
    
    if (!file_exists($logDir)) {
        mkdir($logDir, 0755, true);
    }
    
    $log = "[" . date('Y-m-d H:i:s') . "] To: $to | Subject: $subject | Message: $message\n";
    file_put_contents($logFile, $log, FILE_APPEND);
    
    return true;
}

/**
 * Log activity (untuk audit trail)
 */
function logActivity($userId, $action, $description) {
    $conn = getDBConnection();
    
    try {
        $stmt = $conn->prepare("
            INSERT INTO activity_logs (user_id, action, description, ip_address, user_agent, created_at)
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        
        $stmt->execute([
            $userId,
            $action,
            $description,
            $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
        ]);
        
        return true;
    } catch (Exception $e) {
        // Silently fail logging
        return false;
    }
}

// ==========================================
// CART FUNCTIONS
// ==========================================

/**
 * Get cart item count
 */
function getCartItemCount() {
    if (!isset($_SESSION['user_id'])) {
        return 0;
    }
    
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT COUNT(*) FROM cart WHERE customer_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetchColumn();
}

/**
 * Get cart total
 */
function getCartTotal() {
    if (!isset($_SESSION['user_id'])) {
        return 0;
    }
    
    $conn = getDBConnection();
    $stmt = $conn->prepare("
        SELECT SUM(b.price * c.quantity) 
        FROM cart c
        JOIN books b ON c.book_id = b.id
        WHERE c.customer_id = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetchColumn() ?? 0;
}

// ==========================================
// DEBUG HELPER
// ==========================================

/**
 * Debug helper - dump and die
 */
function dd($var) {
    echo '<pre>';
    var_dump($var);
    echo '</pre>';
    die();
}

/**
 * Debug helper - dump without die
 */
function dump($var) {
    echo '<pre>';
    var_dump($var);
    echo '</pre>';
}