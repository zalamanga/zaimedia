<?php

/**
 * Check if user is logged in
 */
function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        setFlash('error', 'Silakan login terlebih dahulu');
        redirect(BASE_URL . 'login.php');
    }
}

/**
 * Login user with email and password
 */
function loginUser($email, $password) {
    $conn = getDBConnection();
    
    // Get user by email
    $user = getUserByEmail($email);
    
    // Check if user exists
    if (!$user) {
        return [
            'success' => false,
            'message' => 'Email atau password salah'
        ];
    }
    
    // Check if user is active
    if (!isUserActive($user['id'])) {
        return [
            'success' => false,
            'message' => 'Akun Anda tidak aktif. Silakan hubungi administrator.'
        ];
    }
    
    // Verify password
    if (!verifyPassword($password, $user['password'])) {
        return [
            'success' => false,
            'message' => 'Email atau password salah'
        ];
    }
    
    // Set session
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['login_time'] = time();
    
    
    return [
        'success' => true,
        'message' => 'Login berhasil',
        'user' => $user
    ];
}

/**
 * Check if user has specific role
 */
function requireRole($role) {
    requireLogin();
    
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT role FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    
    if (!$user || $user['role'] !== $role) {
        setFlash('error', 'Akses ditolak. Anda tidak memiliki permission.');
        redirect(BASE_URL . '403.php');
    }
}

/**
 * Check if user has one of multiple roles
 */
function requireRoles($roles) {
    requireLogin();
    
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT role FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    
    if (!$user || !in_array($user['role'], $roles)) {
        setFlash('error', 'Akses ditolak. Anda tidak memiliki permission.');
        redirect(BASE_URL . '403.php');
    }
}

/**
 * Check if user has specific role (returns boolean)
 */
function hasRole($role) {
    if (!isset($_SESSION['user_id'])) {
        return false;
    }
    
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT role FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    
    return $user && $user['role'] === $role;
}

/**
 * Check if user is admin
 */
function isAdmin() {
    return hasRole('admin');
}

/**
 * Check if user is writer
 */
function isWriter() {
    return hasRole('writer');
}

/**
 * Check if user is customer
 */
function isCustomer() {
    return hasRole('customer');
}

/**
 * Get current user's role
 */
function getCurrentRole() {
    if (!isset($_SESSION['user_id'])) {
        return null;
    }
    
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT role FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    
    return $user ? $user['role'] : null;
}

/**
 * Redirect based on user role
 */
function redirectByRole() {
    $role = getCurrentRole();
    
    if (!$role) {
        redirect(BASE_URL . 'login.php');
    }
    
    switch ($role) {
        case 'admin':
            redirect(BASE_URL . 'admin/dashboard.php');
            break;
        case 'writer':
            redirect(BASE_URL . 'writer/dashboard.php');
            break;
        case 'customer':
            redirect(BASE_URL . 'customer/dashboard.php');
            break;
        default:
            redirect(BASE_URL . 'index.php');
    }
}

/**
 * Check if user can access a resource
 */
function canAccess($resource, $userId = null) {
    if (!$userId) {
        $userId = $_SESSION['user_id'] ?? null;
    }
    
    if (!$userId) {
        return false;
    }
    
    // Admin can access everything
    if (isAdmin()) {
        return true;
    }
    
    // Add more specific access control logic here
    return false;
}

/**
 * Get user permissions
 */
function getUserPermissions() {
    $role = getCurrentRole();
    
    $permissions = [
        'admin' => [
            'manage_books',
            'manage_users',
            'manage_orders',
            'manage_withdrawals',
            'manage_categories',
            'view_all_data'
        ],
        'writer' => [
            'create_books',
            'edit_own_books',
            'view_own_books',
            'request_withdrawal',
            'view_royalty'
        ],
        'customer' => [
            'view_books',
            'purchase_books',
            'view_own_orders',
            'download_books',
            'write_reviews'
        ]
    ];
    
    return $permissions[$role] ?? [];
}

/**
 * Check if user has permission
 */
function hasPermission($permission) {
    $userPermissions = getUserPermissions();
    return in_array($permission, $userPermissions);
}

/**
 * Prevent logged in users from accessing auth pages
 */
function preventAuthAccess() {
    if (isset($_SESSION['user_id'])) {
        redirectByRole();
    }
}

/**
 * Auto login after registration
 */
function autoLogin($userId) {
    $_SESSION['user_id'] = $userId;
    $_SESSION['login_time'] = time();
}

/**
 * Logout user
 */
function logout() {
    // Destroy all session data
    $_SESSION = array();
    
    // Delete session cookie
    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time()-42000, '/');
    }
    
    // Destroy session
    session_destroy();
}

/**
 * Check session timeout
 */
function checkSessionTimeout($timeout = 7200) {
    if (isset($_SESSION['login_time'])) {
        $elapsed = time() - $_SESSION['login_time'];
        
        if ($elapsed > $timeout) {
            setFlash('error', 'Session Anda telah berakhir. Silakan login kembali.');
            logout();
            redirect(BASE_URL . 'login.php');
        }
        
        // Update login time
        $_SESSION['login_time'] = time();
    }
}

/**
 * Remember user login
 */
function rememberLogin($userId, $days = 30) {
    $token = bin2hex(random_bytes(32));
    $expiry = time() + ($days * 24 * 60 * 60);
    
    // Store token in database
    $conn = getDBConnection();
    $stmt = $conn->prepare("
        INSERT INTO remember_tokens (user_id, token, expires_at)
        VALUES (?, ?, FROM_UNIXTIME(?))
    ");
    $stmt->execute([$userId, hash('sha256', $token), $expiry]);
    
    // Set cookie
    setcookie('remember_token', $token, $expiry, '/', '', true, true);
}

/**
 * Check remember token
 */
function checkRememberToken() {
    if (isset($_COOKIE['remember_token']) && !isset($_SESSION['user_id'])) {
        $token = $_COOKIE['remember_token'];
        $hashedToken = hash('sha256', $token);
        
        $conn = getDBConnection();
        $stmt = $conn->prepare("
            SELECT user_id FROM remember_tokens 
            WHERE token = ? AND expires_at > NOW()
        ");
        $stmt->execute([$hashedToken]);
        $result = $stmt->fetch();
        
        if ($result) {
            $_SESSION['user_id'] = $result['user_id'];
            $_SESSION['login_time'] = time();
            return true;
        } else {
            // Invalid or expired token, delete cookie
            setcookie('remember_token', '', time()-42000, '/');
        }
    }
    
    return false;
}

/**
 * Validate password strength
 */
function validatePasswordStrength($password) {
    $errors = [];
    
    if (strlen($password) < 6) {
        $errors[] = 'Password minimal 6 karakter';
    }
    
    // Add more validation rules as needed
    
    return [
        'valid' => empty($errors),
        'errors' => $errors
    ];
}

/**
 * Generate secure password hash
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

/**
 * Verify password
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Check if email exists
 */
function emailExists($email) {
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    return $stmt->fetch() !== false;
}

/**
 * Check if username exists
 */
function usernameExists($username) {
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$username]);
    return $stmt->fetch() !== false;
}

/**
 * Get user by email
 */
function getUserByEmail($email) {
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    return $stmt->fetch();
}

/**
 * Get user by username
 */
function getUserByUsername($username) {
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    return $stmt->fetch();
}

/**
 * Get user by ID
 */
function getUserById($id) {
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

/**
 * Update user last login
 */
function updateLastLogin($userId) {
    $conn = getDBConnection();
    $stmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
    $stmt->execute([$userId]);
}

/**
 * Check if user is active
 */
function isUserActive($userId) {
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT status FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    
    return $user && $user['status'] === 'active';
}

/**
 * Suspend user account
 */
function suspendUser($userId, $reason = null) {
    $conn = getDBConnection();
    $stmt = $conn->prepare("UPDATE users SET status = 'suspended' WHERE id = ?");
    return $stmt->execute([$userId]);
}

/**
 * Activate user account
 */
function activateUser($userId) {
    $conn = getDBConnection();
    $stmt = $conn->prepare("UPDATE users SET status = 'active' WHERE id = ?");
    return $stmt->execute([$userId]);
}

/**
 * Ban user account
 */
function banUser($userId, $reason = null) {
    $conn = getDBConnection();
    $stmt = $conn->prepare("UPDATE users SET status = 'banned' WHERE id = ?");
    return $stmt->execute([$userId]);
}