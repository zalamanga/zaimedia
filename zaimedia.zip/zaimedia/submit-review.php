<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Check if user is logged in
if (!isLoggedIn()) {
    setFlash('error', 'Anda harus login terlebih dahulu');
    redirect('login.php');
}

$currentUser = getCurrentUser();

// Only customer can submit review
if ($currentUser['role'] !== 'customer') {
    setFlash('error', 'Hanya customer yang dapat memberikan review');
    redirect('index.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bookId = $_POST['book_id'] ?? 0;
    $rating = $_POST['rating'] ?? 0;
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    
    // Validation
    $errors = [];
    
    if (empty($bookId) || $bookId <= 0) {
        $errors[] = 'Buku tidak valid';
    }
    
    if (empty($rating) || $rating < 1 || $rating > 5) {
        $errors[] = 'Rating harus antara 1-5 bintang';
    }
    
    if (empty($content)) {
        $errors[] = 'Konten review tidak boleh kosong';
    } elseif (strlen($content) < 10) {
        $errors[] = 'Konten review minimal 10 karakter';
    }
    
    if (!empty($errors)) {
        setFlash('error', implode('<br>', $errors));
        redirect('book-detail.php?id=' . $bookId . '#write-review');
    }
    
    try {
        $conn = getDBConnection();
        
        // Check if book exists
        $stmt = $conn->prepare("SELECT id, status FROM books WHERE id = ?");
        $stmt->execute([$bookId]);
        $book = $stmt->fetch();
        
        if (!$book || $book['status'] !== 'approved') {
            setFlash('error', 'Buku tidak ditemukan');
            redirect('index.php');
        }
        
        // Check if user already reviewed this book
        $stmt = $conn->prepare("SELECT id FROM reviews WHERE book_id = ? AND customer_id = ?");
        $stmt->execute([$bookId, $currentUser['id']]);
        $existingReview = $stmt->fetch();
        
        if ($existingReview) {
            setFlash('error', 'Anda sudah memberikan review untuk buku ini');
            redirect('book-detail.php?id=' . $bookId . '#reviews-section');
        }
        
        // Check if user has purchased this book (verified purchase)
        $stmt = $conn->prepare("
            SELECT oi.id 
            FROM order_items oi
            JOIN orders o ON oi.order_id = o.id
            WHERE oi.book_id = ? 
            AND o.customer_id = ? 
            AND o.payment_status = 'paid'
            LIMIT 1
        ");
        $stmt->execute([$bookId, $currentUser['id']]);
        $hasPurchased = $stmt->fetch();
        $isVerified = $hasPurchased ? 1 : 0;
        
        // Insert review
        $stmt = $conn->prepare("
            INSERT INTO reviews (book_id, customer_id, rating, title, content, is_verified, created_at)
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $stmt->execute([
            $bookId,
            $currentUser['id'],
            $rating,
            $title,
            $content,
            $isVerified
        ]);
        
        setFlash('success', 'Terima kasih! Review Anda telah berhasil dikirim');
        redirect('book-detail.php?id=' . $bookId . '#reviews-section');
        
    } catch (PDOException $e) {
        error_log("Review submission error: " . $e->getMessage());
        setFlash('error', 'Terjadi kesalahan saat mengirim review');
        redirect('book-detail.php?id=' . $bookId . '#write-review');
    }
} else {
    redirect('index.php');
}