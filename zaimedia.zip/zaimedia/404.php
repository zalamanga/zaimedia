<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Page Not Found - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .error-container {
            text-align: center;
            color: white;
        }
        .error-code {
            font-size: 150px;
            font-weight: bold;
            line-height: 1;
            text-shadow: 0 5px 20px rgba(0,0,0,0.3);
        }
        .error-icon {
            font-size: 100px;
            margin-bottom: 30px;
        }
        .error-card {
            background: white;
            border-radius: 20px;
            padding: 50px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            color: #333;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="error-container">
            <div class="error-card">
                <i class="bi bi-exclamation-triangle error-icon text-warning"></i>
                <h1 class="error-code">404</h1>
                <h3 class="mb-4">Page Not Found</h3>
                <p class="text-muted mb-4">
                    Maaf, halaman yang Anda cari tidak ditemukan.
                    <br>Mungkin halaman telah dipindahkan atau dihapus.
                </p>
                <div class="d-flex gap-3 justify-content-center">
                    <a href="index.php" class="btn btn-primary btn-lg">
                        <i class="bi bi-house me-2"></i> Back to Home
                    </a>
                    <a href="javascript:history.back()" class="btn btn-outline-secondary btn-lg">
                        <i class="bi bi-arrow-left me-2"></i> Go Back
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>