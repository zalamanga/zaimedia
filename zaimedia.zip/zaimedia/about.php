<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';

// Get categories for navbar
$conn = getDBConnection();
$stmt = $conn->query("SELECT * FROM categories ORDER BY name");
$categories = $stmt->fetchAll();

// Get flash message
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .navbar {
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .hero-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 100px 0;
        }

        .about-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
            height: 100%;
            transition: transform 0.3s;
        }

        .about-card:hover {
            transform: translateY(-5px);
        }

        .icon-box {
            width: 80px;
            height: 80px;
            border-radius: 15px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 32px;
            margin-bottom: 20px;
        }

        .stats-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 80px 0;
        }

        .stat-box {
            text-align: center;
        }

        .stat-number {
            font-size: 48px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        footer {
            background: #2c3e50;
            color: white;
            padding: 40px 0;
            margin-top: 80px;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold fs-4" href="index.php">
                <i class="bi bi-book-fill text-primary me-2"></i>ZaiMedia
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="books.php">Books</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                            Categories
                        </a>
                        <ul class="dropdown-menu">
                            <?php foreach ($categories as $cat): ?>
                            <li>
                                <a class="dropdown-item" href="books.php?category=<?= $cat['id'] ?>">
                                    <?= htmlspecialchars($cat['name']) ?>
                                </a>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="about.php">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                </ul>
                <div class="d-flex align-items-center gap-3">
                    <?php if (isLoggedIn()): ?>
                        <?php $currentUser = getCurrentUser(); ?>
                        <div class="dropdown">
                            <a class="btn btn-outline-primary dropdown-toggle" href="#" data-bs-toggle="dropdown">
                                <i class="bi bi-person-circle me-2"></i>
                                <?= htmlspecialchars($currentUser['username']) ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <?php if ($currentUser['role'] === 'admin'): ?>
                                    <li><a class="dropdown-item" href="admin/dashboard.php">
                                        <i class="bi bi-speedometer2 me-2"></i> Admin Dashboard
                                    </a></li>
                                <?php elseif ($currentUser['role'] === 'writer'): ?>
                                    <li><a class="dropdown-item" href="writer/dashboard.php">
                                        <i class="bi bi-book me-2"></i> Writer Dashboard
                                    </a></li>
                                <?php else: ?>
                                    <li><a class="dropdown-item" href="customer/dashboard.php">
                                        <i class="bi bi-person me-2"></i> My Account
                                    </a></li>
                                <?php endif; ?>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="logout.php">
                                    <i class="bi bi-box-arrow-right me-2"></i> Logout
                                </a></li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-outline-primary">
                            <i class="bi bi-box-arrow-in-right me-2"></i> Login
                        </a>
                        <a href="register.php" class="btn btn-primary">
                            <i class="bi bi-person-plus me-2"></i> Register
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <?php if ($flash): ?>
    <div class="container mt-3">
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
            <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    </div>
    <?php endif; ?>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h1 class="display-4 fw-bold mb-4">Tentang ZaiMedia</h1>
                    <p class="lead mb-4">Platform toko buku online terpercaya yang menghadirkan ribuan koleksi buku
                        berkualitas untuk menambah wawasan dan pengetahuan Anda.</p>
                    <a href="books.php" class="btn btn-light btn-lg px-5">
                        <i class="bi bi-book me-2"></i>Jelajahi Koleksi
                    </a>
                </div>
                <div class="col-lg-6 text-center d-none d-lg-block">
                    <i class="bi bi-book-half" style="font-size: 200px;"></i>
                </div>
            </div>
        </div>
    </section>

    <!-- Our Story -->
    <section class="py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 mb-4">
                    <h2 class="mb-4">Cerita Kami</h2>
                    <p class="text-muted mb-3">ZaiMedia didirikan pada tahun 2020 dengan visi untuk menjadikan buku
                        lebih mudah diakses oleh semua kalangan masyarakat Indonesia. Kami percaya bahwa membaca adalah
                        kunci untuk membuka pintu pengetahuan dan mengembangkan diri.</p>
                    <p class="text-muted mb-3">Berawal dari sebuah toko buku kecil, kini ZaiMedia telah berkembang
                        menjadi platform online dengan ribuan koleksi buku dari berbagai genre dan penulis terbaik, baik
                        lokal maupun internasional.</p>
                    <p class="text-muted">Kami berkomitmen untuk terus memberikan pelayanan terbaik dan menghadirkan
                        buku-buku berkualitas dengan harga terjangkau untuk semua pembaca di Indonesia.</p>
                </div>
                <div class="col-lg-6">
                    <div style="width: 100%; height: 400px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 15px; display: flex; align-items: center; justify-content: center; color: white; font-size: 100px;">
                        <i class="bi bi-book"></i>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Our Values -->
    <section class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-5">Nilai-Nilai Kami</h2>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="about-card text-center">
                        <div class="icon-box mx-auto">
                            <i class="bi bi-shield-check"></i>
                        </div>
                        <h4 class="mb-3">Terpercaya</h4>
                        <p class="text-muted">Kami menjamin keaslian setiap buku yang dijual dan memberikan garansi
                            kepuasan pelanggan.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="about-card text-center">
                        <div class="icon-box mx-auto">
                            <i class="bi bi-heart"></i>
                        </div>
                        <h4 class="mb-3">Peduli</h4>
                        <p class="text-muted">Kami peduli dengan kebutuhan pembaca dan selalu siap membantu dalam
                            memberikan rekomendasi buku terbaik.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="about-card text-center">
                        <div class="icon-box mx-auto">
                            <i class="bi bi-lightning"></i>
                        </div>
                        <h4 class="mb-3">Inovatif</h4>
                        <p class="text-muted">Terus berinovasi dalam menghadirkan pengalaman berbelanja buku yang mudah
                            dan menyenangkan.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Statistics -->
    <section class="stats-section">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="stat-box">
                        <div class="stat-number">5000+</div>
                        <p class="mb-0">Koleksi Buku</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-box">
                        <div class="stat-number">50K+</div>
                        <p class="mb-0">Pembaca Puas</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-box">
                        <div class="stat-number">200+</div>
                        <p class="mb-0">Penulis Partner</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-box">
                        <div class="stat-number">4.8</div>
                        <p class="mb-0">Rating Pelanggan</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="py-5 bg-light">
        <div class="container text-center">
            <h2 class="mb-4">Siap Memulai Petualangan Membaca?</h2>
            <p class="lead text-muted mb-4">Jelajahi ribuan koleksi buku kami dan temukan bacaan favorit Anda</p>
            <a href="books.php" class="btn btn-primary btn-lg me-3 px-5">Lihat Koleksi Buku</a>
            <a href="contact.php" class="btn btn-outline-primary btn-lg px-5">Hubungi Kami</a>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h5 class="fw-bold mb-3">
                        <i class="bi bi-book-fill me-2"></i>ZaiMedia
                    </h5>
                    <p class="text-light">Platform toko buku online terpercaya dengan koleksi lengkap dan harga terjangkau.</p>
                </div>
                <div class="col-md-4 mb-4">
                    <h5 class="fw-bold mb-3">Quick Links</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="index.php" class="text-light text-decoration-none">Home</a></li>
                        <li class="mb-2"><a href="books.php" class="text-light text-decoration-none">Books</a></li>
                        <li class="mb-2"><a href="about.php" class="text-light text-decoration-none">About</a></li>
                        <li class="mb-2"><a href="contact.php" class="text-light text-decoration-none">Contact</a></li>
                    </ul>
                </div>
                <div class="col-md-4 mb-4">
                    <h5 class="fw-bold mb-3">Contact</h5>
                    <ul class="list-unstyled text-light">
                        <li class="mb-2"><i class="bi bi-envelope me-2"></i> info@zaimedia.com</li>
                        <li class="mb-2"><i class="bi bi-phone me-2"></i> +62 812-3456-7890</li>
                        <li class="mb-2"><i class="bi bi-geo-alt me-2"></i> Jakarta, Indonesia</li>
                    </ul>
                </div>
            </div>
            <hr class="bg-light">
            <div class="text-center text-light">
                <p class="mb-0">&copy; 2024 ZaiMedia Bookstore. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>