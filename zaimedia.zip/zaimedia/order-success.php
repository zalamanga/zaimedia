<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

requireLogin();

$conn = getDBConnection();
$customerId = $_SESSION['user_id'];
$orderNumber = $_GET['order'] ?? '';

// Get order details
$stmt = $conn->prepare("
    SELECT * FROM orders 
    WHERE order_number = ? AND customer_id = ?
");
$stmt->execute([$orderNumber, $customerId]);
$order = $stmt->fetch();

if (!$order) {
    setFlash('error', 'Order tidak ditemukan');
    redirect('index.php');
}

// Get order items
$stmt = $conn->prepare("
    SELECT oi.*, b.title, b.author, b.cover_image
    FROM order_items oi
    JOIN books b ON oi.book_id = b.id
    WHERE oi.order_id = ?
");
$stmt->execute([$order['id']]);
$items = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Success - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 50px 0;
        }
        .success-container {
            max-width: 900px;
            margin: 0 auto;
        }
        .success-icon {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 30px;
            animation: scaleIn 0.5s ease-out;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        @keyframes scaleIn {
            from { 
                transform: scale(0) rotate(-180deg);
                opacity: 0;
            }
            to { 
                transform: scale(1) rotate(0);
                opacity: 1;
            }
        }
        .order-card {
            background: white;
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            margin-bottom: 20px;
        }
        .confetti {
            position: fixed;
            width: 10px;
            height: 10px;
            background: #f0f;
            position: absolute;
            animation: confetti-fall 3s linear infinite;
        }
        @keyframes confetti-fall {
            to {
                transform: translateY(100vh) rotate(360deg);
            }
        }
        .step-badge {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }
        .order-item-card {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 10px;
        }
        .download-badge {
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }
    </style>
</head>
<body>
    <div class="container success-container">
        <!-- Success Message -->
        <div class="order-card text-center mb-4">
            <div class="success-icon">
                <i class="bi bi-check-lg text-success" style="font-size: 4rem;"></i>
            </div>
            
            <h1 class="mb-3">🎉 Pembayaran Berhasil!</h1>
            <p class="lead text-muted mb-4">
                Terima kasih telah berbelanja di ZaiMedia
            </p>
            
            <div class="alert alert-success d-inline-block">
                <strong>Order Number:</strong> 
                <span class="fs-5"><?= htmlspecialchars($order['order_number']) ?></span>
            </div>
            
            <p class="text-muted mt-3">
                Order Anda telah berhasil dibayar dan sedang diproses.
                <br>Anda dapat langsung mendownload buku-buku yang telah dibeli.
            </p>
        </div>

        <!-- Quick Actions -->
        <div class="order-card mb-4">
            <div class="row text-center g-3">
                <div class="col-md-4">
                    <a href="customer/library.php" class="btn btn-success btn-lg w-100 download-badge">
                        <i class="bi bi-download fs-3 d-block mb-2"></i>
                        <strong>Download Buku</strong>
                        <br><small>Tersedia di My Library</small>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="customer/orders.php" class="btn btn-outline-primary btn-lg w-100">
                        <i class="bi bi-list-ul fs-3 d-block mb-2"></i>
                        <strong>Lihat Order</strong>
                        <br><small>Riwayat pesanan</small>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="books.php" class="btn btn-outline-secondary btn-lg w-100">
                        <i class="bi bi-shop fs-3 d-block mb-2"></i>
                        <strong>Belanja Lagi</strong>
                        <br><small>Browse buku</small>
                    </a>
                </div>
            </div>
        </div>

        <!-- Order Details -->
        <div class="order-card mb-4">
            <h5 class="mb-4">
                <i class="bi bi-receipt me-2"></i>Detail Order
            </h5>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <small class="text-muted">Order Number</small>
                    <p class="mb-0"><strong><?= htmlspecialchars($order['order_number']) ?></strong></p>
                </div>
                <div class="col-md-6">
                    <small class="text-muted">Tanggal Order</small>
                    <p class="mb-0"><?= formatDateTimeIndo($order['created_at']) ?></p>
                </div>
            </div>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <small class="text-muted">Metode Pembayaran</small>
                    <p class="mb-0">
                        <i class="bi bi-credit-card me-2"></i>
                        <?= ucwords(str_replace('_', ' ', $order['payment_method'])) ?>
                    </p>
                </div>
                <div class="col-md-6">
                    <small class="text-muted">Status Pembayaran</small>
                    <p class="mb-0">
                        <span class="badge bg-success">
                            <i class="bi bi-check-circle me-1"></i>Paid
                        </span>
                    </p>
                </div>
            </div>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <small class="text-muted">Status Order</small>
                    <p class="mb-0">
                        <span class="badge bg-info">
                            <i class="bi bi-arrow-repeat me-1"></i>Processing
                        </span>
                    </p>
                </div>
                <div class="col-md-6">
                    <small class="text-muted">Total Pembayaran</small>
                    <p class="mb-0">
                        <strong class="text-primary fs-5"><?= formatRupiah($order['total']) ?></strong>
                    </p>
                </div>
            </div>
        </div>

        <!-- Order Items -->
        <div class="order-card mb-4">
            <h5 class="mb-4">
                <i class="bi bi-book me-2"></i>Buku yang Dibeli (<?= count($items) ?> items)
            </h5>
            
            <?php foreach ($items as $item): ?>
            <div class="order-item-card">
                <div class="d-flex align-items-center">
                    <div style="width: 60px; height: 80px; border-radius: 5px; overflow: hidden; margin-right: 15px;">
                        <?php if ($item['cover_image']): ?>
                            <img src="<?= BOOK_COVER_URL . $item['cover_image'] ?>" 
                                 style="width: 100%; height: 100%; object-fit: cover;"
                                 alt="<?= htmlspecialchars($item['title']) ?>">
                        <?php else: ?>
                            <div class="bg-gradient text-white d-flex align-items-center justify-content-center h-100">
                                <i class="bi bi-book"></i>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="flex-grow-1">
                        <h6 class="mb-1"><?= htmlspecialchars($item['title']) ?></h6>
                        <small class="text-muted">
                            <i class="bi bi-person me-1"></i><?= htmlspecialchars($item['author']) ?>
                        </small>
                        <br>
                        <small class="text-muted">Qty: <?= $item['quantity'] ?></small>
                    </div>
                    <div class="text-end">
                        <strong class="d-block mb-2"><?= formatRupiah($item['subtotal']) ?></strong>
                        <a href="customer/library.php" class="btn btn-sm btn-success">
                            <i class="bi bi-download me-1"></i> Download
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            
            <hr class="my-3">
            
            <div class="row">
                <div class="col-md-8">
                    <small class="text-muted">Subtotal</small>
                </div>
                <div class="col-md-4 text-end">
                    <strong><?= formatRupiah($order['subtotal']) ?></strong>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8">
                    <small class="text-muted">PPN (<?= TAX_PERCENTAGE ?>%)</small>
                </div>
                <div class="col-md-4 text-end">
                    <strong><?= formatRupiah($order['tax']) ?></strong>
                </div>
            </div>
            <div class="row mt-2 pt-2 border-top">
                <div class="col-md-8">
                    <strong>Total</strong>
                </div>
                <div class="col-md-4 text-end">
                    <strong class="text-primary fs-5"><?= formatRupiah($order['total']) ?></strong>
                </div>
            </div>
        </div>

        <!-- Next Steps -->
        <div class="order-card mb-4">
            <h5 class="mb-4">
                <i class="bi bi-info-circle me-2"></i>Langkah Selanjutnya
            </h5>
            
            <div class="d-flex align-items-start mb-3">
                <div class="step-badge me-3">1</div>
                <div>
                    <h6 class="mb-1">Download Buku Anda</h6>
                    <p class="text-muted mb-0">
                        Buku sudah tersedia untuk didownload. Klik tombol "Download Buku" di atas atau kunjungi halaman My Library.
                    </p>
                </div>
            </div>
            
            <div class="d-flex align-items-start mb-3">
                <div class="step-badge me-3">2</div>
                <div>
                    <h6 class="mb-1">Email Konfirmasi</h6>
                    <p class="text-muted mb-0">
                        Kami telah mengirim email konfirmasi ke <strong><?= htmlspecialchars($order['shipping_name']) ?></strong> dengan detail order dan link download.
                    </p>
                </div>
            </div>
            
            <div class="d-flex align-items-start">
                <div class="step-badge me-3">3</div>
                <div>
                    <h6 class="mb-1">Berikan Review</h6>
                    <p class="text-muted mb-0">
                        Setelah membaca, jangan lupa berikan review untuk membantu pembaca lain!
                    </p>
                </div>
            </div>
        </div>

        <!-- Customer Support -->
        <div class="order-card">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h6 class="mb-2">
                        <i class="bi bi-headset me-2"></i>Butuh Bantuan?
                    </h6>
                    <p class="text-muted mb-0">
                        Tim customer support kami siap membantu Anda 24/7
                    </p>
                </div>
                <div class="col-md-4 text-end">
                    <a href="#" class="btn btn-outline-primary">
                        <i class="bi bi-chat-dots me-2"></i>Contact Support
                    </a>
                </div>
            </div>
        </div>

        <!-- Back to Home -->
        <div class="text-center mt-4">
            <a href="index.php" class="btn btn-light btn-lg">
                <i class="bi bi-house-door me-2"></i> Kembali ke Home
            </a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Create confetti effect
        function createConfetti() {
            const colors = ['#667eea', '#764ba2', '#f093fb', '#4facfe', '#43e97b'];
            for (let i = 0; i < 50; i++) {
                setTimeout(() => {
                    const confetti = document.createElement('div');
                    confetti.className = 'confetti';
                    confetti.style.left = Math.random() * 100 + '%';
                    confetti.style.background = colors[Math.floor(Math.random() * colors.length)];
                    confetti.style.animationDuration = (Math.random() * 3 + 2) + 's';
                    confetti.style.animationDelay = Math.random() + 's';
                    document.body.appendChild(confetti);
                    
                    setTimeout(() => confetti.remove(), 5000);
                }, i * 50);
            }
        }
        
        // Run confetti on load
        window.addEventListener('load', createConfetti);
    </script>
</body>
</html>