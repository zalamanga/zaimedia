<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'api/books.php';

$conn = getDBConnection();

// Get filters
$category = $_GET['category'] ?? null;
$search = $_GET['search'] ?? '';
$sort = $_GET['sort'] ?? 'newest';

// Build filters
$filters = ['status' => 'approved'];

if ($category) {
    $filters['category_id'] = $category;
}
if (!empty($search)) {
    $filters['search'] = $search;
}

// Sorting
switch ($sort) {
    case 'price_low':
        $filters['order_by'] = 'b.price';
        $filters['order_dir'] = 'ASC';
        break;
    case 'price_high':
        $filters['order_by'] = 'b.price';
        $filters['order_dir'] = 'DESC';
        break;
    case 'popular':
        $filters['order_by'] = 'b.views';
        $filters['order_dir'] = 'DESC';
        break;
    default: // newest
        $filters['order_by'] = 'b.created_at';
        $filters['order_dir'] = 'DESC';
}

// Get books
$books = getBooks($filters);

// Get categories
$stmt = $conn->query("SELECT * FROM categories ORDER BY name");
$categories = $stmt->fetchAll();

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Browse Books - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .navbar {
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .page-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 60px 0 40px;
            margin-bottom: 40px;
        }
        
        .filter-sidebar {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            position: sticky;
            top: 90px;
        }
        
        .category-item {
            padding: 12px 15px;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            text-decoration: none;
            color: #333;
            border: 2px solid transparent;
        }
        
        .category-item:hover {
            background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
            border-color: #667eea;
            transform: translateX(5px);
        }
        
        .category-item.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }
        
        .category-item i {
            font-size: 1.1rem;
            margin-right: 10px;
        }
        
        .book-card {
            transition: all 0.3s ease;
            height: 100%;
            cursor: pointer;
            border: none;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            border-radius: 15px;
            overflow: hidden;
            background: white;
        }
        
        .book-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 12px 35px rgba(102, 126, 234, 0.3);
        }
        
        .book-image {
            height: 320px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            position: relative;
            overflow: hidden;
        }
        
        .book-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s;
        }
        
        .book-card:hover .book-image img {
            transform: scale(1.05);
        }
        
        .category-badge {
            position: absolute;
            top: 15px;
            right: 15px;
            background: rgba(255,255,255,0.95);
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }
        
        .views-badge {
            position: absolute;
            bottom: 15px;
            left: 15px;
            background: rgba(0,0,0,0.7);
            color: white;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            backdrop-filter: blur(10px);
        }
        
        .price-tag {
            font-size: 1.3rem;
            font-weight: 700;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .search-box {
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            margin-bottom: 30px;
        }
        
        .sort-select {
            border-radius: 10px;
            border: 2px solid #e9ecef;
            padding: 10px 15px;
            transition: all 0.3s;
        }
        
        .sort-select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        
        footer {
            background: #2c3e50;
            color: white;
            padding: 40px 0;
            margin-top: 80px;
        }
        
        .btn-cart {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            padding: 8px 16px;
            border-radius: 10px;
            transition: all 0.3s;
        }
        
        .btn-cart:hover {
            transform: scale(1.05);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        
        .section-divider {
            height: 4px;
            width: 60px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 2px;
            margin: 10px 0 20px 0;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold fs-4" href="index.php">
                <i class="bi bi-book-fill text-primary me-2"></i>ZaiMedia
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="books.php">Books</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                            Categories
                        </a>
                        <ul class="dropdown-menu">
                            <?php foreach ($categories as $cat): ?>
                            <li>
                                <a class="dropdown-item" href="books.php?category=<?= $cat['id'] ?>">
                                    <?= htmlspecialchars($cat['name']) ?>
                                </a>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                </ul>
                <div class="d-flex align-items-center gap-3">
                    <?php if (isLoggedIn()): ?>
                        <?php $currentUser = getCurrentUser(); ?>
                        <div class="dropdown">
                            <a class="btn btn-outline-primary dropdown-toggle" href="#" data-bs-toggle="dropdown">
                                <i class="bi bi-person-circle me-2"></i>
                                <?= htmlspecialchars($currentUser['username']) ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <?php if ($currentUser['role'] === 'admin'): ?>
                                    <li><a class="dropdown-item" href="admin/dashboard.php">
                                        <i class="bi bi-speedometer2 me-2"></i> Admin Dashboard
                                    </a></li>
                                <?php elseif ($currentUser['role'] === 'writer'): ?>
                                    <li><a class="dropdown-item" href="writer/dashboard.php">
                                        <i class="bi bi-book me-2"></i> Writer Dashboard
                                    </a></li>
                                <?php else: ?>
                                    <li><a class="dropdown-item" href="customer/dashboard.php">
                                        <i class="bi bi-person me-2"></i> My Account
                                    </a></li>
                                <?php endif; ?>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="logout.php">
                                    <i class="bi bi-box-arrow-right me-2"></i> Logout
                                </a></li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-outline-primary">
                            <i class="bi bi-box-arrow-in-right me-2"></i> Login
                        </a>
                        <a href="register.php" class="btn btn-primary">
                            <i class="bi bi-person-plus me-2"></i> Register
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <?php if ($flash): ?>
    <div class="container mt-3">
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
            <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    </div>
    <?php endif; ?>

    <!-- Page Header -->
    <div class="page-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h1 class="display-5 fw-bold mb-2">
                        <i class="bi bi-collection me-3"></i>
                        <?php if ($category): ?>
                            <?php
                            $catName = array_filter($categories, fn($c) => $c['id'] == $category);
                            $catName = reset($catName);
                            echo htmlspecialchars($catName['name']);
                            ?>
                        <?php elseif ($search): ?>
                            Search Results
                        <?php else: ?>
                            Browse Books
                        <?php endif; ?>
                    </h1>
                    <p class="lead mb-0">
                        <i class="bi bi-book me-2"></i><?= count($books) ?> books available
                        <?php if ($search): ?>
                            for "<?= htmlspecialchars($search) ?>"
                        <?php endif; ?>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Content -->
    <div class="container mb-5">
        <div class="row">
            <!-- Sidebar Filter -->
            <div class="col-lg-3 col-md-4 mb-4">
                <div class="filter-sidebar">
                    <h5 class="fw-bold mb-1">
                        <i class="bi bi-funnel me-2"></i>Categories
                    </h5>
                    <div class="section-divider"></div>
                    
                    <a href="books.php" class="category-item <?= !$category ? 'active' : '' ?>">
                        <i class="bi bi-grid-fill"></i>
                        <span>All Books</span>
                    </a>
                    
                    <?php foreach ($categories as $cat): ?>
                    <a href="books.php?category=<?= $cat['id'] ?>" 
                       class="category-item <?= $category == $cat['id'] ? 'active' : '' ?>">
                        <i class="bi bi-tag-fill"></i>
                        <span><?= htmlspecialchars($cat['name']) ?></span>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Books Grid -->
            <div class="col-lg-9 col-md-8">
                <!-- Search & Sort Box -->
                <div class="search-box">
                    <div class="row g-3 align-items-center">
                        <div class="col-md-7">
                            <form method="GET" class="d-flex gap-2">
                                <?php if ($category): ?>
                                <input type="hidden" name="category" value="<?= $category ?>">
                                <?php endif; ?>
                                <div class="input-group">
                                    <span class="input-group-text bg-white border-end-0">
                                        <i class="bi bi-search"></i>
                                    </span>
                                    <input type="text" class="form-control border-start-0 ps-0" 
                                           name="search" placeholder="Cari judul buku atau penulis..." 
                                           value="<?= htmlspecialchars($search) ?>">
                                </div>
                                <button type="submit" class="btn btn-primary px-4">
                                    Search
                                </button>
                            </form>
                        </div>
                        <div class="col-md-5">
                            <div class="d-flex align-items-center gap-2">
                                <label class="text-muted small mb-0 text-nowrap">
                                    <i class="bi bi-sort-down me-1"></i>Sort by:
                                </label>
                                <select class="form-select sort-select" 
                                        onchange="window.location.href='books.php?<?= $category ? 'category='.$category.'&' : '' ?><?= $search ? 'search='.urlencode($search).'&' : '' ?>sort=' + this.value">
                                    <option value="newest" <?= $sort === 'newest' ? 'selected' : '' ?>>Terbaru</option>
                                    <option value="popular" <?= $sort === 'popular' ? 'selected' : '' ?>>Terpopuler</option>
                                    <option value="price_low" <?= $sort === 'price_low' ? 'selected' : '' ?>>Harga Terendah</option>
                                    <option value="price_high" <?= $sort === 'price_high' ? 'selected' : '' ?>>Harga Tertinggi</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Books Grid -->
                <?php if (empty($books)): ?>
                    <div class="text-center py-5">
                        <i class="bi bi-inbox" style="font-size: 80px; color: #ddd;"></i>
                        <h4 class="mt-3 text-muted">Tidak ada buku ditemukan</h4>
                        <p class="text-muted">Coba ubah filter atau kata kunci pencarian Anda</p>
                        <a href="books.php" class="btn btn-primary mt-3">
                            <i class="bi bi-arrow-left me-2"></i>Lihat Semua Buku
                        </a>
                    </div>
                <?php else: ?>
                    <div class="row g-4">
                        <?php foreach ($books as $book): ?>
                        <div class="col-lg-4 col-md-6">
                            <div class="card book-card" onclick="window.location.href='book-detail.php?id=<?= $book['id'] ?>'">
                                <div class="book-image">
                                    <?php if ($book['cover_image']): ?>
                                        <img src="<?= BOOK_COVER_URL . $book['cover_image'] ?>" 
                                             alt="<?= htmlspecialchars($book['title']) ?>">
                                    <?php else: ?>
                                        <span class="p-3 text-center"><?= htmlspecialchars($book['title']) ?></span>
                                    <?php endif; ?>
                                    
                                    <span class="category-badge">
                                        <?= htmlspecialchars($book['category_name']) ?>
                                    </span>
                                    
                                    <span class="views-badge">
                                        <i class="bi bi-eye me-1"></i><?= number_format($book['views']) ?>
                                    </span>
                                </div>
                                <div class="card-body">
                                    <h6 class="card-title fw-bold mb-2" style="min-height: 45px;">
                                        <?= htmlspecialchars(truncateText($book['title'], 50)) ?>
                                    </h6>
                                    <p class="text-muted small mb-2">
                                        <i class="bi bi-person me-1"></i>
                                        <?= htmlspecialchars($book['author']) ?>
                                    </p>
                                    <p class="text-muted small mb-3">
                                        <i class="bi bi-journal-text me-1"></i>
                                        <?= $book['pages'] ?> halaman
                                    </p>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="price-tag"><?= formatRupiah($book['price']) ?></span>
                                        <button class="btn btn-primary btn-sm btn-cart" onclick="event.stopPropagation()">
                                            <i class="bi bi-cart-plus"></i> Add
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h5 class="fw-bold mb-3">
                        <i class="bi bi-book-fill me-2"></i>ZaiMedia
                    </h5>
                    <p class="text-light">Platform toko buku online terpercaya dengan koleksi lengkap dan harga terjangkau.</p>
                </div>
                <div class="col-md-4 mb-4">
                    <h5 class="fw-bold mb-3">Quick Links</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="index.php" class="text-light text-decoration-none">Home</a></li>
                        <li class="mb-2"><a href="books.php" class="text-light text-decoration-none">Books</a></li>
                        <li class="mb-2"><a href="about.php" class="text-light text-decoration-none">About</a></li>
                        <li class="mb-2"><a href="contact.php" class="text-light text-decoration-none">Contact</a></li>
                    </ul>
                </div>
                <div class="col-md-4 mb-4">
                    <h5 class="fw-bold mb-3">Contact</h5>
                    <ul class="list-unstyled text-light">
                        <li class="mb-2"><i class="bi bi-envelope me-2"></i> info@zaimedia.com</li>
                        <li class="mb-2"><i class="bi bi-phone me-2"></i> +62 812-3456-7890</li>
                        <li class="mb-2"><i class="bi bi-geo-alt me-2"></i> Jakarta, Indonesia</li>
                    </ul>
                </div>
            </div>
            <hr class="bg-light">
            <div class="text-center text-light">
                <p class="mb-0">&copy; 2024 ZaiMedia Bookstore. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>