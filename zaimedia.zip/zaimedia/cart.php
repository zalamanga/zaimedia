<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

requireLogin();

$conn = getDBConnection();
$customerId = $_SESSION['user_id'];

// Handle add to cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    if ($action === 'add') {
        $bookId = (int)$_POST['book_id'];
        $quantity = (int)($_POST['quantity'] ?? 1);
        
        // Check if already in cart
        $stmt = $conn->prepare("SELECT id, quantity FROM cart WHERE customer_id = ? AND book_id = ?");
        $stmt->execute([$customerId, $bookId]);
        $existing = $stmt->fetch();
        
        if ($existing) {
            // Update quantity
            $stmt = $conn->prepare("UPDATE cart SET quantity = quantity + ? WHERE id = ?");
            $stmt->execute([$quantity, $existing['id']]);
        } else {
            // Insert new
            $stmt = $conn->prepare("INSERT INTO cart (customer_id, book_id, quantity) VALUES (?, ?, ?)");
            $stmt->execute([$customerId, $bookId, $quantity]);
        }
        
        setFlash('success', 'Buku berhasil ditambahkan ke cart');
        
    } elseif ($action === 'update') {
        $cartId = (int)$_POST['cart_id'];
        $quantity = (int)$_POST['quantity'];
        
        if ($quantity > 0) {
            $stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE id = ? AND customer_id = ?");
            $stmt->execute([$quantity, $cartId, $customerId]);
        }
        
    } elseif ($action === 'remove') {
        $cartId = (int)$_POST['cart_id'];
        $stmt = $conn->prepare("DELETE FROM cart WHERE id = ? AND customer_id = ?");
        $stmt->execute([$cartId, $customerId]);
        
        setFlash('success', 'Item dihapus dari cart');
    }
    
    redirect('cart.php');
}

// Get cart items
$stmt = $conn->prepare("
    SELECT c.*, b.title, b.author, b.price, b.cover_image, b.status
    FROM cart c
    JOIN books b ON c.book_id = b.id
    WHERE c.customer_id = ?
");
$stmt->execute([$customerId]);
$cartItems = $stmt->fetchAll();

// Calculate totals
$subtotal = 0;
foreach ($cartItems as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}

$tax = calculateTax($subtotal);
$total = $subtotal + $tax;

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .navbar {
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .cart-item {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .cart-image {
            width: 100px;
            height: 130px;
            object-fit: cover;
            border-radius: 5px;
        }
        .summary-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: sticky;
            top: 80px;
        }
    </style>
</head>
<body class="bg-light">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold fs-4" href="index.php">
                <i class="bi bi-book-fill text-primary me-2"></i>ZaiMedia
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="books.php">Books</a>
                    </li>
                </ul>
                <div class="d-flex align-items-center gap-3">
                    <?php $currentUser = getCurrentUser(); ?>
                    <a href="cart.php" class="btn btn-outline-primary active">
                        <i class="bi bi-cart3 me-2"></i> Cart (<?= count($cartItems) ?>)
                    </a>
                    <div class="dropdown">
                        <a class="btn btn-outline-primary dropdown-toggle" href="#" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle me-2"></i>
                            <?= htmlspecialchars($currentUser['username']) ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="customer/dashboard.php">My Account</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="container my-5">
        <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
            <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <h2 class="mb-4">Shopping Cart</h2>

        <div class="row">
            <div class="col-md-8">
                <?php if (empty($cartItems)): ?>
                    <div class="cart-item text-center py-5">
                        <i class="bi bi-cart-x display-1 text-muted"></i>
                        <h4 class="mt-3">Cart Anda Kosong</h4>
                        <p class="text-muted">Belum ada buku di cart. Yuk belanja sekarang!</p>
                        <a href="books.php" class="btn btn-primary mt-3">
                            <i class="bi bi-shop me-2"></i> Browse Books
                        </a>
                    </div>
                <?php else: ?>
                    <?php foreach ($cartItems as $item): ?>
                    <div class="cart-item">
                        <div class="row align-items-center">
                            <div class="col-md-2">
                                <?php if ($item['cover_image']): ?>
                                    <img src="<?= BOOK_COVER_URL . $item['cover_image'] ?>" 
                                         class="cart-image" alt="<?= htmlspecialchars($item['title']) ?>">
                                <?php else: ?>
                                    <div class="cart-image bg-gradient d-flex align-items-center justify-content-center text-white">
                                        <i class="bi bi-book fs-2"></i>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-4">
                                <h6 class="mb-1"><?= htmlspecialchars($item['title']) ?></h6>
                                <small class="text-muted"><?= htmlspecialchars($item['author']) ?></small>
                                <?php if ($item['status'] !== 'approved'): ?>
                                    <br><span class="badge bg-danger mt-1">Not Available</span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-2">
                                <h6 class="text-primary mb-0"><?= formatRupiah($item['price']) ?></h6>
                            </div>
                            <div class="col-md-2">
                                <form method="POST" class="d-inline">
                                    <div class="input-group input-group-sm">
                                        <button type="button" class="btn btn-outline-secondary" 
                                                onclick="updateQuantity(<?= $item['id'] ?>, <?= $item['quantity'] - 1 ?>)">
                                            <i class="bi bi-dash"></i>
                                        </button>
                                        <input type="number" class="form-control text-center" 
                                               value="<?= $item['quantity'] ?>" min="1" max="10" readonly>
                                        <button type="button" class="btn btn-outline-secondary"
                                                onclick="updateQuantity(<?= $item['id'] ?>, <?= $item['quantity'] + 1 ?>)">
                                            <i class="bi bi-plus"></i>
                                        </button>
                                    </div>
                                </form>
                            </div>
                            <div class="col-md-2 text-end">
                                <h6 class="mb-2"><?= formatRupiah($item['price'] * $item['quantity']) ?></h6>
                                <button class="btn btn-sm btn-outline-danger" onclick="removeItem(<?= $item['id'] ?>)">
                                    <i class="bi bi-trash"></i> Remove
                                </button>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <?php if (!empty($cartItems)): ?>
            <div class="col-md-4">
                <div class="summary-card">
                    <h5 class="mb-4">Order Summary</h5>
                    
                    <div class="d-flex justify-content-between mb-2">
                        <span>Subtotal (<?= count($cartItems) ?> items)</span>
                        <strong><?= formatRupiah($subtotal) ?></strong>
                    </div>
                    
                    <div class="d-flex justify-content-between mb-2">
                        <span>Tax (<?= TAX_PERCENTAGE ?>%)</span>
                        <strong><?= formatRupiah($tax) ?></strong>
                    </div>
                    
                    <hr>
                    
                    <div class="d-flex justify-content-between mb-4">
                        <h6>Total</h6>
                        <h5 class="text-primary"><?= formatRupiah($total) ?></h5>
                    </div>
                    
                    <a href="checkout.php" class="btn btn-primary w-100 mb-2">
                        <i class="bi bi-credit-card me-2"></i> Proceed to Checkout
                    </a>
                    
                    <a href="books.php" class="btn btn-outline-secondary w-100">
                        <i class="bi bi-arrow-left me-2"></i> Continue Shopping
                    </a>
                    
                    <div class="mt-4 p-3 bg-light rounded">
                        <h6 class="mb-2">
                            <i class="bi bi-shield-check text-success me-2"></i>
                            Safe & Secure
                        </h6>
                        <small class="text-muted">
                            Your payment information is encrypted and secure
                        </small>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function updateQuantity(cartId, quantity) {
            if (quantity < 1) quantity = 1;
            if (quantity > 10) quantity = 10;
            
            const form = document.createElement('form');
            form.method = 'POST';
            form.innerHTML = `
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="cart_id" value="${cartId}">
                <input type="hidden" name="quantity" value="${quantity}">
            `;
            document.body.appendChild(form);
            form.submit();
        }

        function removeItem(cartId) {
            if (confirm('Remove item dari cart?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="remove">
                    <input type="hidden" name="cart_id" value="${cartId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>
</body>
</html>