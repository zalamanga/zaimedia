<?php

// ==========================================
// SYSTEM CONFIGURATION
// ==========================================

// Base URL
define('BASE_URL', 'http://localhost:8080/zaimedia/');

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'zaimedia');
define('DB_USER', 'root');
define('DB_PASS', '');

// ==========================================
// FILE UPLOAD CONFIGURATION
// ==========================================

// Upload paths
define('UPLOAD_PATH', __DIR__ . '/../uploads/');
define('BOOK_COVER_PATH', UPLOAD_PATH . 'books/covers/');
define('BOOK_PDF_PATH', UPLOAD_PATH . 'books/pdf/');
define('AVATAR_PATH', UPLOAD_PATH . 'avatars/');

// Upload URLs
define('UPLOAD_URL', BASE_URL . 'uploads/');
define('BOOK_COVER_URL', UPLOAD_URL . 'books/covers/');
define('BOOK_PDF_URL', UPLOAD_URL . 'books/pdf/');
define('AVATAR_URL', UPLOAD_URL . 'avatars/');

// ==========================================
// BUSINESS LOGIC CONFIGURATION
// ==========================================

// Tax percentage
define('TAX_PERCENTAGE', 11);

// Writer royalty percentage (70% to writer)
define('DEFAULT_ROYALTY_PERCENTAGE', 70);

// Minimum withdrawal amount (Rp 100,000)
define('MIN_WITHDRAWAL', 100000);

// Maximum withdrawal amount per request (Rp 10,000,000)
define('MAX_WITHDRAWAL', 10000000);

// ==========================================
// SESSION CONFIGURATION
// ==========================================

// Session timeout (in seconds) - 2 hours
define('SESSION_TIMEOUT', 7200);

// ==========================================
// PAGINATION CONFIGURATION
// ==========================================

// Items per page
define('ITEMS_PER_PAGE', 20);

// ==========================================
// EMAIL CONFIGURATION (for future use)
// ==========================================

// SMTP settings
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'your-email@gmail.com');
define('SMTP_PASSWORD', 'your-password');
define('SMTP_FROM_EMAIL', 'noreply@zaimedia.com');
define('SMTP_FROM_NAME', 'ZaiMedia Bookstore');

// ==========================================
// SYSTEM SETTINGS
// ==========================================

// Site name
define('SITE_NAME', 'ZaiMedia Bookstore');

// Site description
define('SITE_DESCRIPTION', 'Platform jual beli buku digital dengan sistem royalty untuk penulis');

// Admin email
define('ADMIN_EMAIL', 'admin@zaimedia.com');

// Support email
define('SUPPORT_EMAIL', 'support@zaimedia.com');

// ==========================================
// ERROR REPORTING (Development Mode)
// ==========================================

// Set to false in production
if (true) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
    ini_set('log_errors', 1);
    ini_set('error_log', __DIR__ . '/../logs/error.log');
}

// ==========================================
// TIMEZONE
// ==========================================

date_default_timezone_set('Asia/Jakarta');

// ==========================================
// START SESSION
// ==========================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}