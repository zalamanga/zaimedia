<?php

/**
 * Get Database Connection using PDO
 */
function getDBConnection() {
    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ];
        
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        return $pdo;
    } catch (PDOException $e) {
        die("Connection failed: " . $e->getMessage());
    }
}

/**
 * Test database connection
 */
function testDBConnection() {
    try {
        $conn = getDBConnection();
        return true;
    } catch (Exception $e) {
        return false;
    }
}

/**
 * Execute query and return result
 */
function executeQuery($sql, $params = []) {
    $conn = getDBConnection();
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    return $stmt;
}

/**
 * Get single row
 */
function getRow($sql, $params = []) {
    $stmt = executeQuery($sql, $params);
    return $stmt->fetch();
}

/**
 * Get all rows
 */
function getRows($sql, $params = []) {
    $stmt = executeQuery($sql, $params);
    return $stmt->fetchAll();
}

/**
 * Insert data and return last insert ID
 */
function insertData($table, $data) {
    $conn = getDBConnection();
    
    $columns = implode(', ', array_keys($data));
    $placeholders = implode(', ', array_fill(0, count($data), '?'));
    
    $sql = "INSERT INTO $table ($columns) VALUES ($placeholders)";
    $stmt = $conn->prepare($sql);
    $stmt->execute(array_values($data));
    
    return $conn->lastInsertId();
}

/**
 * Update data
 */
function updateData($table, $data, $where, $whereParams = []) {
    $conn = getDBConnection();
    
    $set = [];
    foreach (array_keys($data) as $column) {
        $set[] = "$column = ?";
    }
    $setClause = implode(', ', $set);
    
    $sql = "UPDATE $table SET $setClause WHERE $where";
    $stmt = $conn->prepare($sql);
    
    $params = array_merge(array_values($data), $whereParams);
    return $stmt->execute($params);
}

/**
 * Delete data
 */
function deleteData($table, $where, $whereParams = []) {
    $conn = getDBConnection();
    
    $sql = "DELETE FROM $table WHERE $where";
    $stmt = $conn->prepare($sql);
    
    return $stmt->execute($whereParams);
}

/**
 * Count rows
 */
function countRows($table, $where = '1=1', $params = []) {
    $conn = getDBConnection();
    
    $sql = "SELECT COUNT(*) FROM $table WHERE $where";
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    
    return $stmt->fetchColumn();
}

/**
 * Check if record exists
 */
function recordExists($table, $where, $params = []) {
    return countRows($table, $where, $params) > 0;
}

/**
 * Begin transaction
 */
function beginTransaction() {
    $conn = getDBConnection();
    return $conn->beginTransaction();
}

/**
 * Commit transaction
 */
function commitTransaction() {
    $conn = getDBConnection();
    return $conn->commit();
}

/**
 * Rollback transaction
 */
function rollbackTransaction() {
    $conn = getDBConnection();
    return $conn->rollBack();
}