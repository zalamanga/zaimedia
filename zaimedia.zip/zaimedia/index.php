<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'api/books.php';

// Get newest books
$newestBooks = getBooks([
    'status' => 'approved',
    'limit' => 8,
    'order_by' => 'b.created_at',
    'order_dir' => 'DESC'
]);

// Get popular books (sorted by views)
$popularBooks = getBooks([
    'status' => 'approved',
    'limit' => 8,
    'order_by' => 'b.views',
    'order_dir' => 'DESC'
]);

// Get categories
$conn = getDBConnection();
$stmt = $conn->query("SELECT * FROM categories ORDER BY name");
$categories = $stmt->fetchAll();

// Get flash message
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZaiMedia - Toko Buku Online</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .navbar {
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        /* Banner Slider Styles */
        .banner-slider {
            position: relative;
            height: 500px;
            overflow: hidden;
            margin-bottom: 50px;
        }

        .banner-slide {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            opacity: 0;
            transition: opacity 1s ease-in-out;
            display: flex;
            align-items: center;
        }

        .banner-slide.active {
            opacity: 1;
        }

        .banner-slide-1 {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        .banner-slide-2 {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }

        .banner-slide-3 {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        }

        .banner-content {
            color: white;
            z-index: 2;
        }

        .banner-icon {
            font-size: 120px;
            color: white;
            opacity: 0.9;
        }

        .slider-controls {
            position: absolute;
            bottom: 30px;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            gap: 10px;
            z-index: 3;
        }

        .slider-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.5);
            border: none;
            cursor: pointer;
            transition: background 0.3s;
        }

        .slider-dot.active {
            background: white;
        }

        .slider-arrow {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(255, 255, 255, 0.3);
            border: none;
            color: white;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            cursor: pointer;
            transition: background 0.3s;
            z-index: 3;
        }

        .slider-arrow:hover {
            background: rgba(255, 255, 255, 0.5);
        }

        .slider-arrow-left {
            left: 20px;
        }

        .slider-arrow-right {
            right: 20px;
        }

        .book-card {
            transition: transform 0.3s, box-shadow 0.3s;
            height: 100%;
            cursor: pointer;
            border: none;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-radius: 10px;
            overflow: hidden;
        }
        .book-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .book-image {
            height: 300px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            position: relative;
            overflow: hidden;
        }
        .book-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .category-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background: rgba(255,255,255,0.95);
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
        .popular-badge {
            position: absolute;
            top: 10px;
            left: 10px;
            background: linear-gradient(135deg, #ff6b6b 0%, #ff8e53 100%);
            color: white;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            box-shadow: 0 2px 5px rgba(0,0,0,0.3);
        }
        .price-tag {
            font-size: 1.2rem;
            font-weight: 700;
            color: #667eea;
        }
        .section-title {
            position: relative;
            padding-bottom: 15px;
            margin-bottom: 30px;
        }
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 60px;
            height: 4px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 2px;
        }
        footer {
            background: #2c3e50;
            color: white;
            padding: 40px 0;
            margin-top: 80px;
        }
        .stats-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: transform 0.3s;
        }
        .stats-card:hover {
            transform: translateY(-5px);
        }
        .views-count {
            position: absolute;
            bottom: 10px;
            left: 10px;
            background: rgba(0,0,0,0.7);
            color: white;
            padding: 4px 10px;
            border-radius: 15px;
            font-size: 0.75rem;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold fs-4" href="index.php">
                <i class="bi bi-book-fill text-primary me-2"></i>ZaiMedia
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="books.php">Books</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                            Categories
                        </a>
                        <ul class="dropdown-menu">
                            <?php foreach ($categories as $cat): ?>
                            <li>
                                <a class="dropdown-item" href="books.php?category=<?= $cat['id'] ?>">
                                    <?= htmlspecialchars($cat['name']) ?>
                                </a>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                </ul>
                <div class="d-flex align-items-center gap-3">
                    <?php if (isLoggedIn()): ?>
                        <?php $currentUser = getCurrentUser(); ?>
                        <div class="dropdown">
                            <a class="btn btn-outline-primary dropdown-toggle" href="#" data-bs-toggle="dropdown">
                                <i class="bi bi-person-circle me-2"></i>
                                <?= htmlspecialchars($currentUser['username']) ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <?php if ($currentUser['role'] === 'admin'): ?>
                                    <li><a class="dropdown-item" href="admin/dashboard.php">
                                        <i class="bi bi-speedometer2 me-2"></i> Admin Dashboard
                                    </a></li>
                                <?php elseif ($currentUser['role'] === 'writer'): ?>
                                    <li><a class="dropdown-item" href="writer/dashboard.php">
                                        <i class="bi bi-book me-2"></i> Writer Dashboard
                                    </a></li>
                                <?php else: ?>
                                    <li><a class="dropdown-item" href="customer/dashboard.php">
                                        <i class="bi bi-person me-2"></i> My Account
                                    </a></li>
                                <?php endif; ?>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="logout.php">
                                    <i class="bi bi-box-arrow-right me-2"></i> Logout
                                </a></li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-outline-primary">
                            <i class="bi bi-box-arrow-in-right me-2"></i> Login
                        </a>
                        <a href="register.php" class="btn btn-primary">
                            <i class="bi bi-person-plus me-2"></i> Register
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <?php if ($flash): ?>
    <div class="container mt-3">
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
            <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    </div>
    <?php endif; ?>

    <!-- Banner Slider -->
    <div class="banner-slider">
        <!-- Slide 1 -->
        <div class="banner-slide banner-slide-1 active">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 banner-content">
                        <h1 class="display-3 fw-bold mb-3">Selamat Datang di ZaiMedia</h1>
                        <p class="lead mb-4">Temukan koleksi buku terbaik untuk menambah wawasan dan pengetahuan Anda</p>
                        <a href="books.php" class="btn btn-light btn-lg px-5">
                            <i class="bi bi-book me-2"></i>Jelajahi Sekarang
                        </a>
                    </div>
                    <div class="col-lg-6 text-center d-none d-lg-block">
                        <i class="bi bi-book banner-icon"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Slide 2 -->
        <div class="banner-slide banner-slide-2">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 banner-content">
                        <h1 class="display-3 fw-bold mb-3">Diskon Hingga 50%</h1>
                        <p class="lead mb-4">Dapatkan penawaran terbaik untuk buku-buku pilihan minggu ini</p>
                        <a href="books.php" class="btn btn-light btn-lg px-5">
                            <i class="bi bi-tag-fill me-2"></i>Lihat Promo
                        </a>
                    </div>
                    <div class="col-lg-6 text-center d-none d-lg-block">
                        <i class="bi bi-tag-fill banner-icon"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Slide 3 -->
        <div class="banner-slide banner-slide-3">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 banner-content">
                        <h1 class="display-3 fw-bold mb-3">Pengiriman Gratis</h1>
                        <p class="lead mb-4">Gratis ongkir untuk pembelian minimal Rp 100.000</p>
                        <a href="books.php" class="btn btn-light btn-lg px-5">
                            <i class="bi bi-cart-check me-2"></i>Belanja Sekarang
                        </a>
                    </div>
                    <div class="col-lg-6 text-center d-none d-lg-block">
                        <i class="bi bi-truck banner-icon"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Slider Controls -->
        <button class="slider-arrow slider-arrow-left" onclick="prevSlide()">
            <i class="bi bi-chevron-left"></i>
        </button>
        <button class="slider-arrow slider-arrow-right" onclick="nextSlide()">
            <i class="bi bi-chevron-right"></i>
        </button>

        <div class="slider-controls">
            <button class="slider-dot active" onclick="goToSlide(0)"></button>
            <button class="slider-dot" onclick="goToSlide(1)"></button>
            <button class="slider-dot" onclick="goToSlide(2)"></button>
        </div>
    </div>

    <!-- Stats Section -->
    <div class="container mb-5">
        <div class="row g-4">
            <div class="col-md-4">
                <div class="stats-card text-center">
                    <i class="bi bi-book fs-1 text-primary mb-3 d-block"></i>
                    <h3 class="fw-bold"><?= count($newestBooks) + count($popularBooks) ?>+</h3>
                    <p class="text-muted mb-0">Books Available</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stats-card text-center">
                    <i class="bi bi-people fs-1 text-success mb-3 d-block"></i>
                    <h3 class="fw-bold">1000+</h3>
                    <p class="text-muted mb-0">Happy Readers</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stats-card text-center">
                    <i class="bi bi-star-fill fs-1 text-warning mb-3 d-block"></i>
                    <h3 class="fw-bold">4.8/5</h3>
                    <p class="text-muted mb-0">Average Rating</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Popular Books Section -->
    <div class="container mb-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold section-title">
                <i class="bi bi-fire text-danger me-2"></i>Buku Populer
            </h2>
            <a href="books.php?sort=popular" class="btn btn-outline-primary">
                Lihat Semua <i class="bi bi-arrow-right ms-2"></i>
            </a>
        </div>
        
        <?php if (empty($popularBooks)): ?>
            <div class="alert alert-info text-center">
                <i class="bi bi-info-circle me-2"></i>
                Belum ada buku populer saat ini
            </div>
        <?php else: ?>
            <div class="row g-4">
                <?php foreach ($popularBooks as $index => $book): ?>
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="card book-card" onclick="window.location.href='book-detail.php?id=<?= $book['id'] ?>'">
                        <div class="book-image">
                            <?php if ($book['cover_image']): ?>
                                <img src="<?= BOOK_COVER_URL . $book['cover_image'] ?>" 
                                     alt="<?= htmlspecialchars($book['title']) ?>">
                            <?php else: ?>
                                <span class="p-3 text-center"><?= htmlspecialchars($book['title']) ?></span>
                            <?php endif; ?>
                            
                            <?php if ($index < 3): ?>
                            <span class="popular-badge">
                                <i class="bi bi-fire me-1"></i>#<?= $index + 1 ?> Popular
                            </span>
                            <?php endif; ?>
                            
                            <span class="category-badge">
                                <?= htmlspecialchars($book['category_name']) ?>
                            </span>
                            
                            <span class="views-count">
                                <i class="bi bi-eye me-1"></i><?= number_format($book['views']) ?> views
                            </span>
                        </div>
                        <div class="card-body">
                            <h6 class="card-title mb-2" style="min-height: 40px;">
                                <?= htmlspecialchars(truncateText($book['title'], 50)) ?>
                            </h6>
                            <p class="text-muted small mb-2">
                                <i class="bi bi-person me-1"></i>
                                <?= htmlspecialchars($book['author']) ?>
                            </p>
                            <p class="text-muted small mb-3">
                                <i class="bi bi-journal me-1"></i>
                                <?= $book['pages'] ?> halaman
                            </p>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="price-tag"><?= formatRupiah($book['price']) ?></span>
                                <button class="btn btn-sm btn-primary">
                                    <i class="bi bi-cart-plus"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Newest Books Section -->
    <div class="container mb-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold section-title">
                <i class="bi bi-clock-history text-success me-2"></i>Buku Terbaru
            </h2>
            <a href="books.php?sort=newest" class="btn btn-outline-primary">
                Lihat Semua <i class="bi bi-arrow-right ms-2"></i>
            </a>
        </div>
        
        <?php if (empty($newestBooks)): ?>
            <div class="alert alert-info text-center">
                <i class="bi bi-info-circle me-2"></i>
                Belum ada buku yang tersedia saat ini
            </div>
        <?php else: ?>
            <div class="row g-4">
                <?php foreach ($newestBooks as $book): ?>
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="card book-card" onclick="window.location.href='book-detail.php?id=<?= $book['id'] ?>'">
                        <div class="book-image">
                            <?php if ($book['cover_image']): ?>
                                <img src="<?= BOOK_COVER_URL . $book['cover_image'] ?>" 
                                     alt="<?= htmlspecialchars($book['title']) ?>">
                            <?php else: ?>
                                <span class="p-3 text-center"><?= htmlspecialchars($book['title']) ?></span>
                            <?php endif; ?>
                            <span class="category-badge">
                                <?= htmlspecialchars($book['category_name']) ?>
                            </span>
                        </div>
                        <div class="card-body">
                            <h6 class="card-title mb-2" style="min-height: 40px;">
                                <?= htmlspecialchars(truncateText($book['title'], 50)) ?>
                            </h6>
                            <p class="text-muted small mb-2">
                                <i class="bi bi-person me-1"></i>
                                <?= htmlspecialchars($book['author']) ?>
                            </p>
                            <p class="text-muted small mb-3">
                                <i class="bi bi-journal me-1"></i>
                                <?= $book['pages'] ?> halaman
                            </p>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="price-tag"><?= formatRupiah($book['price']) ?></span>
                                <button class="btn btn-sm btn-primary">
                                    <i class="bi bi-cart-plus"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- CTA Section -->
    <div class="container mb-5">
        <div class="card border-0" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 20px; overflow: hidden;">
            <div class="card-body text-white text-center py-5">
                <h2 class="fw-bold mb-3">Ingin Menjadi Penulis?</h2>
                <p class="lead mb-4">Bergabunglah dengan ZaiMedia dan publikasikan buku Anda ke ribuan pembaca</p>
                <a href="register.php" class="btn btn-light btn-lg px-5">
                    Daftar Sekarang <i class="bi bi-arrow-right ms-2"></i>
                </a>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h5 class="fw-bold mb-3">
                        <i class="bi bi-book-fill me-2"></i>ZaiMedia
                    </h5>
                    <p class="text-light">Platform toko buku online terpercaya dengan koleksi lengkap dan harga terjangkau.</p>
                </div>
                <div class="col-md-4 mb-4">
                    <h5 class="fw-bold mb-3">Quick Links</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="index.php" class="text-light text-decoration-none">Home</a></li>
                        <li class="mb-2"><a href="books.php" class="text-light text-decoration-none">Books</a></li>
                        <li class="mb-2"><a href="about.php" class="text-light text-decoration-none">About</a></li>
                        <li class="mb-2"><a href="contact.php" class="text-light text-decoration-none">Contact</a></li>
                    </ul>
                </div>
                <div class="col-md-4 mb-4">
                    <h5 class="fw-bold mb-3">Contact</h5>
                    <ul class="list-unstyled text-light">
                        <li class="mb-2"><i class="bi bi-envelope me-2"></i> info@zaimedia.com</li>
                        <li class="mb-2"><i class="bi bi-phone me-2"></i> +62 812-3456-7890</li>
                        <li class="mb-2"><i class="bi bi-geo-alt me-2"></i> Jakarta, Indonesia</li>
                    </ul>
                </div>
            </div>
            <hr class="bg-light">
            <div class="text-center text-light">
                <p class="mb-0">&copy; 2024 ZaiMedia Bookstore. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let currentSlide = 0;
        const slides = document.querySelectorAll('.banner-slide');
        const dots = document.querySelectorAll('.slider-dot');

        function showSlide(index) {
            slides.forEach(slide => slide.classList.remove('active'));
            dots.forEach(dot => dot.classList.remove('active'));

            slides[index].classList.add('active');
            dots[index].classList.add('active');
        }

        function nextSlide() {
            currentSlide = (currentSlide + 1) % slides.length;
            showSlide(currentSlide);
        }

        function prevSlide() {
            currentSlide = (currentSlide - 1 + slides.length) % slides.length;
            showSlide(currentSlide);
        }

        function goToSlide(index) {
            currentSlide = index;
            showSlide(currentSlide);
        }

        // Auto slide every 5 seconds
        setInterval(nextSlide, 5000);
    </script>
</body>
</html>