<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireRole('writer');

$user = getCurrentUser();
$conn = getDBConnection();
$writerId = $_SESSION['user_id'];

// Get writer balance
$stmt = $conn->prepare("SELECT * FROM writer_balance WHERE writer_id = ?");
$stmt->execute([$writerId]);
$balance = $stmt->fetch();

if (!$balance) {
    $stmt = $conn->prepare("INSERT INTO writer_balance (writer_id, available_balance) VALUES (?, 0)");
    $stmt->execute([$writerId]);
    $balance = ['available_balance' => 0, 'pending_balance' => 0, 'total_withdrawn' => 0];
}

// Get withdrawal history
$stmt = $conn->prepare("
    SELECT * FROM withdrawals 
    WHERE writer_id = ? 
    ORDER BY created_at DESC 
    LIMIT 20
");
$stmt->execute([$writerId]);
$withdrawals = $stmt->fetchAll();

// Process withdrawal request
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $amount = (float)$_POST['amount'];
    $bankName = sanitize($_POST['bank_name']);
    $accountNumber = sanitize($_POST['account_number']);
    $accountName = sanitize($_POST['account_name']);
    $notes = sanitize($_POST['notes'] ?? '');
    
    // Validation
    if ($amount < 50000) {
        $error = 'Minimum withdrawal adalah Rp 50.000';
    } elseif ($amount > $balance['available_balance']) {
        $error = 'Saldo tidak mencukupi';
    } elseif (empty($bankName) || empty($accountNumber) || empty($accountName)) {
        $error = 'Semua field bank harus diisi';
    } else {
        // Generate withdrawal number
        $withdrawalNumber = generateWithdrawalNumber();
        
        // Insert withdrawal request
        $stmt = $conn->prepare("
            INSERT INTO withdrawals (writer_id, withdrawal_number, amount, bank_name, account_number, account_name, notes, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')
        ");
        
        try {
            $stmt->execute([
                $writerId,
                $withdrawalNumber,
                $amount,
                $bankName,
                $accountNumber,
                $accountName,
                $notes
            ]);
            
            // Update balance
            $stmt = $conn->prepare("
                UPDATE writer_balance 
                SET available_balance = available_balance - ?,
                    pending_balance = pending_balance + ?
                WHERE writer_id = ?
            ");
            $stmt->execute([$amount, $amount, $writerId]);
            
            setFlash('success', 'Request withdrawal berhasil disubmit. Menunggu approval admin.');
            redirect('withdrawal.php');
            
        } catch (PDOException $e) {
            $error = 'Gagal submit withdrawal: ' . $e->getMessage();
        }
    }
}

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Withdrawal - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: white;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            position: fixed;
            width: 250px;
        }
        .sidebar-header {
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .menu-item {
            padding: 12px 20px;
            color: #333;
            text-decoration: none;
            display: block;
            transition: all 0.3s;
        }
        .menu-item:hover,
        .menu-item.active {
            background: #f8f9fa;
            color: #667eea;
            border-left: 3px solid #667eea;
        }
        .content-area {
            margin-left: 250px;
            padding: 30px;
        }
        .stats-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .balance-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0">Writer</h4>
            <small><?= htmlspecialchars($user['full_name']) ?></small>
        </div>
    <div class="sidebar-menu">
    <a href="dashboard.php" class="menu-item">
        <i class="bi bi-speedometer2 me-2"></i> Dashboard
    </a>
    <a href="books.php" class="menu-item">
        <i class="bi bi-book me-2"></i> My Books
    </a>
    <a href="book-add.php" class="menu-item">
        <i class="bi bi-plus-circle me-2"></i> Add New Book
    </a>
    <a href="royalty.php" class="menu-item">
        <i class="bi bi-cash-coin me-2"></i> Royalty
    </a>
    <a href="withdrawal.php" class="menu-item">
        <i class="bi bi-wallet2 me-2"></i> Withdrawal
    </a>
    <!-- TAMBAHKAN INI -->
    <a href="profile.php" class="menu-item">
        <i class="bi bi-person me-2"></i> Profile
    </a>
</div>
        <div style="position: absolute; bottom: 20px; width: 100%;">
            <a href="../index.php" class="menu-item">
                <i class="bi bi-house me-2"></i> Homepage
            </a>
            <a href="../logout.php" class="menu-item">
                <i class="bi bi-box-arrow-left me-2"></i> LogOut
            </a>
        </div>
    </div>

    <!-- Content Area -->
    <div class="content-area">
        <h2 class="mb-4">Withdrawal</h2>

        <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
            <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?= $error ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Balance Card -->
        <div class="balance-card">
            <div class="row">
                <div class="col-md-4">
                    <h6 class="mb-2 opacity-75">Saldo Tersedia</h6>
                    <h2 class="mb-0"><?= formatRupiah($balance['available_balance']) ?></h2>
                    <small class="opacity-75">Bisa ditarik</small>
                </div>
                <div class="col-md-4">
                    <h6 class="mb-2 opacity-75">Sedang Diproses</h6>
                    <h2 class="mb-0"><?= formatRupiah($balance['pending_balance']) ?></h2>
                    <small class="opacity-75">Pending approval</small>
                </div>
                <div class="col-md-4">
                    <h6 class="mb-2 opacity-75">Total Ditarik</h6>
                    <h2 class="mb-0"><?= formatRupiah($balance['total_withdrawn']) ?></h2>
                    <small class="opacity-75">All time</small>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Request Withdrawal Form -->
            <div class="col-md-5">
                <div class="stats-card">
                    <h5 class="mb-4">Request Withdrawal</h5>
                    
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Jumlah Penarikan <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text">Rp</span>
                                <input type="number" class="form-control" name="amount" 
                                       placeholder="50000" min="50000" 
                                       max="<?= $balance['available_balance'] ?>" required>
                            </div>
                            <small class="text-muted">Minimum Rp 50.000</small>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Nama Bank <span class="text-danger">*</span></label>
                            <select class="form-select" name="bank_name" required>
                                <option value="">Pilih Bank</option>
                                <option value="BCA">BCA</option>
                                <option value="Mandiri">Mandiri</option>
                                <option value="BNI">BNI</option>
                                <option value="BRI">BRI</option>
                                <option value="CIMB Niaga">CIMB Niaga</option>
                                <option value="Permata">Permata</option>
                                <option value="Danamon">Danamon</option>
                                <option value="BTN">BTN</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Nomor Rekening <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="account_number" 
                                   placeholder="1234567890" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Nama Pemilik Rekening <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="account_name" 
                                   placeholder="Nama sesuai rekening" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Catatan (Optional)</label>
                            <textarea class="form-control" name="notes" rows="2" 
                                      placeholder="Catatan tambahan..."></textarea>
                        </div>

                        <div class="alert alert-warning">
                            <small>
                                <i class="bi bi-info-circle me-2"></i>
                                Proses withdrawal biasanya 1-3 hari kerja setelah disetujui admin.
                            </small>
                        </div>

                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-send me-2"></i> Submit Request
                        </button>
                    </form>
                </div>
            </div>

            <!-- Withdrawal History -->
            <div class="col-md-7">
                <div class="stats-card">
                    <h5 class="mb-4">Riwayat Withdrawal</h5>

                    <?php if (empty($withdrawals)): ?>
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle me-2"></i>
                            Belum ada riwayat withdrawal
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>No. WD</th>
                                        <th>Amount</th>
                                        <th>Bank</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($withdrawals as $wd): ?>
                                    <tr>
                                        <td>
                                            <strong><?= htmlspecialchars($wd['withdrawal_number']) ?></strong>
                                        </td>
                                        <td class="fw-bold text-primary">
                                            <?= formatRupiah($wd['amount']) ?>
                                        </td>
                                        <td>
                                            <?= htmlspecialchars($wd['bank_name']) ?><br>
                                            <small class="text-muted"><?= htmlspecialchars($wd['account_number']) ?></small>
                                        </td>
                                        <td>
                                            <?php
                                            $statusBadge = [
                                                'pending' => 'warning',
                                                'approved' => 'info',
                                                'processing' => 'primary',
                                                'completed' => 'success',
                                                'rejected' => 'danger'
                                            ];
                                            ?>
                                            <span class="badge bg-<?= $statusBadge[$wd['status']] ?>">
                                                <?= ucfirst($wd['status']) ?>
                                            </span>
                                            <?php if ($wd['status'] === 'rejected' && $wd['rejection_reason']): ?>
                                            <br><small class="text-danger"><?= htmlspecialchars($wd['rejection_reason']) ?></small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <small><?= formatDateIndo($wd['created_at']) ?></small>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>