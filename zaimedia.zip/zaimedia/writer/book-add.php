<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
require_once '../api/books.php';

// Require writer role
requireRole('writer');

$user = getCurrentUser();
$conn = getDBConnection();

// Get categories
$stmt = $conn->query("SELECT * FROM categories ORDER BY name");
$categories = $stmt->fetchAll();

// Process form submission
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'writer_id' => $_SESSION['user_id'],
        'category_id' => sanitize($_POST['category_id']),
        'title' => sanitize($_POST['title']),
        'author' => sanitize($_POST['author']),
        'publisher' => sanitize($_POST['publisher']),
        'year' => sanitize($_POST['year']),
        'pages' => sanitize($_POST['pages']),
        'price' => sanitize($_POST['price']),
        'isbn' => sanitize($_POST['isbn'] ?? ''),
        'short_description' => sanitize($_POST['short_description']),
        'long_description' => sanitize($_POST['long_description'])
    ];
    
    $result = createBook($data, $_FILES);
    
    if (isset($result['success']) && $result['success']) {
        setFlash('success', $result['message']);
        redirect('books.php');
    } else {
        $error = isset($result['error']) ? $result['error'] : 'Terjadi kesalahan saat submit buku';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit New Book - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: white;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            position: fixed;
            width: 250px;
        }
        .sidebar-header {
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .menu-item {
            padding: 12px 20px;
            color: #333;
            text-decoration: none;
            display: block;
            transition: all 0.3s;
        }
        .menu-item:hover,
        .menu-item.active {
            background: #f8f9fa;
            color: #667eea;
            border-left: 3px solid #667eea;
        }
        .content-area {
            margin-left: 250px;
            padding: 30px;
        }
        .stats-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .upload-area {
            border: 2px dashed #ccc;
            border-radius: 10px;
            padding: 40px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
            background: #f8f9fa;
        }
        .upload-area:hover {
            border-color: #667eea;
            background-color: #e9ecef;
        }
        .upload-area i {
            font-size: 3rem;
            color: #667eea;
        }
        .upload-area.has-file {
            border-color: #28a745;
            background-color: #d4edda;
        }
        .upload-area.has-file i {
            color: #28a745;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0">Writer</h4>
            <small><?= htmlspecialchars($user['full_name']) ?></small>
        </div>
        <div class="sidebar-menu">
    <a href="dashboard.php" class="menu-item">
        <i class="bi bi-speedometer2 me-2"></i> Dashboard
    </a>
    <a href="books.php" class="menu-item">
        <i class="bi bi-book me-2"></i> My Books
    </a>
    <a href="book-add.php" class="menu-item">
        <i class="bi bi-plus-circle me-2"></i> Add New Book
    </a>
    <a href="royalty.php" class="menu-item">
        <i class="bi bi-cash-coin me-2"></i> Royalty
    </a>
    <a href="withdrawal.php" class="menu-item">
        <i class="bi bi-wallet2 me-2"></i> Withdrawal
    </a>
    <!-- TAMBAHKAN INI -->
    <a href="profile.php" class="menu-item">
        <i class="bi bi-person me-2"></i> Profile
    </a>
</div>
        <div style="position: absolute; bottom: 20px; width: 100%;">
            <a href="../index.php" class="menu-item">
                <i class="bi bi-house me-2"></i> Homepage
            </a>
            <a href="../logout.php" class="menu-item">
                <i class="bi bi-box-arrow-left me-2"></i> LogOut
            </a>
        </div>
    </div>

    <!-- Content Area -->
    <div class="content-area">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Submit New Book</h2>
            <a href="dashboard.php" class="btn btn-secondary">
                <i class="bi bi-arrow-left me-2"></i> Kembali
            </a>
        </div>

        <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?= $error ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <div class="row">
                <div class="col-md-4">
                    <!-- Cover Upload -->
                    <div class="stats-card">
                        <h5 class="mb-3">Cover Buku</h5>
                        <div class="upload-area" id="coverUploadArea" onclick="document.getElementById('coverInput').click()">
                            <i class="bi bi-image mb-3"></i>
                            <h6>Upload Cover Buku</h6>
                            <p class="text-muted small mb-0">JPG, PNG (Max 5MB)</p>
                            <input type="file" id="coverInput" name="cover_image" hidden accept="image/*" onchange="previewCover(event)">
                        </div>
                        <div id="coverPreview" style="display: none;" class="mt-3">
                            <img id="previewImage" src="" style="width: 100%; border-radius: 10px;">
                            <button type="button" class="btn btn-sm btn-outline-danger w-100 mt-2" onclick="removeCover()">
                                <i class="bi bi-trash me-2"></i> Remove
                            </button>
                        </div>
                    </div>

                    <!-- PDF Upload -->
                    <div class="stats-card">
                        <h5 class="mb-3">File PDF Buku</h5>
                        <div class="upload-area" id="pdfUploadArea" onclick="document.getElementById('pdfInput').click()">
                            <i class="bi bi-file-pdf mb-3"></i>
                            <h6>Upload PDF Buku</h6>
                            <p class="text-muted small mb-0">PDF Only (Max 50MB)</p>
                            <input type="file" id="pdfInput" name="pdf_file" hidden accept=".pdf" onchange="previewPDF(event)">
                        </div>
                        <div id="pdfInfo" style="display: none;" class="mt-3 p-3 bg-light rounded">
                            <div class="d-flex align-items-center justify-content-between">
                                <div class="d-flex align-items-center">
                                    <i class="bi bi-file-pdf text-danger fs-3 me-3"></i>
                                    <div>
                                        <h6 class="mb-0" id="pdfFileName">filename.pdf</h6>
                                        <small class="text-muted" id="pdfFileSize">0 MB</small>
                                    </div>
                                </div>
                                <button type="button" class="btn btn-sm btn-outline-danger" onclick="removePDF()">
                                    <i class="bi bi-x"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-8">
                    <div class="stats-card">
                        <h5 class="mb-3">Detail Buku</h5>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Judul Buku <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="title" placeholder="Masukkan judul buku" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Penulis <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="author" placeholder="Nama penulis" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Penerbit <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="publisher" placeholder="Nama penerbit" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Tahun Terbit <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" name="year" placeholder="2024" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Jumlah Halaman <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" name="pages" placeholder="320" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Harga (Rp) <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" name="price" placeholder="120000" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">ISBN</label>
                                <input type="text" class="form-control" name="isbn" placeholder="978-0735211292">
                            </div>
                            <div class="col-12 mb-3">
                                <label class="form-label">Kategori <span class="text-danger">*</span></label>
                                <select class="form-select" name="category_id" required>
                                    <option value="">Pilih Kategori</option>
                                    <?php foreach ($categories as $cat): ?>
                                    <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-12 mb-3">
                                <label class="form-label">Deskripsi Singkat <span class="text-danger">*</span></label>
                                <textarea class="form-control" name="short_description" rows="3" placeholder="Deskripsi singkat tentang buku..." required></textarea>
                                <small class="text-muted">Max 200 karakter</small>
                            </div>
                            <div class="col-12 mb-3">
                                <label class="form-label">Deskripsi Lengkap <span class="text-danger">*</span></label>
                                <textarea class="form-control" name="long_description" rows="5" placeholder="Deskripsi lengkap tentang buku..." required></textarea>
                            </div>
                        </div>
                        
                        <hr>
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle me-2"></i>
                            <strong>Catatan:</strong> Buku yang Anda submit akan direview oleh admin. Anda akan mendapat notifikasi setelah proses review selesai.
                        </div>
                        
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary px-4">
                                <i class="bi bi-send me-2"></i> Submit untuk Review
                            </button>
                            <a href="dashboard.php" class="btn btn-outline-secondary px-4">Batal</a>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let coverFile = null;
        let pdfFile = null;

        function previewCover(event) {
            const file = event.target.files[0];
            if (file) {
                if (file.size > 5 * 1024 * 1024) {
                    alert('File terlalu besar! Maximum 5MB');
                    return;
                }

                coverFile = file;
                const reader = new FileReader();
                reader.onload = function (e) {
                    document.getElementById('previewImage').src = e.target.result;
                    document.getElementById('coverPreview').style.display = 'block';
                    document.getElementById('coverUploadArea').style.display = 'none';
                }
                reader.readAsDataURL(file);
            }
        }

        function removeCover() {
            coverFile = null;
            document.getElementById('coverInput').value = '';
            document.getElementById('coverPreview').style.display = 'none';
            document.getElementById('coverUploadArea').style.display = 'block';
        }

        function previewPDF(event) {
            const file = event.target.files[0];
            if (file) {
                if (file.type !== 'application/pdf') {
                    alert('File harus berformat PDF!');
                    return;
                }

                if (file.size > 50 * 1024 * 1024) {
                    alert('File terlalu besar! Maximum 50MB');
                    return;
                }

                pdfFile = file;
                const sizeMB = (file.size / (1024 * 1024)).toFixed(2);

                document.getElementById('pdfFileName').textContent = file.name;
                document.getElementById('pdfFileSize').textContent = sizeMB + ' MB';
                document.getElementById('pdfInfo').style.display = 'block';
                document.getElementById('pdfUploadArea').classList.add('has-file');
            }
        }

        function removePDF() {
            pdfFile = null;
            document.getElementById('pdfInput').value = '';
            document.getElementById('pdfInfo').style.display = 'none';
            document.getElementById('pdfUploadArea').classList.remove('has-file');
        }
    </script>
</body>
</html>