<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireRole('writer');

$user = getCurrentUser();
$conn = getDBConnection();
$writerId = $_SESSION['user_id'];

// Get filters
$status = $_GET['status'] ?? 'all';
$search = $_GET['search'] ?? '';

// Build query
$sql = "SELECT b.*, c.name as category_name,
        (SELECT COUNT(*) FROM sales WHERE book_id = b.id) as total_sales,
        (SELECT SUM(royalty_amount) FROM sales WHERE book_id = b.id) as total_royalty
        FROM books b
        LEFT JOIN categories c ON b.category_id = c.id
        WHERE b.writer_id = ?";
$params = [$writerId];

if ($status !== 'all') {
    $sql .= " AND b.status = ?";
    $params[] = $status;
}

if (!empty($search)) {
    $sql .= " AND (b.title LIKE ? OR b.author LIKE ?)";
    $search_param = '%' . $search . '%';
    $params[] = $search_param;
    $params[] = $search_param;
}

$sql .= " ORDER BY b.created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$books = $stmt->fetchAll();

// Get stats
$stmt = $conn->prepare("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
        SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected
    FROM books
    WHERE writer_id = ?
");
$stmt->execute([$writerId]);
$stats = $stmt->fetch();

// Handle delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_book'])) {
    $bookId = (int)$_POST['book_id'];
    
    // Check if book belongs to writer
    $stmt = $conn->prepare("SELECT id FROM books WHERE id = ? AND writer_id = ?");
    $stmt->execute([$bookId, $writerId]);
    
    if ($stmt->fetch()) {
        // Delete book
        $stmt = $conn->prepare("DELETE FROM books WHERE id = ?");
        if ($stmt->execute([$bookId])) {
            setFlash('success', 'Buku berhasil dihapus');
        } else {
            setFlash('error', 'Gagal menghapus buku');
        }
    } else {
        setFlash('error', 'Buku tidak ditemukan');
    }
    
    redirect('books.php');
}

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Books - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: white;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            position: fixed;
            width: 250px;
        }
        .sidebar-header {
            padding: 20px;
            background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
            color: white;
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .menu-item {
            padding: 12px 20px;
            color: #333;
            text-decoration: none;
            display: block;
            transition: all 0.3s;
        }
        .menu-item:hover,
        .menu-item.active {
            background: #f8f9fa;
            color: #764ba2;
            border-left: 3px solid #764ba2;
        }
        .content-area {
            margin-left: 250px;
            padding: 30px;
        }
        .stats-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .book-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: all 0.3s;
        }
        .book-card:hover {
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }
        .book-cover-small {
            width: 80px;
            height: 110px;
            border-radius: 5px;
            object-fit: cover;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0">Writer</h4>
            <small><?= htmlspecialchars($user['full_name']) ?></small>
        </div>
      <div class="sidebar-menu">
    <a href="dashboard.php" class="menu-item">
        <i class="bi bi-speedometer2 me-2"></i> Dashboard
    </a>
    <a href="books.php" class="menu-item">
        <i class="bi bi-book me-2"></i> My Books
    </a>
    <a href="book-add.php" class="menu-item">
        <i class="bi bi-plus-circle me-2"></i> Add New Book
    </a>
    <a href="royalty.php" class="menu-item">
        <i class="bi bi-cash-coin me-2"></i> Royalty
    </a>
    <a href="withdrawal.php" class="menu-item">
        <i class="bi bi-wallet2 me-2"></i> Withdrawal
    </a>
    <!-- TAMBAHKAN INI -->
    <a href="profile.php" class="menu-item">
        <i class="bi bi-person me-2"></i> Profile
    </a>
</div>
        <div style="position: absolute; bottom: 20px; width: 100%;">
            <a href="../index.php" class="menu-item">
                <i class="bi bi-house me-2"></i> Homepage
            </a>
            <a href="../logout.php" class="menu-item">
                <i class="bi bi-box-arrow-left me-2"></i> LogOut
            </a>
        </div>
    </div>

    <!-- Content Area -->
    <div class="content-area">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>My Books</h2>
            <a href="book-add.php" class="btn btn-primary">
                <i class="bi bi-plus-circle me-2"></i> Add New Book
            </a>
        </div>

        <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
            <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Stats -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stats-card">
                    <h6 class="text-muted">Total Books</h6>
                    <h3><?= $stats['total'] ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <h6 class="text-muted">Approved</h6>
                    <h3 class="text-success"><?= $stats['approved'] ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <h6 class="text-muted">Pending</h6>
                    <h3 class="text-warning"><?= $stats['pending'] ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <h6 class="text-muted">Rejected</h6>
                    <h3 class="text-danger"><?= $stats['rejected'] ?></h3>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="stats-card">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <ul class="nav nav-pills">
                        <li class="nav-item">
                            <a class="nav-link <?= $status === 'all' ? 'active' : '' ?>" 
                               href="?status=all">
                                All (<?= $stats['total'] ?>)
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= $status === 'pending' ? 'active' : '' ?>" 
                               href="?status=pending">
                                Pending (<?= $stats['pending'] ?>)
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= $status === 'approved' ? 'active' : '' ?>" 
                               href="?status=approved">
                                Approved (<?= $stats['approved'] ?>)
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= $status === 'rejected' ? 'active' : '' ?>" 
                               href="?status=rejected">
                                Rejected (<?= $stats['rejected'] ?>)
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <form method="GET" class="d-flex">
                        <input type="hidden" name="status" value="<?= $status ?>">
                        <input type="text" class="form-control me-2" name="search" 
                               placeholder="Search books..." value="<?= htmlspecialchars($search) ?>">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-search"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Books List -->
        <?php if (empty($books)): ?>
            <div class="stats-card text-center py-5">
                <i class="bi bi-inbox display-1 text-muted"></i>
                <h4 class="mt-3">No Books Found</h4>
                <p class="text-muted">You haven't submitted any books yet.</p>
                <a href="book-add.php" class="btn btn-primary mt-3">
                    <i class="bi bi-plus-circle me-2"></i> Add Your First Book
                </a>
            </div>
        <?php else: ?>
            <?php foreach ($books as $book): ?>
            <div class="book-card">
                <div class="row align-items-center">
                    <div class="col-md-1">
                        <?php if ($book['cover_image']): ?>
                            <img src="<?= BOOK_COVER_URL . $book['cover_image'] ?>" 
                                 class="book-cover-small" 
                                 alt="<?= htmlspecialchars($book['title']) ?>">
                        <?php else: ?>
                            <div class="book-cover-small bg-gradient d-flex align-items-center justify-content-center text-white">
                                <i class="bi bi-book"></i>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-md-4">
                        <h6 class="mb-1"><?= htmlspecialchars($book['title']) ?></h6>
                        <small class="text-muted">
                            <i class="bi bi-person me-1"></i><?= htmlspecialchars($book['author']) ?>
                        </small>
                        <br>
                        <span class="badge bg-secondary"><?= htmlspecialchars($book['category_name']) ?></span>
                    </div>
                    
                    <div class="col-md-2 text-center">
                        <h6 class="text-primary mb-0"><?= formatRupiah($book['price']) ?></h6>
                        <small class="text-muted"><?= $book['pages'] ?> pages</small>
                    </div>
                    
                    <div class="col-md-2 text-center">
                        <?php
                        $statusBadge = [
                            'pending' => 'warning',
                            'approved' => 'success',
                            'rejected' => 'danger'
                        ];
                        ?>
                        <span class="badge bg-<?= $statusBadge[$book['status']] ?> mb-1">
                            <?= ucfirst($book['status']) ?>
                        </span>
                        <br>
                        <small class="text-muted">
                            <i class="bi bi-eye me-1"></i><?= number_format($book['views']) ?> views
                        </small>
                    </div>
                    
                    <div class="col-md-2 text-center">
                        <strong class="text-success d-block"><?= formatRupiah($book['total_royalty'] ?? 0) ?></strong>
                        <small class="text-muted"><?= $book['total_sales'] ?? 0 ?> sales</small>
                    </div>
                    
                    <div class="col-md-1 text-end">
                        <div class="dropdown">
                            <button class="btn btn-sm btn-outline-secondary dropdown-toggle" 
                                    data-bs-toggle="dropdown">
                                <i class="bi bi-three-dots-vertical"></i>
                            </button>
                            <ul class="dropdown-menu">
                                <li>
                                    <a class="dropdown-item" href="book-edit.php?id=<?= $book['id'] ?>">
                                        <i class="bi bi-pencil me-2"></i> Edit
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="../book-detail.php?id=<?= $book['id'] ?>" target="_blank">
                                        <i class="bi bi-eye me-2"></i> View
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <a class="dropdown-item text-danger" href="#" 
                                       onclick="deleteBook(<?= $book['id'] ?>, '<?= htmlspecialchars($book['title']) ?>')">
                                        <i class="bi bi-trash me-2"></i> Delete
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <?php if ($book['status'] === 'rejected' && $book['rejection_reason']): ?>
                <div class="alert alert-danger mt-3 mb-0">
                    <strong>Rejection Reason:</strong> <?= nl2br(htmlspecialchars($book['rejection_reason'])) ?>
                </div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function deleteBook(id, title) {
            if (confirm('Hapus buku "' + title + '"?\n\nTindakan ini tidak dapat dibatalkan!')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="delete_book" value="1">
                    <input type="hidden" name="book_id" value="${id}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>
</body>
</html>