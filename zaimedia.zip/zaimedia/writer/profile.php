<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireRole('writer');

$user = getCurrentUser();
$conn = getDBConnection();
$writerId = $_SESSION['user_id'];

// Handle profile update
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profile'])) {
        $data = [
            'full_name' => sanitize($_POST['full_name']),
            'email' => sanitize($_POST['email']),
            'phone' => sanitize($_POST['phone']),
            'address' => sanitize($_POST['address']),
            'city' => sanitize($_POST['city']),
            'postal_code' => sanitize($_POST['postal_code'])
        ];
        
        if (!empty($data['full_name']) && !empty($data['email'])) {
            // Check email uniqueness
            $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
            $stmt->execute([$data['email'], $writerId]);
            
            if ($stmt->fetch()) {
                $error = 'Email sudah digunakan';
            } else {
                $stmt = $conn->prepare("
                    UPDATE users 
                    SET full_name = ?, email = ?, phone = ?, address = ?, city = ?, postal_code = ?
                    WHERE id = ?
                ");
                
                if ($stmt->execute([
                    $data['full_name'],
                    $data['email'],
                    $data['phone'],
                    $data['address'],
                    $data['city'],
                    $data['postal_code'],
                    $writerId
                ])) {
                    setFlash('success', 'Profile berhasil diupdate');
                    redirect('profile.php');
                } else {
                    $error = 'Gagal update profile';
                }
            }
        } else {
            $error = 'Nama lengkap dan email harus diisi';
        }
    }
    
    if (isset($_POST['change_password'])) {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
            $error = 'Semua field password harus diisi';
        } elseif ($new_password !== $confirm_password) {
            $error = 'Konfirmasi password tidak cocok';
        } elseif (strlen($new_password) < 6) {
            $error = 'Password minimal 6 karakter';
        } else {
            $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
            $stmt->execute([$writerId]);
            $userData = $stmt->fetch();
            
            if (!password_verify($current_password, $userData['password'])) {
                $error = 'Password lama tidak sesuai';
            } else {
                $hashedPassword = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                
                if ($stmt->execute([$hashedPassword, $writerId])) {
                    setFlash('success', 'Password berhasil diubah');
                    redirect('profile.php');
                } else {
                    $error = 'Gagal mengubah password';
                }
            }
        }
    }
}

// Refresh user data
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$writerId]);
$user = $stmt->fetch();

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: white;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            position: fixed;
            width: 250px;
        }
        .sidebar-header {
            padding: 20px;
            background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
            color: white;
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .menu-item {
            padding: 12px 20px;
            color: #333;
            text-decoration: none;
            display: block;
            transition: all 0.3s;
        }
        .menu-item:hover,
        .menu-item.active {
            background: #f8f9fa;
            color: #764ba2;
            border-left: 3px solid #764ba2;
        }
        .content-area {
            margin-left: 250px;
            padding: 30px;
        }
        .profile-card {
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .profile-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 3rem;
            margin: 0 auto 20px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0">Writer</h4>
            <small><?= htmlspecialchars($user['full_name']) ?></small>
        </div>
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a href="books.php" class="menu-item">
                <i class="bi bi-book me-2"></i> My Books
            </a>
            <a href="book-add.php" class="menu-item">
                <i class="bi bi-plus-circle me-2"></i> Add New Book
            </a>
            <a href="royalty.php" class="menu-item">
                <i class="bi bi-cash-coin me-2"></i> Royalty
            </a>
            <a href="withdrawal.php" class="menu-item">
                <i class="bi bi-wallet2 me-2"></i> Withdrawal
            </a>
            <a href="profile.php" class="menu-item active">
                <i class="bi bi-person me-2"></i> Profile
            </a>
        </div>
        <div style="position: absolute; bottom: 20px; width: 100%;">
            <a href="../index.php" class="menu-item">
                <i class="bi bi-house me-2"></i> Homepage
            </a>
            <a href="../logout.php" class="menu-item">
                <i class="bi bi-box-arrow-left me-2"></i> LogOut
            </a>
        </div>
    </div>

    <!-- Content Area -->
    <div class="content-area">
        <h2 class="mb-4">My Profile</h2>

        <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
            <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?= $error ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-4">
                <div class="profile-card text-center">
                    <div class="profile-avatar">
                        <?= strtoupper(substr($user['full_name'], 0, 1)) ?>
                    </div>
                    <h4><?= htmlspecialchars($user['full_name']) ?></h4>
                    <p class="text-muted mb-3">@<?= htmlspecialchars($user['username']) ?></p>
                    <span class="badge bg-primary mb-3">Writer</span>
                    
                    <div class="text-start mt-4">
                        <p class="mb-2">
                            <i class="bi bi-envelope me-2 text-muted"></i>
                            <?= htmlspecialchars($user['email']) ?>
                        </p>
                        <?php if ($user['phone']): ?>
                        <p class="mb-2">
                            <i class="bi bi-telephone me-2 text-muted"></i>
                            <?= htmlspecialchars($user['phone']) ?>
                        </p>
                        <?php endif; ?>
                        <p class="mb-0">
                            <i class="bi bi-calendar me-2 text-muted"></i>
                            Member since <?= formatDateIndo($user['created_at']) ?>
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <!-- Edit Profile -->
                <div class="profile-card">
                    <h5 class="mb-4">
                        <i class="bi bi-pencil me-2"></i>Edit Profile
                    </h5>
                    
                    <form method="POST">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Full Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="full_name" 
                                       value="<?= htmlspecialchars($user['full_name']) ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email <span class="text-danger">*</span></label>
                                <input type="email" class="form-control" name="email" 
                                       value="<?= htmlspecialchars($user['email']) ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Username</label>
                                <input type="text" class="form-control" 
                                       value="<?= htmlspecialchars($user['username']) ?>" disabled>
                                <small class="text-muted">Username tidak bisa diubah</small>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Phone Number</label>
                                <input type="tel" class="form-control" name="phone" 
                                       value="<?= htmlspecialchars($user['phone'] ?? '') ?>" 
                                       placeholder="+62812345678">
                            </div>
                            <div class="col-12 mb-3">
                                <label class="form-label">Address</label>
                                <textarea class="form-control" name="address" rows="3"><?= htmlspecialchars($user['address'] ?? '') ?></textarea>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">City</label>
                                <input type="text" class="form-control" name="city" 
                                       value="<?= htmlspecialchars($user['city'] ?? '') ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Postal Code</label>
                                <input type="text" class="form-control" name="postal_code" 
                                       value="<?= htmlspecialchars($user['postal_code'] ?? '') ?>">
                            </div>
                        </div>
                        
                        <button type="submit" name="update_profile" class="btn btn-primary">
                            <i class="bi bi-save me-2"></i> Save Changes
                        </button>
                    </form>
                </div>

                <!-- Change Password -->
                <div class="profile-card">
                    <h5 class="mb-4">
                        <i class="bi bi-lock me-2"></i>Change Password
                    </h5>
                    
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Current Password <span class="text-danger">*</span></label>
                            <input type="password" class="form-control" name="current_password" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">New Password <span class="text-danger">*</span></label>
                            <input type="password" class="form-control" name="new_password" minlength="6" required>
                            <small class="text-muted">Minimal 6 karakter</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Confirm New Password <span class="text-danger">*</span></label>
                            <input type="password" class="form-control" name="confirm_password" minlength="6" required>
                        </div>
                        
                        <button type="submit" name="change_password" class="btn btn-warning">
                            <i class="bi bi-key me-2"></i> Change Password
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>