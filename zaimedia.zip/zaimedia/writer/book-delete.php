<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireRole('writer');

$conn = getDBConnection();
$writerId = $_SESSION['user_id'];
$bookId = $_GET['id'] ?? 0;

// Verify book ownership
$stmt = $conn->prepare("SELECT * FROM books WHERE id = ? AND writer_id = ?");
$stmt->execute([$bookId, $writerId]);
$book = $stmt->fetch();

if (!$book) {
    setFlash('error', 'Buku tidak ditemukan atau Anda tidak memiliki akses');
    redirect('books.php');
}

// Check if book has sales
$stmt = $conn->prepare("SELECT COUNT(*) FROM sales WHERE book_id = ?");
$stmt->execute([$bookId]);
$salesCount = $stmt->fetchColumn();

if ($salesCount > 0) {
    setFlash('error', 'Tidak dapat menghapus buku yang sudah memiliki penjualan');
    redirect('books.php');
}

// Delete book
try {
    $conn->beginTransaction();
    
    // Delete book files
    if ($book['cover_image'] && file_exists(BOOK_COVER_PATH . $book['cover_image'])) {
        unlink(BOOK_COVER_PATH . $book['cover_image']);
    }
    
    if ($book['pdf_file'] && file_exists(BOOK_PDF_PATH . $book['pdf_file'])) {
        unlink(BOOK_PDF_PATH . $book['pdf_file']);
    }
    
    // Delete from cart
    $stmt = $conn->prepare("DELETE FROM cart WHERE book_id = ?");
    $stmt->execute([$bookId]);
    
    // Delete reviews
    $stmt = $conn->prepare("DELETE FROM reviews WHERE book_id = ?");
    $stmt->execute([$bookId]);
    
    // Delete book
    $stmt = $conn->prepare("DELETE FROM books WHERE id = ?");
    $stmt->execute([$bookId]);
    
    $conn->commit();
    
    setFlash('success', 'Buku berhasil dihapus');
} catch (Exception $e) {
    $conn->rollBack();
    setFlash('error', 'Gagal menghapus buku: ' . $e->getMessage());
}

redirect('books.php');