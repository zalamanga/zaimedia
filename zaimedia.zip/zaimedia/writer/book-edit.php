<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireRole('writer');

$user = getCurrentUser();
$conn = getDBConnection();
$writerId = $_SESSION['user_id'];
$bookId = $_GET['id'] ?? 0;

// Get book data
$stmt = $conn->prepare("SELECT * FROM books WHERE id = ? AND writer_id = ?");
$stmt->execute([$bookId, $writerId]);
$book = $stmt->fetch();

if (!$book) {
    setFlash('error', 'Buku tidak ditemukan');
    redirect('books.php');
}

// Get categories
$stmt = $conn->query("SELECT * FROM categories ORDER BY name");
$categories = $stmt->fetchAll();

// Handle form submission
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'title' => sanitize($_POST['title']),
        'author' => sanitize($_POST['author']),
        'publisher' => sanitize($_POST['publisher']),
        'year' => (int)$_POST['year'],
        'pages' => (int)$_POST['pages'],
        'isbn' => sanitize($_POST['isbn']),
        'category_id' => (int)$_POST['category_id'],
        'price' => (int)$_POST['price'],
        'short_description' => sanitize($_POST['short_description']),
        'long_description' => sanitize($_POST['long_description'])
    ];
    
    // Validation
    $required = ['title', 'author', 'publisher', 'year', 'pages', 'category_id', 'price', 'short_description', 'long_description'];
    $isValid = true;
    foreach ($required as $field) {
        if (empty($data[$field])) {
            $error = 'Semua field harus diisi';
            $isValid = false;
            break;
        }
    }
    
    if ($isValid) {
        try {
            $conn->beginTransaction();
            
            // Handle cover image upload
            $coverImage = $book['cover_image'];
            if (isset($_FILES['cover_image']) && $_FILES['cover_image']['error'] === UPLOAD_ERR_OK) {
                $uploadResult = uploadBookCover($_FILES['cover_image']);
                if ($uploadResult['success']) {
                    // Delete old cover
                    if ($coverImage && file_exists(BOOK_COVER_PATH . $coverImage)) {
                        unlink(BOOK_COVER_PATH . $coverImage);
                    }
                    $coverImage = $uploadResult['filename'];
                } else {
                    $error = $uploadResult['error'];
                    $isValid = false;
                }
            }
            
            // Handle PDF upload
            $pdfFile = $book['pdf_file'];
            if (isset($_FILES['pdf_file']) && $_FILES['pdf_file']['error'] === UPLOAD_ERR_OK) {
                $uploadResult = uploadBookPDF($_FILES['pdf_file']);
                if ($uploadResult['success']) {
                    // Delete old PDF
                    if ($pdfFile && file_exists(BOOK_PDF_PATH . $pdfFile)) {
                        unlink(BOOK_PDF_PATH . $pdfFile);
                    }
                    $pdfFile = $uploadResult['filename'];
                } else {
                    $error = $uploadResult['error'];
                    $isValid = false;
                }
            }
            
            if ($isValid) {
                // Update book
                $stmt = $conn->prepare("
                    UPDATE books SET
                        title = ?,
                        author = ?,
                        publisher = ?,
                        year = ?,
                        pages = ?,
                        isbn = ?,
                        category_id = ?,
                        price = ?,
                        short_description = ?,
                        long_description = ?,
                        cover_image = ?,
                        pdf_file = ?,
                        status = 'pending'
                    WHERE id = ? AND writer_id = ?
                ");
                
                $stmt->execute([
                    $data['title'],
                    $data['author'],
                    $data['publisher'],
                    $data['year'],
                    $data['pages'],
                    $data['isbn'],
                    $data['category_id'],
                    $data['price'],
                    $data['short_description'],
                    $data['long_description'],
                    $coverImage,
                    $pdfFile,
                    $bookId,
                    $writerId
                ]);
                
                $conn->commit();
                
                setFlash('success', 'Buku berhasil diupdate dan menunggu review admin');
                redirect('books.php');
            } else {
                $conn->rollBack();
            }
            
        } catch (Exception $e) {
            $conn->rollBack();
            $error = 'Gagal update buku: ' . $e->getMessage();
        }
    }
}

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Book - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: white;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            position: fixed;
            width: 250px;
        }
        .sidebar-header {
            padding: 20px;
            background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
            color: white;
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .menu-item {
            padding: 12px 20px;
            color: #333;
            text-decoration: none;
            display: block;
            transition: all 0.3s;
        }
        .menu-item:hover,
        .menu-item.active {
            background: #f8f9fa;
            color: #764ba2;
            border-left: 3px solid #764ba2;
        }
        .content-area {
            margin-left: 250px;
            padding: 30px;
        }
        .form-card {
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .preview-image {
            max-width: 200px;
            border-radius: 5px;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0">Writer</h4>
            <small><?= htmlspecialchars($user['full_name']) ?></small>
        </div>
       <div class="sidebar-menu">
    <a href="dashboard.php" class="menu-item">
        <i class="bi bi-speedometer2 me-2"></i> Dashboard
    </a>
    <a href="books.php" class="menu-item">
        <i class="bi bi-book me-2"></i> My Books
    </a>
    <a href="book-add.php" class="menu-item">
        <i class="bi bi-plus-circle me-2"></i> Add New Book
    </a>
    <a href="royalty.php" class="menu-item">
        <i class="bi bi-cash-coin me-2"></i> Royalty
    </a>
    <a href="withdrawal.php" class="menu-item">
        <i class="bi bi-wallet2 me-2"></i> Withdrawal
    </a>
    <!-- TAMBAHKAN INI -->
    <a href="profile.php" class="menu-item">
        <i class="bi bi-person me-2"></i> Profile
    </a>
</div>
        <div style="position: absolute; bottom: 20px; width: 100%;">
            <a href="../index.php" class="menu-item">
                <i class="bi bi-house me-2"></i> Homepage
            </a>
            <a href="../logout.php" class="menu-item">
                <i class="bi bi-box-arrow-left me-2"></i> LogOut
            </a>
        </div>
    </div>

    <!-- Content Area -->
    <div class="content-area">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Edit Book</h2>
            <a href="books.php" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left me-2"></i> Back to My Books
            </a>
        </div>

        <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
            <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?= $error ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <div class="alert alert-warning">
            <i class="bi bi-info-circle me-2"></i>
            <strong>Note:</strong> Setelah update, buku akan kembali ke status "pending" dan menunggu review dari admin.
        </div>

        <form method="POST" enctype="multipart/form-data">
            <div class="form-card">
                <h5 class="mb-4">Book Information</h5>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Book Title <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="title" 
                               value="<?= htmlspecialchars($book['title']) ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Author <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="author" 
                               value="<?= htmlspecialchars($book['author']) ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Publisher <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="publisher" 
                               value="<?= htmlspecialchars($book['publisher']) ?>" required>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">Year <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" name="year" 
                               value="<?= $book['year'] ?>" min="1900" max="<?= date('Y') ?>" required>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">Pages <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" name="pages" 
                               value="<?= $book['pages'] ?>" min="1" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">ISBN</label>
                        <input type="text" class="form-control" name="isbn" 
                               value="<?= htmlspecialchars($book['isbn']) ?>">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">Category <span class="text-danger">*</span></label>
                        <select class="form-select" name="category_id" required>
                            <option value="">Select Category</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?= $cat['id'] ?>" <?= $book['category_id'] == $cat['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($cat['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">Price (Rp) <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" name="price" 
                               value="<?= $book['price'] ?>" min="1000" step="1000" required>
                    </div>
                </div>
            </div>

            <div class="form-card">
                <h5 class="mb-4">Description</h5>
                
                <div class="mb-3">
                    <label class="form-label">Short Description <span class="text-danger">*</span></label>
                    <textarea class="form-control" name="short_description" rows="3" 
                              required><?= htmlspecialchars($book['short_description']) ?></textarea>
                    <small class="text-muted">Brief description (max 200 characters)</small>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Long Description <span class="text-danger">*</span></label>
                    <textarea class="form-control" name="long_description" rows="8" 
                              required><?= htmlspecialchars($book['long_description']) ?></textarea>
                    <small class="text-muted">Detailed description about the book</small>
                </div>
            </div>

            <div class="form-card">
                <h5 class="mb-4">Files</h5>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Cover Image</label>
                        <input type="file" class="form-control" name="cover_image" accept="image/*">
                        <small class="text-muted">Leave empty to keep current cover</small>
                        <?php if ($book['cover_image']): ?>
                            <div class="mt-2">
                                <p class="mb-1"><strong>Current Cover:</strong></p>
                                <img src="<?= BOOK_COVER_URL . $book['cover_image'] ?>" 
                                     class="preview-image" alt="Current cover">
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">PDF File</label>
                        <input type="file" class="form-control" name="pdf_file" accept=".pdf">
                        <small class="text-muted">Leave empty to keep current PDF</small>
                        <?php if ($book['pdf_file']): ?>
                            <div class="mt-2">
                                <p class="mb-1"><strong>Current PDF:</strong></p>
                                <a href="<?= BOOK_PDF_URL . $book['pdf_file'] ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                    <i class="bi bi-file-pdf me-1"></i> View Current PDF
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="form-card">
                <button type="submit" class="btn btn-primary btn-lg">
                    <i class="bi bi-save me-2"></i> Update Book
                </button>
                <a href="books.php" class="btn btn-outline-secondary btn-lg">
                    Cancel
                </a>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>