<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireRole('writer');

$user = getCurrentUser();
$conn = getDBConnection();
$writerId = $_SESSION['user_id'];

// Get date filter
$month = $_GET['month'] ?? date('Y-m');
$bookFilter = $_GET['book_id'] ?? 'all';

// Get writer balance
// Get writer balance
$stmt = $conn->prepare("SELECT * FROM writer_balance WHERE writer_id = ?");
$stmt->execute([$writerId]);
$balance = $stmt->fetch();

if (!$balance) {
    // Create default balance if not exists
    $stmt = $conn->prepare("INSERT INTO writer_balance (writer_id, available_balance, pending_balance, withdrawn_balance) VALUES (?, 0, 0, 0)");
    $stmt->execute([$writerId]);
    
    $balance = [
        'available_balance' => 0,
        'pending_balance' => 0,
        'withdrawn_balance' => 0
    ];
} else {
    // Ensure all keys exist
    $balance['available_balance'] = $balance['available_balance'] ?? 0;
    $balance['pending_balance'] = $balance['pending_balance'] ?? 0;
    $balance['withdrawn_balance'] = $balance['withdrawn_balance'] ?? 0;
}

// Get writer books for filter
$stmt = $conn->prepare("SELECT id, title FROM books WHERE writer_id = ? ORDER BY title");
$stmt->execute([$writerId]);
$writerBooks = $stmt->fetchAll();

// Build sales query
$sql = "SELECT s.*, b.title as book_title, o.order_number, o.created_at as sale_date
        FROM sales s
        JOIN books b ON s.book_id = b.id
        JOIN orders o ON s.order_id = o.id
        WHERE s.writer_id = ?";
$params = [$writerId];

if ($month !== 'all') {
    $sql .= " AND DATE_FORMAT(o.created_at, '%Y-%m') = ?";
    $params[] = $month;
}

if ($bookFilter !== 'all') {
    $sql .= " AND s.book_id = ?";
    $params[] = $bookFilter;
}

$sql .= " ORDER BY o.created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$sales = $stmt->fetchAll();

// Calculate totals
$totalSales = 0;
$totalRoyalty = 0;
$totalBooks = 0;

foreach ($sales as $sale) {
    $totalSales += $sale['quantity'];
    $totalRoyalty += $sale['royalty_amount'];
    $totalBooks += $sale['quantity'];
}

// Get monthly stats (last 6 months)
$stmt = $conn->prepare("
    SELECT 
        DATE_FORMAT(o.created_at, '%Y-%m') as month,
        SUM(s.quantity) as total_sales,
        SUM(s.royalty_amount) as total_royalty
    FROM sales s
    JOIN orders o ON s.order_id = o.id
    WHERE s.writer_id = ?
    AND o.created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
    GROUP BY DATE_FORMAT(o.created_at, '%Y-%m')
    ORDER BY month DESC
");
$stmt->execute([$writerId]);
$monthlyStats = $stmt->fetchAll();

// Get best selling books
$stmt = $conn->prepare("
    SELECT 
        b.title,
        SUM(s.quantity) as total_sales,
        SUM(s.royalty_amount) as total_royalty
    FROM sales s
    JOIN books b ON s.book_id = b.id
    WHERE s.writer_id = ?
    GROUP BY s.book_id
    ORDER BY total_sales DESC
    LIMIT 5
");
$stmt->execute([$writerId]);
$bestSellers = $stmt->fetchAll();

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Royalty - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: white;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            position: fixed;
            width: 250px;
        }
        .sidebar-header {
            padding: 20px;
            background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
            color: white;
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .menu-item {
            padding: 12px 20px;
            color: #333;
            text-decoration: none;
            display: block;
            transition: all 0.3s;
        }
        .menu-item:hover,
        .menu-item.active {
            background: #f8f9fa;
            color: #764ba2;
            border-left: 3px solid #764ba2;
        }
        .content-area {
            margin-left: 250px;
            padding: 30px;
        }
        .stats-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            transition: transform 0.3s;
        }
        .stats-card:hover {
            transform: translateY(-5px);
        }
        .balance-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 20px;
        }
        .sale-item {
            background: white;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .chart-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0">Writer</h4>
            <small><?= htmlspecialchars($user['full_name']) ?></small>
        </div>
       <div class="sidebar-menu">
    <a href="dashboard.php" class="menu-item">
        <i class="bi bi-speedometer2 me-2"></i> Dashboard
    </a>
    <a href="books.php" class="menu-item">
        <i class="bi bi-book me-2"></i> My Books
    </a>
    <a href="book-add.php" class="menu-item">
        <i class="bi bi-plus-circle me-2"></i> Add New Book
    </a>
    <a href="royalty.php" class="menu-item">
        <i class="bi bi-cash-coin me-2"></i> Royalty
    </a>
    <a href="withdrawal.php" class="menu-item">
        <i class="bi bi-wallet2 me-2"></i> Withdrawal
    </a>
    <!-- TAMBAHKAN INI -->
    <a href="profile.php" class="menu-item">
        <i class="bi bi-person me-2"></i> Profile
    </a>
</div>
        <div style="position: absolute; bottom: 20px; width: 100%;">
            <a href="../index.php" class="menu-item">
                <i class="bi bi-house me-2"></i> Homepage
            </a>
            <a href="../logout.php" class="menu-item">
                <i class="bi bi-box-arrow-left me-2"></i> LogOut
            </a>
        </div>
    </div>

    <!-- Content Area -->
    <div class="content-area">
        <h2 class="mb-4">Royalty Tracking</h2>

        <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
            <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Balance Card -->
        <div class="balance-card">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h3 class="mb-3">Your Balance</h3>
                    <div class="row">
                        <div class="col-md-4">
                            <h6 class="opacity-75">Available</h6>
                            <h2><?= formatRupiah($balance['available_balance']) ?></h2>
                        </div>
                        <div class="col-md-4">
                            <h6 class="opacity-75">Pending</h6>
                            <h2><?= formatRupiah($balance['pending_balance']) ?></h2>
                        </div>
                        <div class="col-md-4">
                            <h6 class="opacity-75">Withdrawn</h6>
                            <h2><?= formatRupiah($balance['withdrawn_balance']) ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 text-end">
                    <a href="withdrawal.php" class="btn btn-light btn-lg">
                        <i class="bi bi-wallet2 me-2"></i> Withdraw
                    </a>
                </div>
            </div>
        </div>

        <!-- Stats Row -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="stats-card">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="bi bi-cart-check text-success" style="font-size: 2.5rem;"></i>
                        </div>
                        <div>
                            <h6 class="text-muted mb-0">Total Sales</h6>
                            <h3 class="mb-0"><?= $totalSales ?></h3>
                            <small class="text-muted">books sold</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stats-card">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="bi bi-cash-stack text-primary" style="font-size: 2.5rem;"></i>
                        </div>
                        <div>
                            <h6 class="text-muted mb-0">Total Royalty</h6>
                            <h3 class="mb-0"><?= formatRupiah($totalRoyalty) ?></h3>
                            <small class="text-muted">earned</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stats-card">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="bi bi-percent text-warning" style="font-size: 2.5rem;"></i>
                        </div>
                        <div>
                            <h6 class="text-muted mb-0">Royalty Rate</h6>
                            <h3 class="mb-0"><?= DEFAULT_ROYALTY_PERCENTAGE ?>%</h3>
                            <small class="text-muted">per book</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-8">
                <!-- Filters -->
                <div class="stats-card">
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <label class="form-label">Filter by Month</label>
                            <select class="form-select" onchange="window.location.href='royalty.php?month=' + this.value + '&book_id=<?= $bookFilter ?>'">
                                <option value="all" <?= $month === 'all' ? 'selected' : '' ?>>All Time</option>
                                <?php
                                for ($i = 0; $i < 12; $i++) {
                                    $date = date('Y-m', strtotime("-$i months"));
                                    $label = date('F Y', strtotime("-$i months"));
                                    echo "<option value='$date' " . ($month === $date ? 'selected' : '') . ">$label</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Filter by Book</label>
                            <select class="form-select" onchange="window.location.href='royalty.php?month=<?= $month ?>&book_id=' + this.value">
                                <option value="all" <?= $bookFilter === 'all' ? 'selected' : '' ?>>All Books</option>
                                <?php foreach ($writerBooks as $wb): ?>
                                    <option value="<?= $wb['id'] ?>" <?= $bookFilter == $wb['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($wb['title']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Sales List -->
                <div class="stats-card">
                    <h5 class="mb-4">
                        <i class="bi bi-list-ul me-2"></i>Sales History (<?= count($sales) ?>)
                    </h5>

                    <?php if (empty($sales)): ?>
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle me-2"></i>
                            No sales found for this period.
                        </div>
                    <?php else: ?>
                        <?php foreach ($sales as $sale): ?>
                        <div class="sale-item">
                            <div class="row align-items-center">
                                <div class="col-md-5">
                                    <h6 class="mb-1"><?= htmlspecialchars($sale['book_title']) ?></h6>
                                    <small class="text-muted">
                                        <i class="bi bi-receipt me-1"></i>
                                        Order: <?= htmlspecialchars($sale['order_number']) ?>
                                    </small>
                                </div>
                                <div class="col-md-2 text-center">
                                    <strong><?= $sale['quantity'] ?> book<?= $sale['quantity'] > 1 ? 's' : '' ?></strong>
                                    <br>
                                    <small class="text-muted"><?= formatRupiah($sale['book_price']) ?> each</small>
                                </div>
                                <div class="col-md-2 text-center">
                                    <span class="badge bg-success"><?= $sale['royalty_percentage'] ?>%</span>
                                    <br>
                                    <small class="text-muted">royalty</small>
                                </div>
                                <div class="col-md-2 text-end">
                                    <h5 class="text-success mb-0"><?= formatRupiah($sale['royalty_amount']) ?></h5>
                                </div>
                                <div class="col-md-1 text-end">
                                    <small class="text-muted"><?= formatDateIndo($sale['sale_date']) ?></small>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>

                        <div class="text-end mt-3 pt-3 border-top">
                            <h5>Total Royalty: <span class="text-success"><?= formatRupiah($totalRoyalty) ?></span></h5>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="col-md-4">
                <!-- Monthly Chart -->
                <div class="chart-card">
                    <h5 class="mb-4">Monthly Performance</h5>
                    <?php if (empty($monthlyStats)): ?>
                        <div class="alert alert-info">
                            No data available
                        </div>
                    <?php else: ?>
                        <div class="list-group list-group-flush">
                            <?php foreach ($monthlyStats as $stat): ?>
                            <div class="list-group-item px-0">
                                <div class="d-flex justify-content-between align-items-center mb-1">
                                    <strong><?= date('F Y', strtotime($stat['month'] . '-01')) ?></strong>
                                    <span class="badge bg-primary"><?= $stat['total_sales'] ?> sales</span>
                                </div>
                                <div class="progress" style="height: 20px;">
                                    <?php
                                    $maxRoyalty = max(array_column($monthlyStats, 'total_royalty'));
                                    $percentage = $maxRoyalty > 0 ? ($stat['total_royalty'] / $maxRoyalty * 100) : 0;
                                    ?>
                                    <div class="progress-bar bg-success" 
                                         style="width: <?= $percentage ?>%">
                                        <?= formatRupiah($stat['total_royalty']) ?>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Best Sellers -->
                <div class="chart-card">
                    <h5 class="mb-4">Best Selling Books</h5>
                    <?php if (empty($bestSellers)): ?>
                        <div class="alert alert-info">
                            No sales yet
                        </div>
                    <?php else: ?>
                        <div class="list-group list-group-flush">
                            <?php foreach ($bestSellers as $index => $book): ?>
                            <div class="list-group-item px-0">
                                <div class="d-flex align-items-center">
                                    <div class="me-3">
                                        <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center" 
                                             style="width: 40px; height: 40px;">
                                            <strong>#<?= $index + 1 ?></strong>
                                        </div>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h6 class="mb-0"><?= htmlspecialchars($book['title']) ?></h6>
                                        <small class="text-muted"><?= $book['total_sales'] ?> sold</small>
                                    </div>
                                    <div class="text-end">
                                        <strong class="text-success"><?= formatRupiah($book['total_royalty']) ?></strong>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Info Card -->
                <div class="stats-card">
                    <h6 class="mb-3">
                        <i class="bi bi-info-circle me-2"></i>Royalty Info
                    </h6>
                    <small class="text-muted">
                        Anda mendapatkan <strong><?= DEFAULT_ROYALTY_PERCENTAGE ?>%</strong> dari setiap penjualan buku.
                        <br><br>
                        Royalty akan masuk ke <strong>Available Balance</strong> setelah pembayaran customer dikonfirmasi.
                        <br><br>
                        Anda dapat melakukan withdrawal minimal <strong><?= formatRupiah(MIN_WITHDRAWAL) ?></strong>.
                    </small>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>