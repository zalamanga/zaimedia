<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireRole('writer');

$user = getCurrentUser();
$conn = getDBConnection();
$writerId = $_SESSION['user_id'];

// Get writer balance
$stmt = $conn->prepare("SELECT * FROM writer_balance WHERE writer_id = ?");
$stmt->execute([$writerId]);
$balance = $stmt->fetch();

if (!$balance) {
    // Create default balance
    $stmt = $conn->prepare("INSERT INTO writer_balance (writer_id, available_balance, pending_balance, total_withdrawn) VALUES (?, 0, 0, 0)");
    $stmt->execute([$writerId]);
    
    $balance = [
        'available_balance' => 0,
        'pending_balance' => 0,
        'total_withdrawn' => 0
    ];
} else {
    $balance['available_balance'] = $balance['available_balance'] ?? 0;
    $balance['pending_balance'] = $balance['pending_balance'] ?? 0;
    $balance['total_withdrawn'] = $balance['total_withdrawn'] ?? 0;
}

// Get book statistics
$stmt = $conn->prepare("
    SELECT 
        COUNT(*) as total_books,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_books,
        SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved_books,
        SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected_books,
        SUM(views) as total_views
    FROM books
    WHERE writer_id = ?
");
$stmt->execute([$writerId]);
$bookStats = $stmt->fetch();

// Get sales statistics
$stmt = $conn->prepare("
    SELECT 
        COUNT(*) as total_sales,
        SUM(quantity) as books_sold,
        SUM(royalty_amount) as total_royalty
    FROM sales
    WHERE writer_id = ?
");
$stmt->execute([$writerId]);
$salesStats = $stmt->fetch();

// Get recent sales
$stmt = $conn->prepare("
    SELECT s.*, b.title, o.order_number, o.created_at as sale_date
    FROM sales s
    JOIN books b ON s.book_id = b.id
    JOIN orders o ON s.order_id = o.id
    WHERE s.writer_id = ?
    ORDER BY o.created_at DESC
    LIMIT 5
");
$stmt->execute([$writerId]);
$recentSales = $stmt->fetchAll();

// Get pending books
$stmt = $conn->prepare("
    SELECT * FROM books 
    WHERE writer_id = ? AND status = 'pending'
    ORDER BY created_at DESC
    LIMIT 3
");
$stmt->execute([$writerId]);
$pendingBooks = $stmt->fetchAll();

// Monthly earnings (last 6 months)
$stmt = $conn->prepare("
    SELECT 
        DATE_FORMAT(o.created_at, '%Y-%m') as month,
        SUM(s.royalty_amount) as earnings,
        SUM(s.quantity) as sales_count
    FROM sales s
    JOIN orders o ON s.order_id = o.id
    WHERE s.writer_id = ?
    AND o.created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
    GROUP BY DATE_FORMAT(o.created_at, '%Y-%m')
    ORDER BY month ASC
");
$stmt->execute([$writerId]);
$monthlyEarnings = $stmt->fetchAll();

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writer Dashboard - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: white;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            position: fixed;
            width: 250px;
        }
        .sidebar-header {
            padding: 20px;
            background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
            color: white;
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .menu-item {
            padding: 12px 20px;
            color: #333;
            text-decoration: none;
            display: block;
            transition: all 0.3s;
        }
        .menu-item:hover,
        .menu-item.active {
            background: #f8f9fa;
            color: #764ba2;
            border-left: 3px solid #764ba2;
        }
        .content-area {
            margin-left: 250px;
            padding: 30px;
        }
        .stats-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            transition: transform 0.3s;
        }
        .stats-card:hover {
            transform: translateY(-5px);
        }
        .balance-card {
            background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
            color: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 20px;
        }
        .stats-icon {
            width: 60px;
            height: 60px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
        }
        .sale-item {
            padding: 15px;
            border-bottom: 1px solid #eee;
        }
        .sale-item:last-child {
            border-bottom: none;
        }
        .welcome-banner {
            background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
            color: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0">Writer</h4>
            <small><?= htmlspecialchars($user['full_name']) ?></small>
        </div>
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item active">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a href="books.php" class="menu-item">
                <i class="bi bi-book me-2"></i> My Books
            </a>
            <a href="book-add.php" class="menu-item">
                <i class="bi bi-plus-circle me-2"></i> Add New Book
            </a>
            <a href="royalty.php" class="menu-item">
                <i class="bi bi-cash-coin me-2"></i> Royalty
            </a>
            <a href="withdrawal.php" class="menu-item">
                <i class="bi bi-wallet2 me-2"></i> Withdrawal
            </a>
            <a href="profile.php" class="menu-item">
                <i class="bi bi-person me-2"></i> Profile
            </a>
        </div>
        <div style="position: absolute; bottom: 20px; width: 100%;">
            <a href="../index.php" class="menu-item">
                <i class="bi bi-house me-2"></i> Homepage
            </a>
            <a href="../logout.php" class="menu-item">
                <i class="bi bi-box-arrow-left me-2"></i> LogOut
            </a>
        </div>
    </div>

    <!-- Content Area -->
    <div class="content-area">
        <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
            <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Welcome Banner -->
        <div class="welcome-banner">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h2 class="mb-2">Welcome back, <?= htmlspecialchars($user['full_name']) ?>! ✍️</h2>
                    <p class="mb-0 opacity-75">Here's your writing performance today.</p>
                </div>
                <div class="col-md-4 text-end">
                    <h5><?= date('l, d F Y') ?></h5>
                    <p class="mb-0" id="currentTime"></p>
                </div>
            </div>
        </div>

        <!-- Balance Card -->
        <div class="balance-card">
            <h4 class="mb-4">Your Balance</h4>
            <div class="row">
                <div class="col-md-4">
                    <h6 class="opacity-75">Available Balance</h6>
                    <h2 class="mb-0"><?= formatRupiah($balance['available_balance']) ?></h2>
                    <small class="opacity-75">Dapat ditarik</small>
                </div>
                <div class="col-md-4">
                    <h6 class="opacity-75">Pending Balance</h6>
                    <h2 class="mb-0"><?= formatRupiah($balance['pending_balance']) ?></h2>
                    <small class="opacity-75">Menunggu konfirmasi</small>
                </div>
                <div class="col-md-4 text-end">
                    <?php if ($balance['available_balance'] >= MIN_WITHDRAWAL): ?>
                        <a href="withdrawal.php" class="btn btn-light btn-lg">
                            <i class="bi bi-wallet2 me-2"></i> Withdraw Now
                        </a>
                    <?php else: ?>
                        <p class="mb-2 small">Minimum withdrawal:</p>
                        <p class="mb-0"><?= formatRupiah(MIN_WITHDRAWAL) ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Stats Row -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="d-flex align-items-center">
                        <div class="stats-icon bg-primary bg-opacity-10 text-primary me-3">
                            <i class="bi bi-book"></i>
                        </div>
                        <div>
                            <h6 class="text-muted mb-0">Total Books</h6>
                            <h3 class="mb-0"><?= $bookStats['total_books'] ?></h3>
                            <small class="text-muted"><?= $bookStats['approved_books'] ?> approved</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="d-flex align-items-center">
                        <div class="stats-icon bg-success bg-opacity-10 text-success me-3">
                            <i class="bi bi-cart-check"></i>
                        </div>
                        <div>
                            <h6 class="text-muted mb-0">Books Sold</h6>
                            <h3 class="mb-0"><?= $salesStats['books_sold'] ?? 0 ?></h3>
                            <small class="text-muted"><?= $salesStats['total_sales'] ?? 0 ?> orders</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="d-flex align-items-center">
                        <div class="stats-icon bg-info bg-opacity-10 text-info me-3">
                            <i class="bi bi-eye"></i>
                        </div>
                        <div>
                            <h6 class="text-muted mb-0">Total Views</h6>
                            <h3 class="mb-0"><?= number_format($bookStats['total_views'] ?? 0) ?></h3>
                            <small class="text-muted">All books</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="d-flex align-items-center">
                        <div class="stats-icon bg-warning bg-opacity-10 text-warning me-3">
                            <i class="bi bi-cash-stack"></i>
                        </div>
                        <div>
                            <h6 class="text-muted mb-0">Total Royalty</h6>
                            <h3 class="mb-0 text-success"><?= formatRupiah($salesStats['total_royalty'] ?? 0) ?></h3>
                            <small class="text-muted">All time</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Alerts -->
        <?php if ($bookStats['pending_books'] > 0): ?>
        <div class="alert alert-warning d-flex align-items-center mb-4">
            <i class="bi bi-clock fs-3 me-3"></i>
            <div>
                <strong><?= $bookStats['pending_books'] ?> book(s)</strong> sedang menunggu review dari admin
                <a href="books.php?status=pending" class="alert-link ms-2">Lihat →</a>
            </div>
        </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-8">
                <!-- Earnings Chart -->
                <div class="stats-card">
                    <h5 class="mb-4">
                        <i class="bi bi-graph-up me-2"></i>Monthly Earnings (Last 6 Months)
                    </h5>
                    <canvas id="earningsChart" height="100"></canvas>
                </div>

                <!-- Recent Sales -->
                <div class="stats-card">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="mb-0">
                            <i class="bi bi-receipt me-2"></i>Recent Sales
                        </h5>
                        <a href="royalty.php" class="btn btn-sm btn-outline-primary">View All</a>
                    </div>

                    <?php if (empty($recentSales)): ?>
                        <div class="alert alert-info">
                            Belum ada penjualan. Terus promosikan buku Anda!
                        </div>
                    <?php else: ?>
                        <?php foreach ($recentSales as $sale): ?>
                        <div class="sale-item">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-1"><?= htmlspecialchars($sale['title']) ?></h6>
                                    <small class="text-muted">
                                        Order: <?= htmlspecialchars($sale['order_number']) ?> | 
                                        Qty: <?= $sale['quantity'] ?>
                                    </small>
                                </div>
                                <div class="text-end">
                                    <strong class="text-success d-block"><?= formatRupiah($sale['royalty_amount']) ?></strong>
                                    <small class="text-muted"><?= timeAgo($sale['sale_date']) ?></small>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <div class="col-md-4">
                <!-- Quick Actions -->
                <div class="stats-card">
                    <h5 class="mb-4">Quick Actions</h5>
                    <div class="d-grid gap-2">
                        <a href="book-add.php" class="btn btn-primary">
                            <i class="bi bi-plus-circle me-2"></i> Submit New Book
                        </a>
                        <a href="books.php" class="btn btn-outline-primary">
                            <i class="bi bi-book me-2"></i> Manage My Books
                        </a>
                        <a href="royalty.php" class="btn btn-outline-success">
                            <i class="bi bi-cash-coin me-2"></i> View Royalty
                        </a>
                        <?php if ($balance['available_balance'] >= MIN_WITHDRAWAL): ?>
                        <a href="withdrawal.php" class="btn btn-outline-warning">
                            <i class="bi bi-wallet2 me-2"></i> Request Withdrawal
                        </a>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Pending Books -->
                <?php if (!empty($pendingBooks)): ?>
                <div class="stats-card">
                    <h5 class="mb-4">
                        <i class="bi bi-clock-history me-2"></i>Pending Books
                    </h5>
                    <?php foreach ($pendingBooks as $book): ?>
                    <div class="sale-item">
                        <h6 class="mb-1"><?= htmlspecialchars(truncateText($book['title'], 40)) ?></h6>
                        <small class="text-muted">
                            <i class="bi bi-clock me-1"></i>
                            <?= timeAgo($book['created_at']) ?>
                        </small>
                    </div>
                    <?php endforeach; ?>
                    <a href="books.php?status=pending" class="btn btn-sm btn-outline-primary w-100 mt-3">
                        View All Pending
                    </a>
                </div>
                <?php endif; ?>

                <!-- Tips -->
                <div class="stats-card">
                    <h5 class="mb-3">💡 Writer Tips</h5>
                    <ul class="small mb-0">
                        <li class="mb-2">Upload cover yang menarik untuk meningkatkan penjualan</li>
                        <li class="mb-2">Tulis deskripsi yang jelas dan informatif</li>
                        <li class="mb-2">Royalty 70% dari setiap penjualan</li>
                        <li class="mb-0">Minimum withdrawal Rp 100.000</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Update clock
        function updateTime() {
            const now = new Date();
            const timeString = now.toLocaleTimeString('id-ID');
            document.getElementById('currentTime').textContent = timeString;
        }
        setInterval(updateTime, 1000);
        updateTime();

        // Earnings Chart
        const ctx = document.getElementById('earningsChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: [
                    <?php foreach ($monthlyEarnings as $me): ?>
                        '<?= date('M Y', strtotime($me['month'] . '-01')) ?>',
                    <?php endforeach; ?>
                ],
                datasets: [{
                    label: 'Earnings',
                    data: [
                        <?php foreach ($monthlyEarnings as $me): ?>
                            <?= $me['earnings'] ?>,
                        <?php endforeach; ?>
                    ],
                    borderColor: '#764ba2',
                    backgroundColor: 'rgba(118, 75, 162, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return 'Rp ' + context.parsed.y.toLocaleString('id-ID');
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'Rp ' + (value/1000) + 'k';
                            }
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>