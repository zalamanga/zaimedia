<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>500 - Server Error - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .error-container {
            text-align: center;
            color: white;
        }
        .error-code {
            font-size: 150px;
            font-weight: bold;
            line-height: 1;
            text-shadow: 0 5px 20px rgba(0,0,0,0.3);
        }
        .error-icon {
            font-size: 100px;
            margin-bottom: 30px;
        }
        .error-card {
            background: white;
            border-radius: 20px;
            padding: 50px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            color: #333;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="error-container">
            <div class="error-card">
                <i class="bi bi-server error-icon text-danger"></i>
                <h1 class="error-code">500</h1>
                <h3 class="mb-4">Internal Server Error</h3>
                <p class="text-muted mb-4">
                    Maaf, terjadi kesalahan pada server kami.
                    <br>Tim kami sedang bekerja untuk memperbaikinya.
                </p>
                <div class="d-flex gap-3 justify-content-center">
                    <a href="index.php" class="btn btn-primary btn-lg">
                        <i class="bi bi-house me-2"></i> Back to Home
                    </a>
                    <a href="javascript:location.reload()" class="btn btn-outline-secondary btn-lg">
                        <i class="bi bi-arrow-clockwise me-2"></i> Retry
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>