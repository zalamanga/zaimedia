<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

requireLogin();

$conn = getDBConnection();
$customerId = $_SESSION['user_id'];
$user = getCurrentUser();

// Get cart items
$stmt = $conn->prepare("
    SELECT c.*, b.title, b.author, b.price, b.cover_image, b.writer_id
    FROM cart c
    JOIN books b ON c.book_id = b.id
    WHERE c.customer_id = ? AND b.status = 'approved'
");
$stmt->execute([$customerId]);
$cartItems = $stmt->fetchAll();

if (empty($cartItems)) {
    setFlash('error', 'Cart Anda kosong');
    redirect('cart.php');
}

// Calculate totals
$subtotal = 0;
foreach ($cartItems as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}

$shippingCost = 0; // Digital product, no shipping
$tax = calculateTax($subtotal);
$total = $subtotal + $shippingCost + $tax;

// Process checkout
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'shipping_name' => sanitize($_POST['shipping_name']),
        'shipping_phone' => sanitize($_POST['shipping_phone']),
        'shipping_address' => sanitize($_POST['shipping_address']),
        'shipping_city' => sanitize($_POST['shipping_city']),
        'shipping_postal_code' => sanitize($_POST['shipping_postal_code']),
        'shipping_method' => 'regular', // Digital delivery
        'payment_method' => sanitize($_POST['payment_method']),
        'notes' => sanitize($_POST['notes'] ?? '')
    ];
    
    // Validation
    $required = ['shipping_name', 'shipping_phone', 'shipping_address', 'shipping_city', 
                 'shipping_postal_code', 'payment_method'];
    $isValid = true;
    foreach ($required as $field) {
        if (empty($data[$field])) {
            $error = 'Semua field harus diisi';
            $isValid = false;
            break;
        }
    }
    
    if ($isValid) {
        try {
            $conn->beginTransaction();
            
            // Generate order number
            $orderNumber = generateOrderNumber();
            
            // Insert order (AUTO PAID - DUMMY MODE)
            $stmt = $conn->prepare("
                INSERT INTO orders (
                    customer_id, order_number, subtotal, shipping_cost, tax, total,
                    payment_method, payment_status, order_status,
                    shipping_name, shipping_phone, shipping_address, shipping_city, 
                    shipping_postal_code, shipping_method, notes
                ) VALUES (?, ?, ?, ?, ?, ?, ?, 'paid', 'processing', ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $customerId,
                $orderNumber,
                $subtotal,
                $shippingCost,
                $tax,
                $total,
                $data['payment_method'],
                $data['shipping_name'],
                $data['shipping_phone'],
                $data['shipping_address'],
                $data['shipping_city'],
                $data['shipping_postal_code'],
                $data['shipping_method'],
                $data['notes']
            ]);
            
            $orderId = $conn->lastInsertId();
            
            // Insert order items & sales
            foreach ($cartItems as $item) {
                // Insert order item
                $stmt = $conn->prepare("
                    INSERT INTO order_items (order_id, book_id, quantity, price, subtotal)
                    VALUES (?, ?, ?, ?, ?)
                ");
                $itemSubtotal = $item['price'] * $item['quantity'];
                $stmt->execute([
                    $orderId,
                    $item['book_id'],
                    $item['quantity'],
                    $item['price'],
                    $itemSubtotal
                ]);
                
                // Calculate royalty
                $royalty = calculateRoyalty($item['price'], $item['quantity']);
                
                // Insert sales record
                $stmt = $conn->prepare("
                    INSERT INTO sales (book_id, writer_id, order_id, quantity, book_price, royalty_percentage, royalty_amount)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $item['book_id'],
                    $item['writer_id'],
                    $orderId,
                    $item['quantity'],
                    $item['price'],
                    DEFAULT_ROYALTY_PERCENTAGE,
                    $royalty
                ]);
                
                // Update writer balance (INSTANT - DUMMY MODE)
                $stmt = $conn->prepare("
                    INSERT INTO writer_balance (writer_id, available_balance)
                    VALUES (?, ?)
                    ON DUPLICATE KEY UPDATE available_balance = available_balance + ?
                ");
                $stmt->execute([$item['writer_id'], $royalty, $royalty]);
            }
            
            // Clear cart
            $stmt = $conn->prepare("DELETE FROM cart WHERE customer_id = ?");
            $stmt->execute([$customerId]);
            
            $conn->commit();
            
            setFlash('success', 'Order berhasil dibuat & dibayar! Order Number: ' . $orderNumber);
            redirect('order-success.php?order=' . $orderNumber);
            
        } catch (Exception $e) {
            $conn->rollBack();
            $error = 'Gagal membuat order: ' . $e->getMessage();
        }
    }
}

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .checkout-card {
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .summary-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: sticky;
            top: 20px;
        }
        .order-item {
            padding: 15px 0;
            border-bottom: 1px solid #eee;
        }
        .order-item:last-child {
            border-bottom: none;
        }
        .payment-method {
            border: 2px solid #dee2e6;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
            cursor: pointer;
            transition: all 0.3s;
        }
        .payment-method:hover {
            border-color: #667eea;
            background: #f8f9fa;
        }
        .payment-method.selected {
            border-color: #667eea;
            background: #e7f1ff;
        }
        .payment-icon {
            width: 50px;
            height: 50px;
            background: #f8f9fa;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }
    </style>
</head>
<body>
    <div class="container my-5">
        <!-- Header -->
        <div class="text-center mb-4">
            <a href="index.php" class="text-decoration-none">
                <h2 class="fw-bold">
                    <i class="bi bi-book-fill text-primary me-2"></i>ZaiMedia
                </h2>
            </a>
            <p class="text-muted">Complete your order</p>
        </div>

        <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
            <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?= $error ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <form method="POST" id="checkoutForm">
            <div class="row">
                <div class="col-md-7">
                    <!-- Shipping Information -->
                    <div class="checkout-card">
                        <h5 class="mb-4">
                            <i class="bi bi-truck me-2"></i>Informasi Pengiriman
                        </h5>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="shipping_name" 
                                       value="<?= htmlspecialchars($user['full_name']) ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Nomor Telepon <span class="text-danger">*</span></label>
                                <input type="tel" class="form-control" name="shipping_phone" 
                                       value="<?= htmlspecialchars($user['phone'] ?? '') ?>" 
                                       placeholder="+62812345678" required>
                            </div>
                            <div class="col-12 mb-3">
                                <label class="form-label">Alamat Lengkap <span class="text-danger">*</span></label>
                                <textarea class="form-control" name="shipping_address" rows="3" 
                                          placeholder="Jl. Contoh No. 123, RT/RW 01/02" required><?= htmlspecialchars($user['address'] ?? '') ?></textarea>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Kota <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="shipping_city" 
                                       value="<?= htmlspecialchars($user['city'] ?? '') ?>" 
                                       placeholder="Jakarta" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Kode Pos <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="shipping_postal_code" 
                                       value="<?= htmlspecialchars($user['postal_code'] ?? '') ?>" 
                                       placeholder="12345" required>
                            </div>
                        </div>
                    </div>

                    <!-- Delivery Method -->
                    <div class="checkout-card">
                        <h5 class="mb-4">
                            <i class="bi bi-box-seam me-2"></i>Metode Pengiriman
                        </h5>
                        
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle me-2"></i>
                            <strong>Pengiriman Digital</strong> - Produk digital akan dikirim via email & tersedia untuk download di My Library setelah pembayaran selesai.
                        </div>
                        
                        <div class="d-flex align-items-center p-3 bg-light rounded">
                            <div class="payment-icon me-3">
                                <i class="bi bi-envelope-check text-primary"></i>
                            </div>
                            <div>
                                <strong>Email Delivery - Instant</strong>
                                <br><small class="text-muted">Download link akan dikirim ke email Anda</small>
                            </div>
                            <div class="ms-auto">
                                <span class="badge bg-success">FREE</span>
                            </div>
                        </div>
                    </div>

                    <!-- Payment Method -->
                    <div class="checkout-card">
                        <h5 class="mb-4">
                            <i class="bi bi-credit-card me-2"></i>Metode Pembayaran
                        </h5>
                        
                        <div class="alert alert-warning">
                            <i class="bi bi-exclamation-triangle me-2"></i>
                            <strong>Demo Mode:</strong> Pembayaran akan otomatis berhasil untuk keperluan testing.
                        </div>
                        
                        <div class="payment-method" onclick="selectPayment('bank_transfer')">
                            <input type="radio" name="payment_method" id="bank_transfer" 
                                   value="bank_transfer" checked required class="d-none">
                            <div class="d-flex align-items-center">
                                <div class="payment-icon me-3">
                                    <i class="bi bi-bank text-primary"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <strong>Bank Transfer</strong>
                                    <br><small class="text-muted">BCA, Mandiri, BNI, BRI</small>
                                </div>
                                <div>
                                    <i class="bi bi-check-circle-fill text-success fs-4 payment-check" style="display: none;"></i>
                                </div>
                            </div>
                        </div>
                        
                        <div class="payment-method" onclick="selectPayment('e_wallet')">
                            <input type="radio" name="payment_method" id="e_wallet" 
                                   value="e_wallet" required class="d-none">
                            <div class="d-flex align-items-center">
                                <div class="payment-icon me-3">
                                    <i class="bi bi-wallet2 text-success"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <strong>E-Wallet</strong>
                                    <br><small class="text-muted">GoPay, OVO, Dana, LinkAja</small>
                                </div>
                                <div>
                                    <i class="bi bi-check-circle-fill text-success fs-4 payment-check" style="display: none;"></i>
                                </div>
                            </div>
                        </div>
                        
                        <div class="payment-method" onclick="selectPayment('credit_card')">
                            <input type="radio" name="payment_method" id="credit_card" 
                                   value="credit_card" required class="d-none">
                            <div class="d-flex align-items-center">
                                <div class="payment-icon me-3">
                                    <i class="bi bi-credit-card text-info"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <strong>Credit/Debit Card</strong>
                                    <br><small class="text-muted">Visa, Mastercard, JCB</small>
                                </div>
                                <div>
                                    <i class="bi bi-check-circle-fill text-success fs-4 payment-check" style="display: none;"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Notes -->
                    <div class="checkout-card">
                        <h5 class="mb-4">
                            <i class="bi bi-pencil me-2"></i>Catatan Order (Opsional)
                        </h5>
                        <textarea class="form-control" name="notes" rows="3" 
                                  placeholder="Catatan tambahan untuk order Anda..."></textarea>
                    </div>
                </div>

                <!-- Order Summary -->
                <div class="col-md-5">
                    <div class="summary-card">
                        <h5 class="mb-4">Ringkasan Order</h5>
                        
                        <!-- Order Items -->
                        <div class="mb-3">
                            <?php foreach ($cartItems as $item): ?>
                            <div class="order-item">
                                <div class="d-flex">
                                    <div style="width: 50px; height: 70px; border-radius: 5px; overflow: hidden; margin-right: 15px;">
                                        <?php if ($item['cover_image']): ?>
                                            <img src="<?= BOOK_COVER_URL . $item['cover_image'] ?>" 
                                                 style="width: 100%; height: 100%; object-fit: cover;"
                                                 alt="<?= htmlspecialchars($item['title']) ?>">
                                        <?php else: ?>
                                            <div class="bg-gradient text-white d-flex align-items-center justify-content-center h-100">
                                                <i class="bi bi-book"></i>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h6 class="mb-1"><?= htmlspecialchars($item['title']) ?></h6>
                                        <small class="text-muted">Qty: <?= $item['quantity'] ?> x <?= formatRupiah($item['price']) ?></small>
                                    </div>
                                    <div class="text-end">
                                        <strong><?= formatRupiah($item['price'] * $item['quantity']) ?></strong>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <hr>
                        
                        <!-- Calculation -->
                        <div class="d-flex justify-content-between mb-2">
                            <span>Subtotal (<?= count($cartItems) ?> items)</span>
                            <strong><?= formatRupiah($subtotal) ?></strong>
                        </div>
                        
                        <div class="d-flex justify-content-between mb-2">
                            <span>Ongkir</span>
                            <strong class="text-success">FREE</strong>
                        </div>
                        
                        <div class="d-flex justify-content-between mb-3">
                            <span>PPN (<?= TAX_PERCENTAGE ?>%)</span>
                            <strong><?= formatRupiah($tax) ?></strong>
                        </div>
                        
                        <hr>
                        
                        <div class="d-flex justify-content-between mb-4">
                            <h6>Total Pembayaran</h6>
                            <h4 class="text-primary mb-0"><?= formatRupiah($total) ?></h4>
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-100 btn-lg mb-2" id="placeOrderBtn">
                            <i class="bi bi-lock-fill me-2"></i> Bayar Sekarang
                        </button>
                        
                        <a href="cart.php" class="btn btn-outline-secondary w-100">
                            <i class="bi bi-arrow-left me-2"></i> Kembali ke Cart
                        </a>
                        
                        <div class="mt-4 p-3 bg-light rounded">
                            <div class="d-flex align-items-center mb-2">
                                <i class="bi bi-shield-check text-success fs-4 me-2"></i>
                                <div>
                                    <strong>Pembayaran Aman</strong>
                                    <br><small class="text-muted">Data Anda terenkripsi</small>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mt-3 p-3 bg-light rounded">
                            <div class="d-flex align-items-center">
                                <i class="bi bi-cash-coin text-warning fs-4 me-2"></i>
                                <div>
                                    <strong>Garansi Uang Kembali</strong>
                                    <br><small class="text-muted">Kebijakan return 7 hari</small>
                                </div>
                            </div>
                        </div>

                        <div class="mt-3 p-3 bg-warning bg-opacity-10 rounded border border-warning">
                            <small>
                                <i class="bi bi-info-circle me-2"></i>
                                <strong>Mode Demo:</strong> Pembayaran akan langsung berhasil untuk testing.
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Initialize first payment method as selected
        document.addEventListener('DOMContentLoaded', function() {
            selectPayment('bank_transfer');
        });

        function selectPayment(method) {
            // Remove all selected classes
            document.querySelectorAll('.payment-method').forEach(el => {
                el.classList.remove('selected');
                el.querySelector('.payment-check').style.display = 'none';
            });
            
            // Add selected class to clicked method
            const selectedMethod = document.getElementById(method).closest('.payment-method');
            selectedMethod.classList.add('selected');
            selectedMethod.querySelector('.payment-check').style.display = 'block';
            
            // Check the radio button
            document.getElementById(method).checked = true;
        }

        // Form submission with loading state
        document.getElementById('checkoutForm').addEventListener('submit', function(e) {
            const btn = document.getElementById('placeOrderBtn');
            btn.disabled = true;
            btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Memproses...';
        });
    </script>
</body>
</html>