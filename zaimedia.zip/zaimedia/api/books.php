<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

/**
 * Create new book
 */
function createBook($data, $files) {
    $conn = getDBConnection();
    
    // Validate required fields
    if (empty($data['title']) || empty($data['author']) || empty($data['price'])) {
        return [
            'success' => false,
            'error' => 'Title, author, and price are required'
        ];
    }
    
    // Upload cover image
    if (!isset($files['cover_image']) || $files['cover_image']['error'] !== UPLOAD_ERR_OK) {
        return [
            'success' => false,
            'error' => 'Cover image is required'
        ];
    }
    
    $coverUpload = uploadBookCover($files['cover_image']);
    if (!$coverUpload['success']) {
        return $coverUpload;
    }
    
    // Upload PDF file
    if (!isset($files['pdf_file']) || $files['pdf_file']['error'] !== UPLOAD_ERR_OK) {
        return [
            'success' => false,
            'error' => 'PDF file is required'
        ];
    }
    
    $pdfUpload = uploadBookPDF($files['pdf_file']);
    if (!$pdfUpload['success']) {
        // Delete uploaded cover if PDF upload fails
        if (file_exists(BOOK_COVER_PATH . $coverUpload['filename'])) {
            unlink(BOOK_COVER_PATH . $coverUpload['filename']);
        }
        return $pdfUpload;
    }
    
    // Insert book with ALL fields
    try {
        $stmt = $conn->prepare("
            INSERT INTO books (
                writer_id, category_id, title, author, publisher, year, pages, 
                price, isbn, short_description, long_description, cover_image, 
                pdf_file, status, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', NOW())
        ");
        
        $result = $stmt->execute([
            $data['writer_id'],
            $data['category_id'],
            $data['title'],
            $data['author'],
            $data['publisher'] ?? '',
            $data['year'] ?? null,
            $data['pages'] ?? null,
            $data['price'],
            $data['isbn'] ?? '',
            $data['short_description'] ?? '',
            $data['long_description'] ?? '',
            $coverUpload['filename'],
            $pdfUpload['filename']
        ]);
        
        if ($result) {
            return [
                'success' => true,
                'message' => 'Buku berhasil disubmit dan menunggu review',
                'book_id' => $conn->lastInsertId()
            ];
        } else {
            // Delete uploaded files if insert fails
            if (file_exists(BOOK_COVER_PATH . $coverUpload['filename'])) {
                unlink(BOOK_COVER_PATH . $coverUpload['filename']);
            }
            if (file_exists(BOOK_PDF_PATH . $pdfUpload['filename'])) {
                unlink(BOOK_PDF_PATH . $pdfUpload['filename']);
            }
            
            return [
                'success' => false,
                'error' => 'Failed to insert book'
            ];
        }
    } catch (Exception $e) {
        // Delete uploaded files if error
        if (file_exists(BOOK_COVER_PATH . $coverUpload['filename'])) {
            unlink(BOOK_COVER_PATH . $coverUpload['filename']);
        }
        if (file_exists(BOOK_PDF_PATH . $pdfUpload['filename'])) {
            unlink(BOOK_PDF_PATH . $pdfUpload['filename']);
        }
        
        return [
            'success' => false,
            'error' => $e->getMessage()
        ];
    }
}

/**
 * Update existing book
 */
function updateBook($bookId, $data, $files = []) {
    $conn = getDBConnection();
    
    // Get current book data
    $stmt = $conn->prepare("SELECT * FROM books WHERE id = ?");
    $stmt->execute([$bookId]);
    $currentBook = $stmt->fetch();
    
    if (!$currentBook) {
        return [
            'success' => false,
            'error' => 'Book not found'
        ];
    }
    
    $coverFilename = $currentBook['cover_image'];
    $pdfFilename = $currentBook['pdf_file'];
    
    // Upload new cover if provided
    if (isset($files['cover_image']) && $files['cover_image']['error'] === UPLOAD_ERR_OK) {
        $coverUpload = uploadBookCover($files['cover_image']);
        if (!$coverUpload['success']) {
            return $coverUpload;
        }
        
        // Delete old cover
        if ($currentBook['cover_image'] && file_exists(BOOK_COVER_PATH . $currentBook['cover_image'])) {
            unlink(BOOK_COVER_PATH . $currentBook['cover_image']);
        }
        
        $coverFilename = $coverUpload['filename'];
    }
    
    // Upload new PDF if provided
    if (isset($files['pdf_file']) && $files['pdf_file']['error'] === UPLOAD_ERR_OK) {
        $pdfUpload = uploadBookPDF($files['pdf_file']);
        if (!$pdfUpload['success']) {
            return $pdfUpload;
        }
        
        // Delete old PDF
        if ($currentBook['pdf_file'] && file_exists(BOOK_PDF_PATH . $currentBook['pdf_file'])) {
            unlink(BOOK_PDF_PATH . $currentBook['pdf_file']);
        }
        
        $pdfFilename = $pdfUpload['filename'];
    }
    
    // Update book with ALL fields
    try {
        $stmt = $conn->prepare("
            UPDATE books 
            SET category_id = ?, title = ?, author = ?, publisher = ?, year = ?, 
                pages = ?, price = ?, isbn = ?, short_description = ?, 
                long_description = ?, cover_image = ?, pdf_file = ?, 
                status = 'pending', updated_at = NOW()
            WHERE id = ?
        ");
        
        $result = $stmt->execute([
            $data['category_id'],
            $data['title'],
            $data['author'],
            $data['publisher'] ?? '',
            $data['year'] ?? null,
            $data['pages'] ?? null,
            $data['price'],
            $data['isbn'] ?? '',
            $data['short_description'] ?? '',
            $data['long_description'] ?? '',
            $coverFilename,
            $pdfFilename,
            $bookId
        ]);
        
        if ($result) {
            return [
                'success' => true,
                'message' => 'Buku berhasil diupdate',
                'book_id' => $bookId
            ];
        } else {
            return [
                'success' => false,
                'error' => 'Failed to update book'
            ];
        }
    } catch (Exception $e) {
        return [
            'success' => false,
            'error' => $e->getMessage()
        ];
    }
}

/**
 * Delete book
 */
function deleteBook($bookId) {
    $conn = getDBConnection();
    
    // Get book data
    $stmt = $conn->prepare("SELECT * FROM books WHERE id = ?");
    $stmt->execute([$bookId]);
    $book = $stmt->fetch();
    
    if (!$book) {
        return [
            'success' => false,
            'error' => 'Book not found'
        ];
    }
    
    // Check if book has sales
    $stmt = $conn->prepare("SELECT COUNT(*) FROM sales WHERE book_id = ?");
    $stmt->execute([$bookId]);
    $salesCount = $stmt->fetchColumn();
    
    if ($salesCount > 0) {
        return [
            'success' => false,
            'error' => 'Cannot delete book with sales history'
        ];
    }
    
    try {
        // Delete files
        if ($book['cover_image'] && file_exists(BOOK_COVER_PATH . $book['cover_image'])) {
            unlink(BOOK_COVER_PATH . $book['cover_image']);
        }
        
        if ($book['pdf_file'] && file_exists(BOOK_PDF_PATH . $book['pdf_file'])) {
            unlink(BOOK_PDF_PATH . $book['pdf_file']);
        }
        
        // Delete from cart
        $stmt = $conn->prepare("DELETE FROM cart WHERE book_id = ?");
        $stmt->execute([$bookId]);
        
        // Delete reviews
        $stmt = $conn->prepare("DELETE FROM reviews WHERE book_id = ?");
        $stmt->execute([$bookId]);
        
        // Delete book
        $stmt = $conn->prepare("DELETE FROM books WHERE id = ?");
        $stmt->execute([$bookId]);
        
        return [
            'success' => true,
            'message' => 'Book deleted successfully'
        ];
    } catch (Exception $e) {
        return [
            'success' => false,
            'error' => $e->getMessage()
        ];
    }
}

/**
 * Get book by ID
 */
// function getBook($bookId) {
//     $conn = getDBConnection();
    
//     $stmt = $conn->prepare("
//         SELECT b.*, c.name as category_name, u.full_name as writer_name
//         FROM books b
//         LEFT JOIN categories c ON b.category_id = c.id
//         LEFT JOIN users u ON b.writer_id = u.id
//         WHERE b.id = ?
//     ");
//     $stmt->execute([$bookId]);
    
//     return $stmt->fetch();
// }

/**
 * Get all books with filters
 */
// function getBooks($filters = []) {
//     $conn = getDBConnection();
    
//     $sql = "
//         SELECT b.*, c.name as category_name, u.full_name as writer_name
//         FROM books b
//         LEFT JOIN categories c ON b.category_id = c.id
//         LEFT JOIN users u ON b.writer_id = u.id
//         WHERE 1=1
//     ";
//     $params = [];
    
//     if (isset($filters['writer_id'])) {
//         $sql .= " AND b.writer_id = ?";
//         $params[] = $filters['writer_id'];
//     }
    
//     if (isset($filters['category_id'])) {
//         $sql .= " AND b.category_id = ?";
//         $params[] = $filters['category_id'];
//     }
    
//     if (isset($filters['status'])) {
//         $sql .= " AND b.status = ?";
//         $params[] = $filters['status'];
//     }
    
//     if (isset($filters['search'])) {
//         $sql .= " AND (b.title LIKE ? OR b.author LIKE ?)";
//         $searchTerm = '%' . $filters['search'] . '%';
//         $params[] = $searchTerm;
//         $params[] = $searchTerm;
//     }
    
//     $sql .= " ORDER BY b.created_at DESC";
    
//     if (isset($filters['limit'])) {
//         $sql .= " LIMIT ?";
//         $params[] = (int)$filters['limit'];
//     }
    
//     $stmt = $conn->prepare($sql);
//     $stmt->execute($params);
    
//     return $stmt->fetchAll();
// }

/**
 * Approve book
 */
function approveBook($bookId) {
    $conn = getDBConnection();
    
    try {
        $stmt = $conn->prepare("UPDATE books SET status = 'approved', updated_at = NOW() WHERE id = ?");
        $stmt->execute([$bookId]);
        
        return [
            'success' => true,
            'message' => 'Book approved successfully'
        ];
    } catch (Exception $e) {
        return [
            'success' => false,
            'error' => $e->getMessage()
        ];
    }
}

/**
 * Reject book
 */
function rejectBook($bookId, $reason) {
    $conn = getDBConnection();
    
    try {
        $stmt = $conn->prepare("
            UPDATE books 
            SET status = 'rejected', rejection_reason = ?, updated_at = NOW() 
            WHERE id = ?
        ");
        $stmt->execute([$reason, $bookId]);
        
        return [
            'success' => true,
            'message' => 'Book rejected'
        ];
    } catch (Exception $e) {
        return [
            'success' => false,
            'error' => $e->getMessage()
        ];
    }
}
/**
 * Review book (approve or reject)
 */
function reviewBook($bookId, $status, $reason = null) {
    $conn = getDBConnection();
    
    try {
        if ($status === 'approved') {
            $stmt = $conn->prepare("
                UPDATE books 
                SET status = 'approved', rejection_reason = NULL, updated_at = NOW() 
                WHERE id = ?
            ");
            $stmt->execute([$bookId]);
            
            return [
                'success' => true,
                'message' => 'Buku berhasil disetujui'
            ];
        } elseif ($status === 'rejected') {
            if (empty($reason)) {
                return [
                    'success' => false,
                    'message' => 'Alasan penolakan harus diisi'
                ];
            }
            
            $stmt = $conn->prepare("
                UPDATE books 
                SET status = 'rejected', rejection_reason = ?, updated_at = NOW() 
                WHERE id = ?
            ");
            $stmt->execute([$reason, $bookId]);
            
            return [
                'success' => true,
                'message' => 'Buku ditolak'
            ];
        } else {
            return [
                'success' => false,
                'message' => 'Status tidak valid'
            ];
        }
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => $e->getMessage()
        ];
    }
}
/**
 * Increment book views
 */
function incrementBookViews($bookId) {
    $conn = getDBConnection();
    
    try {
        $stmt = $conn->prepare("UPDATE books SET views = views + 1 WHERE id = ?");
        $stmt->execute([$bookId]);
        return true;
    } catch (Exception $e) {
        return false;
    }
}

/**
 * Get book statistics
 */
function getBookStats() {
    $conn = getDBConnection();
    
    // Get total books
    $stmt = $conn->query("SELECT COUNT(*) FROM books");
    $total = $stmt->fetchColumn();
    
    // Get pending books
    $stmt = $conn->query("SELECT COUNT(*) FROM books WHERE status = 'pending'");
    $pending = $stmt->fetchColumn();
    
    // Get approved books
    $stmt = $conn->query("SELECT COUNT(*) FROM books WHERE status = 'approved'");
    $approved = $stmt->fetchColumn();
    
    // Get rejected books
    $stmt = $conn->query("SELECT COUNT(*) FROM books WHERE status = 'rejected'");
    $rejected = $stmt->fetchColumn();
    
    return [
        'total' => $total,
        'pending' => $pending,
        'approved' => $approved,
        'rejected' => $rejected
    ];
}