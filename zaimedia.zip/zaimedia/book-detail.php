<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

$bookId = $_GET['id'] ?? 0;
$book = getBook($bookId);

if (!$book || $book['status'] !== 'approved') {
    setFlash('error', 'Buku tidak ditemukan');
    redirect('index.php');
}

$conn = getDBConnection();

// Update views
$stmt = $conn->prepare("UPDATE books SET views = views + 1 WHERE id = ?");
$stmt->execute([$bookId]);

// Get reviews with pagination
$page = $_GET['review_page'] ?? 1;
$perPage = 5;
$offset = ($page - 1) * $perPage;

$stmt = $conn->prepare("
    SELECT r.*, u.full_name, u.username 
    FROM reviews r
    JOIN users u ON r.customer_id = u.id
    WHERE r.book_id = ?
    ORDER BY r.created_at DESC
    LIMIT ? OFFSET ?
");
$stmt->execute([$bookId, $perPage, $offset]);
$reviews = $stmt->fetchAll();

// Count total reviews
$stmt = $conn->prepare("SELECT COUNT(*) FROM reviews WHERE book_id = ?");
$stmt->execute([$bookId]);
$totalReviews = $stmt->fetchColumn();
$totalPages = ceil($totalReviews / $perPage);

// Calculate average rating
$stmt = $conn->prepare("SELECT AVG(rating) as avg_rating FROM reviews WHERE book_id = ?");
$stmt->execute([$bookId]);
$avgRating = $stmt->fetchColumn() ?: 0;
$avgRating = round($avgRating, 1);

// Get rating distribution
$ratingDistribution = [];
for ($i = 5; $i >= 1; $i--) {
    $stmt = $conn->prepare("SELECT COUNT(*) FROM reviews WHERE book_id = ? AND rating = ?");
    $stmt->execute([$bookId, $i]);
    $ratingDistribution[$i] = $stmt->fetchColumn();
}

// Check if current user has purchased and reviewed this book
$hasPurchased = false;
$hasReviewed = false;
if (isLoggedIn()) {
    $currentUser = getCurrentUser();
    
    // Check if purchased
    $stmt = $conn->prepare("
        SELECT oi.id 
        FROM order_items oi
        JOIN orders o ON oi.order_id = o.id
        WHERE oi.book_id = ? 
        AND o.customer_id = ? 
        AND o.payment_status = 'paid'
        LIMIT 1
    ");
    $stmt->execute([$bookId, $currentUser['id']]);
    $hasPurchased = $stmt->fetch() ? true : false;
    
    // Check if reviewed
    $stmt = $conn->prepare("SELECT id FROM reviews WHERE book_id = ? AND customer_id = ?");
    $stmt->execute([$bookId, $currentUser['id']]);
    $hasReviewed = $stmt->fetch() ? true : false;
}

// Get related books
$relatedBooks = getBooks([
    'status' => 'approved',
    'category_id' => $book['category_id'],
    'limit' => 4
]);
$relatedBooks = array_filter($relatedBooks, function($b) use ($bookId) {
    return $b['id'] != $bookId;
});

// Get cart count
$cartCount = 0;
if (isLoggedIn()) {
    $currentUser = getCurrentUser();
    $stmtCart = $conn->prepare("SELECT COUNT(*) FROM cart WHERE customer_id = ?");
    $stmtCart->execute([$currentUser['id']]);
    $cartCount = $stmtCart->fetchColumn();
}

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($book['title']) ?> - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .navbar {
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            background-color: white;
        }
        .book-cover-large {
            width: 100%;
            max-width: 350px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        .rating-stars {
            color: #ffc107;
            font-size: 1.5rem;
        }
        .price-box {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.2);
        }
        .book-info-item {
            padding: 15px 0;
            border-bottom: 1px solid #eee;
        }
        
        /* Review Styles */
        .review-card {
            background: white;
            border-radius: 8px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }
        .review-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
        }
        .rating {
            color: #ffc107;
            font-size: 20px;
        }
        .rating-summary {
            background: white;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }
        .rating-bar {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }
        .rating-bar .progress {
            flex: 1;
            margin: 0 15px;
            height: 8px;
        }
        .star-rating {
            cursor: pointer;
            font-size: 30px;
        }
        .star-rating i {
            color: #dee2e6;
            transition: color 0.2s;
        }
        .star-rating i.filled {
            color: #ffc107;
        }
        .write-review-section {
            background: white;
            border-radius: 8px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .review-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 18px;
        }
        .verified-badge {
            background: #28a745;
            color: white;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 11px;
            margin-left: 10px;
        }
        .book-card {
            transition: transform 0.3s;
            cursor: pointer;
        }
        .book-card:hover {
            transform: translateY(-5px);
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold fs-4" href="index.php">
                <i class="bi bi-book-fill text-primary me-2"></i>ZaiMedia
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="books.php">Books</a>
                    </li>
                </ul>
                <div class="d-flex align-items-center gap-3">
                    <?php if (isLoggedIn()): ?>
                        <?php $currentUser = getCurrentUser(); ?>
                        <a href="cart.php" class="btn btn-outline-success position-relative">
                            <i class="bi bi-cart3"></i>
                            <?php if ($cartCount > 0): ?>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                <?= $cartCount ?>
                            </span>
                            <?php endif; ?>
                        </a>
                        <div class="dropdown">
                            <a class="btn btn-outline-primary dropdown-toggle" href="#" data-bs-toggle="dropdown">
                                <i class="bi bi-person-circle me-2"></i>
                                <?= htmlspecialchars($currentUser['username']) ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <?php if ($currentUser['role'] === 'admin'): ?>
                                    <li><a class="dropdown-item" href="admin/dashboard.php">Admin Dashboard</a></li>
                                <?php elseif ($currentUser['role'] === 'writer'): ?>
                                    <li><a class="dropdown-item" href="writer/dashboard.php">Writer Dashboard</a></li>
                                <?php else: ?>
                                    <li><a class="dropdown-item" href="customer/dashboard.php">My Account</a></li>
                                    <li><a class="dropdown-item" href="customer/library.php">My Library</a></li>
                                <?php endif; ?>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-outline-primary">Login</a>
                        <a href="register.php" class="btn btn-primary">Register</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <?php if ($flash): ?>
    <div class="container mt-3">
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
            <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    </div>
    <?php endif; ?>

    <!-- Book Detail -->
    <div class="container my-5">
        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item"><a href="books.php">Books</a></li>
                <li class="breadcrumb-item active"><?= htmlspecialchars($book['title']) ?></li>
            </ol>
        </nav>

        <div class="row">
            <!-- Book Cover -->
            <div class="col-md-4">
                <?php if ($book['cover_image']): ?>
                    <img src="<?= BOOK_COVER_URL . $book['cover_image'] ?>" 
                         alt="<?= htmlspecialchars($book['title']) ?>"
                         class="book-cover-large">
                <?php else: ?>
                    <div class="book-cover-large bg-gradient d-flex align-items-center justify-content-center text-white">
                        <h4><?= htmlspecialchars($book['title']) ?></h4>
                    </div>
                <?php endif; ?>

                <!-- Writer Info -->
                <div class="mt-4 p-3 bg-light rounded">
                    <h6 class="mb-3">Writer Information</h6>
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="bi bi-person-circle fs-1 text-primary"></i>
                        </div>
                        <div>
                            <strong><?= htmlspecialchars($book['writer_name']) ?></strong><br>
                            <small class="text-muted">@<?= htmlspecialchars($book['writer_username']) ?></small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Book Details -->
            <div class="col-md-5">
                <h1 class="mb-3"><?= htmlspecialchars($book['title']) ?></h1>
                
                <!-- Rating -->
                <?php if ($totalReviews > 0): ?>
                <div class="mb-3">
                    <span class="rating-stars">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <?php if ($i <= $avgRating): ?>
                                <i class="bi bi-star-fill"></i>
                            <?php elseif ($i - 0.5 <= $avgRating): ?>
                                <i class="bi bi-star-half"></i>
                            <?php else: ?>
                                <i class="bi bi-star"></i>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </span>
                    <span class="ms-2"><?= $avgRating ?>/5 (<?= $totalReviews ?> reviews)</span>
                </div>
                <?php endif; ?>

                <span class="badge bg-secondary mb-3"><?= htmlspecialchars($book['category_name']) ?></span>

                <!-- Short Description -->
                <p class="lead"><?= nl2br(htmlspecialchars($book['short_description'])) ?></p>

                <!-- Book Info -->
                <div class="book-info-item">
                    <strong>Author:</strong> <?= htmlspecialchars($book['author']) ?>
                </div>
                <div class="book-info-item">
                    <strong>Publisher:</strong> <?= htmlspecialchars($book['publisher']) ?>
                </div>
                <div class="book-info-item">
                    <strong>Year:</strong> <?= $book['year'] ?>
                </div>
                <div class="book-info-item">
                    <strong>Pages:</strong> <?= $book['pages'] ?> halaman
                </div>
                <?php if ($book['isbn']): ?>
                <div class="book-info-item">
                    <strong>ISBN:</strong> <?= htmlspecialchars($book['isbn']) ?>
                </div>
                <?php endif; ?>
                <div class="book-info-item border-0">
                    <strong>Views:</strong> <?= number_format($book['views']) ?>x
                </div>

                <!-- Long Description -->
                <div class="mt-4">
                    <h5>Description</h5>
                    <p><?= nl2br(htmlspecialchars($book['long_description'])) ?></p>
                </div>
            </div>

            <!-- Price & Purchase -->
            <div class="col-md-3">
                <div class="price-box mb-3">
                    <h6 class="mb-2 opacity-75">Price</h6>
                    <h2 class="mb-4"><?= formatRupiah($book['price']) ?></h2>
                    
                    <?php if (isLoggedIn()): ?>
                        <button class="btn btn-light w-100 mb-2" onclick="addToCart(<?= $book['id'] ?>)">
                            <i class="bi bi-cart-plus me-2"></i> Add to Cart
                        </button>
                        <button class="btn btn-outline-light w-100" onclick="buyNow(<?= $book['id'] ?>)">
                            <i class="bi bi-lightning me-2"></i> Buy Now
                        </button>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-light w-100 mb-2">
                            <i class="bi bi-cart-plus me-2"></i> Add to Cart
                        </a>
                        <p class="text-center mt-3 mb-0 small opacity-75">
                            Login untuk membeli buku
                        </p>
                    <?php endif; ?>
                </div>

                <!-- Features -->
                <div class="p-3 bg-light rounded">
                    <h6 class="mb-3">Features</h6>
                    <ul class="list-unstyled">
                        <li class="mb-2">
                            <i class="bi bi-check-circle text-success me-2"></i>
                            Digital PDF Format
                        </li>
                        <li class="mb-2">
                            <i class="bi bi-check-circle text-success me-2"></i>
                            Lifetime Access
                        </li>
                        <li class="mb-2">
                            <i class="bi bi-check-circle text-success me-2"></i>
                            Read on Any Device
                        </li>
                        <li class="mb-2">
                            <i class="bi bi-check-circle text-success me-2"></i>
                            Money Back Guarantee
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Reviews Section -->
        <div class="row mt-5" id="reviews-section">
            <div class="col-12">
                <h2 class="mb-4">Ulasan Buku: <?= htmlspecialchars($book['title']) ?></h2>

                <?php if ($totalReviews > 0): ?>
                <!-- Rating Summary -->
                <div class="rating-summary">
                    <div class="row align-items-center">
                        <div class="col-md-4 text-center border-end">
                            <h1 class="display-3 mb-0"><?= $avgRating ?></h1>
                            <div class="rating mb-2">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <?php if ($i <= $avgRating): ?>
                                        <i class="bi bi-star-fill"></i>
                                    <?php elseif ($i - 0.5 <= $avgRating): ?>
                                        <i class="bi bi-star-half"></i>
                                    <?php else: ?>
                                        <i class="bi bi-star"></i>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </div>
                            <p class="text-muted mb-0">dari <?= $totalReviews ?> ulasan</p>
                        </div>
                        <div class="col-md-8 ps-4">
                            <?php foreach ($ratingDistribution as $star => $count): ?>
                            <div class="rating-bar">
                                <span><?= $star ?>★</span>
                                <div class="progress">
                                    <?php 
                                    $percentage = $totalReviews > 0 ? ($count / $totalReviews) * 100 : 0;
                                    ?>
                                    <div class="progress-bar bg-warning" style="width: <?= $percentage ?>%"></div>
                                </div>
                                <span class="text-muted"><?= $count ?></span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Write Review Section -->
                <div id="write-review">
                    <?php if (isLoggedIn() && $currentUser['role'] === 'customer'): ?>
                        <?php if ($hasPurchased): ?>
                            <?php if (!$hasReviewed): ?>
                            <div class="write-review-section">
                                <h4 class="mb-4">
                                    Tulis Ulasan Anda
                                    <span class="verified-badge">
                                        <i class="bi bi-check-circle-fill"></i> Verified Purchase
                                    </span>
                                </h4>
                                <form id="reviewForm" action="submit-review.php" method="POST">
                                    <input type="hidden" name="book_id" value="<?= $bookId ?>">
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Rating Anda</label>
                                        <div class="star-rating" id="starRating">
                                            <i class="bi bi-star" data-rating="1"></i>
                                            <i class="bi bi-star" data-rating="2"></i>
                                            <i class="bi bi-star" data-rating="3"></i>
                                            <i class="bi bi-star" data-rating="4"></i>
                                            <i class="bi bi-star" data-rating="5"></i>
                                        </div>
                                        <input type="hidden" name="rating" id="ratingValue" value="0">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Judul Ulasan</label>
                                        <input type="text" class="form-control" name="title" 
                                               placeholder="Ringkasan pendapat Anda">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Ulasan Anda</label>
                                        <textarea class="form-control" name="content" rows="5" 
                                                  placeholder="Ceritakan pengalaman Anda dengan buku ini..." 
                                                  required></textarea>
                                    </div>

                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-send me-2"></i>Kirim Ulasan
                                    </button>
                                </form>
                            </div>
                            <?php else: ?>
                            <div class="alert alert-success">
                                <i class="bi bi-check-circle me-2"></i>
                                Anda sudah memberikan review untuk buku ini!
                            </div>
                            <?php endif; ?>
                        <?php else: ?>
                        <div class="alert alert-warning">
                            <i class="bi bi-exclamation-triangle me-2"></i>
                            Beli buku ini dulu untuk memberikan review
                        </div>
                        <?php endif; ?>
                    <?php elseif (!isLoggedIn()): ?>
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle me-2"></i>
                            <a href="login.php">Login</a> untuk memberikan review
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Reviews List -->
                <?php if (!empty($reviews)): ?>
                <div id="reviewsList">
                    <?php foreach ($reviews as $review): ?>
                    <div class="review-card" data-rating="<?= $review['rating'] ?>">
                        <div class="d-flex mb-3">
                            <div class="review-avatar">
                                <?= strtoupper(substr($review['full_name'], 0, 2)) ?>
                            </div>
                            <div class="ms-3 flex-grow-1">
                                <div class="d-flex align-items-center">
                                    <h5 class="mb-0"><?= htmlspecialchars($review['full_name']) ?></h5>
                                    <?php if ($review['is_verified']): ?>
                                        <span class="verified-badge">
                                            <i class="bi bi-check-circle-fill"></i> Verified
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <small class="text-muted"><?= timeAgo($review['created_at']) ?></small>
                            </div>
                            <div class="rating">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <?php if ($i <= $review['rating']): ?>
                                        <i class="bi bi-star-fill"></i>
                                    <?php else: ?>
                                        <i class="bi bi-star"></i>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </div>
                        </div>
                        <?php if ($review['title']): ?>
                            <h6 class="mb-2"><?= htmlspecialchars($review['title']) ?></h6>
                        <?php endif; ?>
                        <p class="mb-3"><?= nl2br(htmlspecialchars($review['content'])) ?></p>
                    </div>
                    <?php endforeach; ?>

                    <!-- Load More / Pagination -->
                    <?php if ($totalPages > 1): ?>
                    <div class="text-center mt-4">
                        <?php if ($page < $totalPages): ?>
                        <a href="?id=<?= $bookId ?>&review_page=<?= $page + 1 ?>#reviews-section" 
                           class="btn btn-outline-primary">
                            <i class="bi bi-arrow-down-circle me-2"></i>Muat Lebih Banyak
                        </a>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
                <?php elseif ($totalReviews == 0): ?>
                    <div class="text-center py-5 bg-white rounded">
                        <i class="bi bi-chat-left-text display-1 text-muted"></i>
                        <h4 class="mt-3">Belum Ada Review</h4>
                        <p class="text-muted">Jadilah yang pertama memberikan review untuk buku ini!</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Related Books -->
        <?php if (!empty($relatedBooks)): ?>
        <div class="row mt-5">
            <div class="col-12">
                <h4 class="mb-4">Related Books</h4>
                <div class="row g-4">
                    <?php foreach (array_slice($relatedBooks, 0, 4) as $relBook): ?>
                    <div class="col-md-3">
                        <div class="card book-card" onclick="window.location.href='book-detail.php?id=<?= $relBook['id'] ?>'">
                            <div style="height: 250px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                                <?php if ($relBook['cover_image']): ?>
                                    <img src="<?= BOOK_COVER_URL . $relBook['cover_image'] ?>" 
                                         style="width: 100%; height: 100%; object-fit: cover;">
                                <?php else: ?>
                                    <div class="d-flex align-items-center justify-content-center h-100 text-white p-3">
                                        <span><?= htmlspecialchars($relBook['title']) ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="card-body">
                                <h6 class="card-title"><?= htmlspecialchars(truncateText($relBook['title'], 50)) ?></h6>
                                <p class="text-muted small mb-2"><?= htmlspecialchars($relBook['author']) ?></p>
                                <h5 class="text-primary mb-0"><?= formatRupiah($relBook['price']) ?></h5>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container text-center">
            <p class="mb-0">&copy; 2024 ZaiMedia Bookstore. All rights reserved.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function addToCart(bookId) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'cart.php';
            form.innerHTML = `
                <input type="hidden" name="action" value="add">
                <input type="hidden" name="book_id" value="${bookId}">
                <input type="hidden" name="quantity" value="1">
            `;
            document.body.appendChild(form);
            form.submit();
        }

        function buyNow(bookId) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'cart.php';
            form.innerHTML = `
                <input type="hidden" name="action" value="add">
                <input type="hidden" name="book_id" value="${bookId}">
                <input type="hidden" name="quantity" value="1">
                <input type="hidden" name="buy_now" value="1">
            `;
            document.body.appendChild(form);
            form.submit();
        }

        // Star Rating
        const stars = document.querySelectorAll('.star-rating i');
        const ratingValue = document.getElementById('ratingValue');

        stars.forEach(star => {
            star.addEventListener('click', function () {
                const rating = this.getAttribute('data-rating');
                ratingValue.value = rating;

                stars.forEach(s => {
                    const starRating = s.getAttribute('data-rating');
                    if (starRating <= rating) {
                        s.classList.remove('bi-star');
                        s.classList.add('bi-star-fill', 'filled');
                    } else {
                        s.classList.remove('bi-star-fill', 'filled');
                        s.classList.add('bi-star');
                    }
                });
            });

            star.addEventListener('mouseenter', function () {
                const rating = this.getAttribute('data-rating');
                stars.forEach(s => {
                    const starRating = s.getAttribute('data-rating');
                    if (starRating <= rating) {
                        s.classList.add('filled');
                    }
                });
            });
        });

        document.getElementById('starRating')?.addEventListener('mouseleave', function () {
            const currentRating = ratingValue.value;
            stars.forEach(s => {
                const starRating = s.getAttribute('data-rating');
                if (starRating > currentRating) {
                    s.classList.remove('filled');
                }
            });
        });

        // Submit Review
        document.getElementById('reviewForm')?.addEventListener('submit', function (e) {
            const rating = ratingValue.value;
            if (rating == 0) {
                e.preventDefault();
                alert('Silakan berikan rating terlebih dahulu');
                return;
            }
        });

        // Auto scroll to write-review if hash present
        if (window.location.hash === '#write-review') {
            setTimeout(() => {
                document.getElementById('write-review').scrollIntoView({ behavior: 'smooth' });
            }, 500);
        }
    </script>
</body>
</html>