<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireLogin();

$conn = getDBConnection();
$customerId = $_SESSION['user_id'];
$user = getCurrentUser();

// Get statistics
$stmt = $conn->prepare("SELECT COUNT(*) FROM orders WHERE customer_id = ?");
$stmt->execute([$customerId]);
$totalOrders = $stmt->fetchColumn();

$stmt = $conn->prepare("SELECT COUNT(*) FROM orders WHERE customer_id = ? AND payment_status = 'paid'");
$stmt->execute([$customerId]);
$paidOrders = $stmt->fetchColumn();

$stmt = $conn->prepare("SELECT SUM(total) FROM orders WHERE customer_id = ? AND payment_status = 'paid'");
$stmt->execute([$customerId]);
$totalSpent = $stmt->fetchColumn() ?? 0;

// Get purchased books count
$stmt = $conn->prepare("
    SELECT COUNT(DISTINCT b.id) 
    FROM books b
    JOIN order_items oi ON b.id = oi.book_id
    JOIN orders o ON oi.order_id = o.id
    WHERE o.customer_id = ? AND o.payment_status = 'paid'
");
$stmt->execute([$customerId]);
$totalBooks = $stmt->fetchColumn();

// Get recent orders
$stmt = $conn->prepare("
    SELECT o.*, COUNT(oi.id) as item_count
    FROM orders o
    LEFT JOIN order_items oi ON o.id = oi.order_id
    WHERE o.customer_id = ?
    GROUP BY o.id
    ORDER BY o.created_at DESC
    LIMIT 5
");
$stmt->execute([$customerId]);
$recentOrders = $stmt->fetchAll();

// Get recent purchases
$stmt = $conn->prepare("
    SELECT DISTINCT b.*, o.created_at as purchase_date
    FROM books b
    JOIN order_items oi ON b.id = oi.book_id
    JOIN orders o ON oi.order_id = o.id
    WHERE o.customer_id = ? AND o.payment_status = 'paid'
    ORDER BY o.created_at DESC
    LIMIT 6
");
$stmt->execute([$customerId]);
$recentBooks = $stmt->fetchAll();

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Dashboard - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: white;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            position: fixed;
            width: 250px;
        }
        .sidebar-header {
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .menu-item {
            padding: 12px 20px;
            color: #333;
            text-decoration: none;
            display: block;
            transition: all 0.3s;
        }
        .menu-item:hover,
        .menu-item.active {
            background: #f8f9fa;
            color: #667eea;
            border-left: 3px solid #667eea;
        }
        .content-area {
            margin-left: 250px;
            padding: 30px;
        }
        .stats-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            transition: transform 0.3s;
        }
        .stats-card:hover {
            transform: translateY(-5px);
        }
        .stats-icon {
            width: 60px;
            height: 60px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
        }
        .info-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .welcome-banner {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
        }
        .book-mini-card {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 10px;
            margin-bottom: 10px;
            transition: background 0.3s;
        }
        .book-mini-card:hover {
            background: #e9ecef;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0">Customer</h4>
            <small><?= htmlspecialchars($user['full_name']) ?></small>
        </div>
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item active">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a href="orders.php" class="menu-item">
                <i class="bi bi-cart me-2"></i> My Orders
            </a>
            <a href="library.php" class="menu-item">
                <i class="bi bi-book me-2"></i> My Library
            </a>
            <a href="profile.php" class="menu-item">
                <i class="bi bi-person me-2"></i> Profile
            </a>
        </div>
        <div style="position: absolute; bottom: 20px; width: 100%;">
            <a href="../index.php" class="menu-item">
                <i class="bi bi-house me-2"></i> Homepage
            </a>
            <a href="../logout.php" class="menu-item">
                <i class="bi bi-box-arrow-left me-2"></i> LogOut
            </a>
        </div>
    </div>

    <!-- Content -->
    <div class="content-area">
        <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
            <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Welcome Banner -->
        <div class="welcome-banner">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h2 class="mb-2">Welcome back, <?= htmlspecialchars($user['full_name']) ?>! 👋</h2>
                    <p class="mb-0 opacity-75">Here's your reading activity today.</p>
                </div>
                <div class="col-md-4 text-end">
                    <h5><?= date('l, d F Y') ?></h5>
                    <p class="mb-0" id="currentTime"></p>
                </div>
            </div>
        </div>

        <!-- Stats Row -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="d-flex align-items-center">
                        <div class="stats-icon bg-primary bg-opacity-10 text-primary me-3">
                            <i class="bi bi-book"></i>
                        </div>
                        <div>
                            <h6 class="text-muted mb-0">My Books</h6>
                            <h3 class="mb-0"><?= $totalBooks ?></h3>
                            <small class="text-muted">In library</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="d-flex align-items-center">
                        <div class="stats-icon bg-success bg-opacity-10 text-success me-3">
                            <i class="bi bi-cart-check"></i>
                        </div>
                        <div>
                            <h6 class="text-muted mb-0">Total Orders</h6>
                            <h3 class="mb-0"><?= $totalOrders ?></h3>
                            <small class="text-muted"><?= $paidOrders ?> paid</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="d-flex align-items-center">
                        <div class="stats-icon bg-warning bg-opacity-10 text-warning me-3">
                            <i class="bi bi-cash-stack"></i>
                        </div>
                        <div>
                            <h6 class="text-muted mb-0">Total Spent</h6>
                            <h3 class="mb-0 text-success"><?= formatRupiah($totalSpent) ?></h3>
                            <small class="text-muted">All time</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="d-flex align-items-center">
                        <div class="stats-icon bg-info bg-opacity-10 text-info me-3">
                            <i class="bi bi-star"></i>
                        </div>
                        <div>
                            <h6 class="text-muted mb-0">Reviews</h6>
                            <h3 class="mb-0">0</h3>
                            <small class="text-muted">Given</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="info-card mb-4">
            <h5 class="mb-4">
                <i class="bi bi-lightning me-2"></i>Quick Actions
            </h5>
            <div class="row g-3">
                <div class="col-md-3">
                    <a href="../books.php" class="btn btn-outline-primary w-100">
                        <i class="bi bi-shop fs-3 d-block mb-2"></i>
                        <strong>Browse Books</strong>
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="library.php" class="btn btn-outline-success w-100">
                        <i class="bi bi-book fs-3 d-block mb-2"></i>
                        <strong>My Library</strong>
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="orders.php" class="btn btn-outline-info w-100">
                        <i class="bi bi-cart fs-3 d-block mb-2"></i>
                        <strong>My Orders</strong>
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="../cart.php" class="btn btn-outline-warning w-100">
                        <i class="bi bi-cart3 fs-3 d-block mb-2"></i>
                        <strong>Shopping Cart</strong>
                    </a>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-8">
                <!-- Recent Orders -->
                <div class="info-card">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="mb-0">
                            <i class="bi bi-cart me-2"></i>Recent Orders
                        </h5>
                        <a href="orders.php" class="btn btn-sm btn-outline-primary">View All</a>
                    </div>

                    <?php if (empty($recentOrders)): ?>
                        <div class="alert alert-info">
                            No orders yet. Start shopping now!
                        </div>
                    <?php else: ?>
                        <?php foreach ($recentOrders as $order): ?>
                        <div class="border-bottom pb-3 mb-3">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <strong><?= htmlspecialchars($order['order_number']) ?></strong>
                                    <br>
                                    <small class="text-muted">
                                        <?= $order['item_count'] ?> items • <?= timeAgo($order['created_at']) ?>
                                    </small>
                                </div>
                                <div class="text-end">
                                    <?php
                                    $statusClass = ['pending' => 'secondary', 'processing' => 'info', 'shipped' => 'primary', 'delivered' => 'success', 'cancelled' => 'danger'];
                                    $paymentClass = ['pending' => 'warning', 'paid' => 'success', 'failed' => 'danger'];
                                    ?>
                                    <span class="badge bg-<?= $paymentClass[$order['payment_status']] ?> mb-2">
                                        <?= ucfirst($order['payment_status']) ?>
                                    </span>
                                    <br>
                                    <strong class="text-primary"><?= formatRupiah($order['total']) ?></strong>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <div class="col-md-4">
                <!-- Recent Purchases -->
                <div class="info-card">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="mb-0">
                            <i class="bi bi-book me-2"></i>Recent Purchases
                        </h5>
                        <a href="library.php" class="btn btn-sm btn-outline-primary">View Library</a>
                    </div>

                    <?php if (empty($recentBooks)): ?>
                        <div class="alert alert-info">
                            No books yet. Start buying now!
                        </div>
                    <?php else: ?>
                        <?php foreach (array_slice($recentBooks, 0, 5) as $book): ?>
                        <div class="book-mini-card">
                            <div class="d-flex align-items-center">
                                <div style="width: 40px; height: 55px; border-radius: 5px; overflow: hidden; margin-right: 10px;">
                                    <?php if ($book['cover_image']): ?>
                                        <img src="<?= BOOK_COVER_URL . $book['cover_image'] ?>" 
                                             style="width: 100%; height: 100%; object-fit: cover;"
                                             alt="<?= htmlspecialchars($book['title']) ?>">
                                    <?php else: ?>
                                        <div class="bg-gradient text-white d-flex align-items-center justify-content-center h-100">
                                            <i class="bi bi-book"></i>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="flex-grow-1">
                                    <h6 class="mb-0 small"><?= htmlspecialchars(truncateText($book['title'], 30)) ?></h6>
                                    <small class="text-muted"><?= timeAgo($book['purchase_date']) ?></small>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <!-- Account Info -->
                <div class="info-card">
                    <h5 class="mb-4">
                        <i class="bi bi-person me-2"></i>Account Info
                    </h5>
                    <p class="mb-2">
                        <strong>Name:</strong><br>
                        <?= htmlspecialchars($user['full_name']) ?>
                    </p>
                    <p class="mb-2">
                        <strong>Email:</strong><br>
                        <?= htmlspecialchars($user['email']) ?>
                    </p>
                    <p class="mb-3">
                        <strong>Member Since:</strong><br>
                        <?= formatDateIndo($user['created_at']) ?>
                    </p>
                    <a href="profile.php" class="btn btn-outline-primary w-100">
                        <i class="bi bi-pencil me-2"></i> Edit Profile
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Update clock
        function updateTime() {
            const now = new Date();
            const timeString = now.toLocaleTimeString('id-ID');
            document.getElementById('currentTime').textContent = timeString;
        }
        setInterval(updateTime, 1000);
        updateTime();
    </script>
</body>
</html>