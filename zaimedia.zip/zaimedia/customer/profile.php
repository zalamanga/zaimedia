<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireLogin();

$conn = getDBConnection();
$customerId = $_SESSION['user_id'];
$user = getCurrentUser();

$error = '';
$success = '';

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    if ($action === 'update_profile') {
        $data = [
            'full_name' => sanitize($_POST['full_name']),
            'phone' => sanitize($_POST['phone']),
            'address' => sanitize($_POST['address']),
            'city' => sanitize($_POST['city']),
            'postal_code' => sanitize($_POST['postal_code'])
        ];
        
        try {
            $stmt = $conn->prepare("
                UPDATE users 
                SET full_name = ?, phone = ?, address = ?, city = ?, postal_code = ?, updated_at = NOW()
                WHERE id = ?
            ");
            $stmt->execute([
                $data['full_name'],
                $data['phone'],
                $data['address'],
                $data['city'],
                $data['postal_code'],
                $customerId
            ]);
            
            $success = 'Profile berhasil diupdate!';
            $user = getCurrentUser(); // Refresh user data
            
        } catch (Exception $e) {
            $error = 'Gagal update profile: ' . $e->getMessage();
        }
        
    } elseif ($action === 'change_password') {
        $currentPassword = $_POST['current_password'];
        $newPassword = $_POST['new_password'];
        $confirmPassword = $_POST['confirm_password'];
        
        // Verify current password
        if (!password_verify($currentPassword, $user['password'])) {
            $error = 'Password lama tidak sesuai';
        } elseif ($newPassword !== $confirmPassword) {
            $error = 'Password baru tidak cocok';
        } elseif (strlen($newPassword) < 6) {
            $error = 'Password minimal 6 karakter';
        } else {
            try {
                $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?");
                $stmt->execute([$hashedPassword, $customerId]);
                
                $success = 'Password berhasil diubah!';
                
            } catch (Exception $e) {
                $error = 'Gagal ubah password: ' . $e->getMessage();
            }
        }
    }
}

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: white;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            position: fixed;
            width: 250px;
        }
        .sidebar-header {
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .menu-item {
            padding: 12px 20px;
            color: #333;
            text-decoration: none;
            display: block;
            transition: all 0.3s;
        }
        .menu-item:hover,
        .menu-item.active {
            background: #f8f9fa;
            color: #667eea;
            border-left: 3px solid #667eea;
        }
        .content-area {
            margin-left: 250px;
            padding: 30px;
        }
        .profile-card {
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .avatar-circle {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 48px;
            font-weight: bold;
            margin: 0 auto 20px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0">Customer</h4>
            <small><?= htmlspecialchars($user['full_name']) ?></small>
        </div>
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a href="orders.php" class="menu-item">
                <i class="bi bi-cart me-2"></i> My Orders
            </a>
            <a href="library.php" class="menu-item">
                <i class="bi bi-book me-2"></i> My Library
            </a>
            <a href="profile.php" class="menu-item active">
                <i class="bi bi-person me-2"></i> Profile
            </a>
        </div>
        <div style="position: absolute; bottom: 20px; width: 100%;">
            <a href="../index.php" class="menu-item">
                <i class="bi bi-house me-2"></i> Homepage
            </a>
            <a href="../logout.php" class="menu-item">
                <i class="bi bi-box-arrow-left me-2"></i> LogOut
            </a>
        </div>
    </div>

    <!-- Content -->
    <div class="content-area">
        <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
            <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?= $error ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?= $success ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <h2 class="mb-4">
            <i class="bi bi-person me-2"></i>My Profile
        </h2>

        <div class="row">
            <div class="col-md-4">
                <!-- Profile Info Card -->
                <div class="profile-card text-center">
                    <div class="avatar-circle">
                        <?= strtoupper(substr($user['full_name'], 0, 2)) ?>
                    </div>
                    
                    <h4 class="mb-2"><?= htmlspecialchars($user['full_name']) ?></h4>
                    <p class="text-muted mb-3">@<?= htmlspecialchars($user['username']) ?></p>
                    
                    <div class="mb-3">
                        <span class="badge bg-<?= getRoleBadgeClass($user['role']) ?> mb-2">
                            <?= ucfirst($user['role']) ?>
                        </span>
                    </div>
                    
                    <hr>
                    
                    <div class="text-start">
                        <p class="mb-2">
                            <i class="bi bi-envelope me-2 text-primary"></i>
                            <?= htmlspecialchars($user['email']) ?>
                        </p>
                        <?php if ($user['phone']): ?>
                        <p class="mb-2">
                            <i class="bi bi-phone me-2 text-success"></i>
                            <?= htmlspecialchars($user['phone']) ?>
                        </p>
                        <?php endif; ?>
                        <p class="mb-0">
                            <i class="bi bi-calendar me-2 text-info"></i>
                            Member since <?= formatDateIndo($user['created_at']) ?>
                        </p>
                    </div>
                </div>

                <!-- Quick Stats -->
                <div class="profile-card">
                    <h5 class="mb-4">Quick Stats</h5>
                    
                    <?php
                    // Get stats
                    $stmt = $conn->prepare("SELECT COUNT(*) FROM orders WHERE customer_id = ? AND payment_status = 'paid'");
                    $stmt->execute([$customerId]);
                    $totalOrders = $stmt->fetchColumn();
                    
                    $stmt = $conn->prepare("
                        SELECT COUNT(DISTINCT b.id) 
                        FROM books b
                        JOIN order_items oi ON b.id = oi.book_id
                        JOIN orders o ON oi.order_id = o.id
                        WHERE o.customer_id = ? AND o.payment_status = 'paid'
                    ");
                    $stmt->execute([$customerId]);
                    $totalBooks = $stmt->fetchColumn();
                    
                    $stmt = $conn->prepare("SELECT SUM(total) FROM orders WHERE customer_id = ? AND payment_status = 'paid'");
                    $stmt->execute([$customerId]);
                    $totalSpent = $stmt->fetchColumn() ?? 0;
                    ?>
                    
                    <div class="d-flex justify-content-between mb-3">
                        <span>Total Orders:</span>
                        <strong><?= $totalOrders ?></strong>
                    </div>
                    <div class="d-flex justify-content-between mb-3">
                        <span>Books Owned:</span>
                        <strong><?= $totalBooks ?></strong>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span>Total Spent:</span>
                        <strong class="text-success"><?= formatRupiah($totalSpent) ?></strong>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <!-- Edit Profile Form -->
                <div class="profile-card">
                    <h5 class="mb-4">
                        <i class="bi bi-pencil me-2"></i>Edit Profile
                    </h5>
                    
                    <form method="POST">
                        <input type="hidden" name="action" value="update_profile">
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Username</label>
                                <input type="text" class="form-control" value="<?= htmlspecialchars($user['username']) ?>" disabled>
                                <small class="text-muted">Username tidak dapat diubah</small>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" disabled>
                                <small class="text-muted">Email tidak dapat diubah</small>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Full Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="full_name" 
                                       value="<?= htmlspecialchars($user['full_name']) ?>" required>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Phone Number</label>
                                <input type="tel" class="form-control" name="phone" 
                                       value="<?= htmlspecialchars($user['phone'] ?? '') ?>"
                                       placeholder="+62812345678">
                            </div>
                            
                            <div class="col-12 mb-3">
                                <label class="form-label">Address</label>
                                <textarea class="form-control" name="address" rows="3" 
                                          placeholder="Jl. Contoh No. 123"><?= htmlspecialchars($user['address'] ?? '') ?></textarea>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">City</label>
                                <input type="text" class="form-control" name="city" 
                                       value="<?= htmlspecialchars($user['city'] ?? '') ?>"
                                       placeholder="Jakarta">
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Postal Code</label>
                                <input type="text" class="form-control" name="postal_code" 
                                       value="<?= htmlspecialchars($user['postal_code'] ?? '') ?>"
                                       placeholder="12345">
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-save me-2"></i> Save Changes
                        </button>
                    </form>
                </div>

                <!-- Change Password Form -->
                <div class="profile-card">
                    <h5 class="mb-4">
                        <i class="bi bi-lock me-2"></i>Change Password
                    </h5>
                    
                    <form method="POST">
                        <input type="hidden" name="action" value="change_password">
                        
                        <div class="mb-3">
                            <label class="form-label">Current Password <span class="text-danger">*</span></label>
                            <input type="password" class="form-control" name="current_password" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">New Password <span class="text-danger">*</span></label>
                            <input type="password" class="form-control" name="new_password" required minlength="6">
                            <small class="text-muted">Minimal 6 karakter</small>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Confirm New Password <span class="text-danger">*</span></label>
                            <input type="password" class="form-control" name="confirm_password" required minlength="6">
                        </div>
                        
                        <button type="submit" class="btn btn-warning">
                            <i class="bi bi-key me-2"></i> Change Password
                        </button>
                    </form>
                </div>

                <!-- Account Settings -->
                <div class="profile-card">
                    <h5 class="mb-4">
                        <i class="bi bi-gear me-2"></i>Account Settings
                    </h5>
                    
                    <div class="d-flex justify-content-between align-items-center mb-3 p-3 bg-light rounded">
                        <div>
                            <h6 class="mb-1">Email Notifications</h6>
                            <small class="text-muted">Receive order updates via email</small>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" checked disabled>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mb-3 p-3 bg-light rounded">
                        <div>
                            <h6 class="mb-1">Marketing Emails</h6>
                            <small class="text-muted">Receive promotional offers</small>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" disabled>
                        </div>
                    </div>

                    <hr>

                    <div class="alert alert-danger">
                        <h6 class="mb-2">
                            <i class="bi bi-exclamation-triangle me-2"></i>Danger Zone
                        </h6>
                        <p class="mb-2">Once you delete your account, there is no going back. Please be certain.</p>
                        <button class="btn btn-danger btn-sm" onclick="alert('Feature coming soon!')">
                            <i class="bi bi-trash me-2"></i> Delete Account
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>