<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireLogin();

$bookId = $_GET['id'] ?? 0;
$customerId = $_SESSION['user_id'];

$conn = getDBConnection();

// Check if customer owns this book
$stmt = $conn->prepare("
    SELECT b.*, o.customer_id
    FROM books b
    JOIN order_items oi ON b.id = oi.book_id
    JOIN orders o ON oi.order_id = o.id
    WHERE b.id = ? AND o.customer_id = ? AND o.payment_status = 'paid'
    LIMIT 1
");
$stmt->execute([$bookId, $customerId]);
$book = $stmt->fetch();

if (!$book) {
    setFlash('error', 'Anda belum membeli buku ini');
    redirect('library.php');
}

if (!$book['pdf_file']) {
    setFlash('error', 'PDF tidak tersedia untuk buku ini');
    redirect('library.php');
}

$pdfUrl = BOOK_PDF_URL . $book['pdf_file'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reading: <?= htmlspecialchars($book['title']) ?> - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            overflow: hidden;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .reader-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }
        .reader-title {
            font-size: 1.2rem;
            font-weight: 600;
            margin: 0;
        }
        .reader-actions {
            display: flex;
            gap: 10px;
        }
        .pdf-container {
            width: 100%;
            height: calc(100vh - 70px);
            border: none;
        }
        .btn-reader {
            background: rgba(255,255,255,0.2);
            border: 1px solid rgba(255,255,255,0.3);
            color: white;
            padding: 8px 16px;
            border-radius: 5px;
            text-decoration: none;
            transition: all 0.3s;
        }
        .btn-reader:hover {
            background: rgba(255,255,255,0.3);
            color: white;
        }
        .loading {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
        }
        .spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #667eea;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="reader-header">
        <div>
            <h1 class="reader-title">
                <i class="bi bi-book-half me-2"></i>
                <?= htmlspecialchars($book['title']) ?>
            </h1>
            <small>by <?= htmlspecialchars($book['author']) ?></small>
        </div>
        <div class="reader-actions">
            <a href="<?= $pdfUrl ?>" 
               download 
               class="btn-reader"
               title="Download PDF">
                <i class="bi bi-download me-1"></i> Download
            </a>
            <a href="../book-detail.php?id=<?= $book['id'] ?>#write-review" 
               class="btn-reader"
               title="Write Review">
                <i class="bi bi-star me-1"></i> Review
            </a>
            <a href="library.php" 
               class="btn-reader"
               title="Back to Library">
                <i class="bi bi-arrow-left me-1"></i> Library
            </a>
        </div>
    </div>

    <div class="loading" id="loading">
        <div class="spinner"></div>
        <p>Loading PDF...</p>
    </div>

    <iframe 
        id="pdfViewer"
        src="<?= $pdfUrl ?>#toolbar=1&navpanes=1&scrollbar=1" 
        class="pdf-container"
        onload="document.getElementById('loading').style.display='none'">
        <p>Your browser does not support PDFs. 
           <a href="<?= $pdfUrl ?>" download>Download the PDF</a> instead.</p>
    </iframe>

    <script>
        // Prevent right-click (optional - for content protection)
        // document.addEventListener('contextmenu', event => event.preventDefault());

        // Track reading time (optional)
        let startTime = Date.now();
        window.addEventListener('beforeunload', function() {
            let readingTime = Math.floor((Date.now() - startTime) / 1000);
            console.log('Reading time:', readingTime, 'seconds');
            // Send to server for analytics if needed
        });

        // Keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            // Ctrl/Cmd + D = Download
            if ((e.ctrlKey || e.metaKey) && e.key === 'd') {
                e.preventDefault();
                window.location.href = '<?= $pdfUrl ?>';
            }
            // Esc = Back to library
            if (e.key === 'Escape') {
                window.location.href = 'library.php';
            }
        });
    </script>
</body>
</html>