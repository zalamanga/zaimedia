<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireLogin();

$conn = getDBConnection();
$customerId = $_SESSION['user_id'];
$user = getCurrentUser();
$orderId = $_GET['id'] ?? 0;

// Get order details
$stmt = $conn->prepare("
    SELECT * FROM orders 
    WHERE id = ? AND customer_id = ?
");
$stmt->execute([$orderId, $customerId]);
$order = $stmt->fetch();

if (!$order) {
    setFlash('error', 'Order tidak ditemukan');
    redirect('orders.php');
}

// Get order items
$stmt = $conn->prepare("
    SELECT oi.*, b.title, b.author, b.cover_image, b.pdf_file
    FROM order_items oi
    JOIN books b ON oi.book_id = b.id
    WHERE oi.order_id = ?
");
$stmt->execute([$orderId]);
$items = $stmt->fetchAll();

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Detail - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: white;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            position: fixed;
            width: 250px;
        }
        .sidebar-header {
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .content-area {
            margin-left: 250px;
            padding: 30px;
        }
        .info-card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .info-row {
            padding: 15px 0;
            border-bottom: 1px solid #eee;
        }
        .info-row:last-child {
            border-bottom: none;
        }
        .item-card {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0">Customer</h4>
            <small><?= htmlspecialchars($user['full_name']) ?></small>
        </div>
        <div class="p-3">
            <a href="dashboard.php" class="btn btn-outline-primary w-100 mb-2">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a href="orders.php" class="btn btn-primary w-100 mb-2">
                <i class="bi bi-cart me-2"></i> My Orders
            </a>
            <a href="library.php" class="btn btn-outline-primary w-100 mb-2">
                <i class="bi bi-book me-2"></i> My Library
            </a>
            <a href="../index.php" class="btn btn-outline-secondary w-100 mb-2">
                <i class="bi bi-house me-2"></i> Homepage
            </a>
            <a href="../logout.php" class="btn btn-outline-danger w-100">
                <i class="bi bi-box-arrow-left me-2"></i> Logout
            </a>
        </div>
    </div>

    <!-- Content -->
    <div class="content-area">
        <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
            <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Order Detail</h2>
            <a href="orders.php" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left me-2"></i> Back
            </a>
        </div>

        <div class="row">
            <div class="col-md-8">
                <!-- Order Info -->
                <div class="info-card">
                    <h5 class="mb-4">Order Information</h5>
                    
                    <div class="info-row">
                        <div class="row">
                            <div class="col-md-4"><strong>Order Number:</strong></div>
                            <div class="col-md-8"><?= htmlspecialchars($order['order_number']) ?></div>
                        </div>
                    </div>

                    <div class="info-row">
                        <div class="row">
                            <div class="col-md-4"><strong>Order Date:</strong></div>
                            <div class="col-md-8"><?= formatDateTimeIndo($order['created_at']) ?></div>
                        </div>
                    </div>

                    <div class="info-row">
                        <div class="row">
                            <div class="col-md-4"><strong>Payment Method:</strong></div>
                            <div class="col-md-8"><?= ucwords(str_replace('_', ' ', $order['payment_method'])) ?></div>
                        </div>
                    </div>

                    <div class="info-row">
                        <div class="row">
                            <div class="col-md-4"><strong>Payment Status:</strong></div>
                            <div class="col-md-8">
                                <?php
                                $paymentClass = [
                                    'pending' => 'warning',
                                    'paid' => 'success',
                                    'failed' => 'danger'
                                ];
                                ?>
                                <span class="badge bg-<?= $paymentClass[$order['payment_status']] ?>">
                                    <?= ucfirst($order['payment_status']) ?>
                                </span>
                            </div>
                        </div>
                    </div>

                    <div class="info-row">
                        <div class="row">
                            <div class="col-md-4"><strong>Order Status:</strong></div>
                            <div class="col-md-8">
                                <?php
                                $statusClass = [
                                    'pending' => 'secondary',
                                    'processing' => 'info',
                                    'shipped' => 'primary',
                                    'delivered' => 'success',
                                    'cancelled' => 'danger'
                                ];
                                ?>
                                <span class="badge bg-<?= $statusClass[$order['order_status']] ?>">
                                    <?= ucfirst($order['order_status']) ?>
                                </span>
                            </div>
                        </div>
                    </div>

                    <?php if ($order['notes']): ?>
                    <div class="info-row">
                        <div class="row">
                            <div class="col-md-4"><strong>Notes:</strong></div>
                            <div class="col-md-8"><?= nl2br(htmlspecialchars($order['notes'])) ?></div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Order Items -->
                <div class="info-card">
                    <h5 class="mb-4">Order Items (<?= count($items) ?>)</h5>
                    
                    <?php foreach ($items as $item): ?>
                    <div class="item-card">
                        <div class="d-flex align-items-center">
                            <div style="width: 60px; height: 80px; border-radius: 5px; overflow: hidden; margin-right: 15px;">
                                <?php if ($item['cover_image']): ?>
                                    <img src="<?= BOOK_COVER_URL . $item['cover_image'] ?>" 
                                         style="width: 100%; height: 100%; object-fit: cover;"
                                         alt="<?= htmlspecialchars($item['title']) ?>">
                                <?php else: ?>
                                    <div class="bg-gradient text-white d-flex align-items-center justify-content-center h-100">
                                        <i class="bi bi-book"></i>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="flex-grow-1">
                                <h6 class="mb-1"><?= htmlspecialchars($item['title']) ?></h6>
                                <small class="text-muted">
                                    <i class="bi bi-person me-1"></i><?= htmlspecialchars($item['author']) ?>
                                </small>
                                <br>
                                <small class="text-muted">
                                    Qty: <?= $item['quantity'] ?> x <?= formatRupiah($item['price']) ?>
                                </small>
                            </div>
                            <div class="text-end">
                                <strong class="d-block mb-2"><?= formatRupiah($item['subtotal']) ?></strong>
                                <?php if ($order['payment_status'] === 'paid' && $item['pdf_file']): ?>
                                    <a href="<?= BOOK_PDF_URL . $item['pdf_file'] ?>" 
                                       class="btn btn-sm btn-success" 
                                       download
                                       target="_blank">
                                        <i class="bi bi-download me-1"></i> Download
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="col-md-4">
                <!-- Price Summary -->
                <div class="info-card">
                    <h5 class="mb-4">Price Summary</h5>
                    
                    <div class="d-flex justify-content-between mb-2">
                        <span>Subtotal:</span>
                        <strong><?= formatRupiah($order['subtotal']) ?></strong>
                    </div>

                    <div class="d-flex justify-content-between mb-2">
                        <span>Shipping:</span>
                        <strong class="text-success">FREE</strong>
                    </div>

                    <div class="d-flex justify-content-between mb-3">
                        <span>Tax (<?= TAX_PERCENTAGE ?>%):</span>
                        <strong><?= formatRupiah($order['tax']) ?></strong>
                    </div>

                    <hr>

                    <div class="d-flex justify-content-between mb-3">
                        <h6>Total:</h6>
                        <h4 class="text-primary"><?= formatRupiah($order['total']) ?></h4>
                    </div>

                    <?php if ($order['payment_status'] === 'paid'): ?>
                        <a href="library.php" class="btn btn-success w-100">
                            <i class="bi bi-download me-2"></i> Go to Library
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Shipping Info -->
                <div class="info-card">
                    <h5 class="mb-4">Shipping Information</h5>
                    
                    <p class="mb-2"><strong><?= htmlspecialchars($order['shipping_name']) ?></strong></p>
                    <p class="mb-2"><?= htmlspecialchars($order['shipping_phone']) ?></p>
                    <p class="mb-2"><?= nl2br(htmlspecialchars($order['shipping_address'])) ?></p>
                    <p class="mb-0">
                        <?= htmlspecialchars($order['shipping_city']) ?>, 
                        <?= htmlspecialchars($order['shipping_postal_code']) ?>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>