<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireLogin();

$conn = getDBConnection();
$customerId = $_SESSION['user_id'];
$user = getCurrentUser();

// Get purchased books (from paid orders) with review status
$stmt = $conn->prepare("
    SELECT DISTINCT 
        b.*,
        oi.order_id, 
        o.order_number, 
        o.created_at as purchase_date,
        (SELECT COUNT(*) FROM reviews r WHERE r.book_id = b.id AND r.customer_id = ?) as has_reviewed
    FROM books b
    JOIN order_items oi ON b.id = oi.book_id
    JOIN orders o ON oi.order_id = o.id
    WHERE o.customer_id = ? AND o.payment_status = 'paid'
    ORDER BY o.created_at DESC
");
$stmt->execute([$customerId, $customerId]);
$books = $stmt->fetchAll();

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Library - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: white;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            position: fixed;
            width: 250px;
        }
        .sidebar-header {
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .menu-item {
            padding: 12px 20px;
            color: #333;
            text-decoration: none;
            display: block;
            transition: all 0.3s;
        }
        .menu-item:hover,
        .menu-item.active {
            background: #f8f9fa;
            color: #667eea;
            border-left: 3px solid #667eea;
        }
        .content-area {
            margin-left: 250px;
            padding: 30px;
        }
        .book-card {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s, box-shadow 0.3s;
            height: 100%;
        }
        .book-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.2);
        }
        .book-cover {
            height: 300px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }
        .book-cover img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .download-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s;
        }
        .book-card:hover .download-overlay {
            opacity: 1;
        }
        .badge-purchased {
            position: absolute;
            top: 10px;
            right: 10px;
            background: rgba(40, 167, 69, 0.9);
            color: white;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        .badge-reviewed {
            position: absolute;
            top: 45px;
            right: 10px;
            background: rgba(255, 193, 7, 0.9);
            color: #333;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0">Customer</h4>
            <small><?= htmlspecialchars($user['full_name']) ?></small>
        </div>
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a href="orders.php" class="menu-item">
                <i class="bi bi-cart me-2"></i> My Orders
            </a>
            <a href="library.php" class="menu-item active">
                <i class="bi bi-book me-2"></i> My Library
            </a>
            <a href="profile.php" class="menu-item">
                <i class="bi bi-person me-2"></i> Profile
            </a>
        </div>
        <div style="position: absolute; bottom: 20px; width: 100%;">
            <a href="../index.php" class="menu-item">
                <i class="bi bi-house me-2"></i> Homepage
            </a>
            <a href="../logout.php" class="menu-item">
                <i class="bi bi-box-arrow-left me-2"></i> LogOut
            </a>
        </div>
    </div>

    <!-- Content -->
    <div class="content-area">
        <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
            <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>
                <i class="bi bi-book me-2"></i>My Library
            </h2>
            <div>
                <span class="badge bg-primary fs-6"><?= count($books) ?> Books</span>
            </div>
        </div>

        <?php if (empty($books)): ?>
            <div class="text-center py-5">
                <div class="bg-white rounded-3 p-5 shadow-sm">
                    <i class="bi bi-book display-1 text-muted"></i>
                    <h4 class="mt-4">Library Anda Kosong</h4>
                    <p class="text-muted mb-4">Belum ada buku yang dibeli. Yuk mulai berbelanja!</p>
                    <a href="../books.php" class="btn btn-primary btn-lg">
                        <i class="bi bi-shop me-2"></i> Browse Books
                    </a>
                </div>
            </div>
        <?php else: ?>
            <div class="alert alert-info mb-4">
                <i class="bi bi-info-circle me-2"></i>
                <strong>Tip:</strong> Kamu bisa download PDF, baca online, atau tulis review untuk setiap buku yang sudah dibeli!
            </div>

            <div class="row g-4">
                <?php foreach ($books as $book): ?>
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="book-card">
                        <div class="book-cover">
                            <?php if ($book['cover_image']): ?>
                                <img src="<?= BOOK_COVER_URL . $book['cover_image'] ?>" 
                                     alt="<?= htmlspecialchars($book['title']) ?>">
                            <?php else: ?>
                                <span class="text-white p-3"><?= htmlspecialchars($book['title']) ?></span>
                            <?php endif; ?>
                            
                            <span class="badge-purchased">
                                <i class="bi bi-check-circle me-1"></i> Owned
                            </span>

                            <?php if ($book['has_reviewed'] > 0): ?>
                            <span class="badge-reviewed">
                                <i class="bi bi-star-fill me-1"></i> Reviewed
                            </span>
                            <?php endif; ?>

                            <div class="download-overlay">
                                <div class="text-center">
                                    <?php if ($book['pdf_file']): ?>
                                        <a href="<?= BOOK_PDF_URL . $book['pdf_file'] ?>" 
                                           class="btn btn-light mb-2"
                                           download
                                           target="_blank">
                                            <i class="bi bi-download me-1"></i> Download
                                        </a>
                                        <br>
                                        <a href="read-book.php?id=<?= $book['id'] ?>" 
                                           class="btn btn-outline-light"
                                           target="_blank">
                                            <i class="bi bi-book-half me-1"></i> Read Online
                                        </a>
                                    <?php else: ?>
                                        <span class="text-white">PDF not available</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card-body p-3">
                            <h6 class="card-title mb-2" style="min-height: 40px;">
                                <?= htmlspecialchars(truncateText($book['title'], 50)) ?>
                            </h6>
                            <p class="text-muted small mb-2">
                                <i class="bi bi-person me-1"></i>
                                <?= htmlspecialchars($book['author']) ?>
                            </p>
                            <p class="text-muted small mb-3">
                                <i class="bi bi-calendar me-1"></i>
                                Purchased: <?= timeAgo($book['purchase_date']) ?>
                            </p>
                            
                            <div class="d-grid gap-2">
                                <?php if ($book['pdf_file']): ?>
                                    <a href="<?= BOOK_PDF_URL . $book['pdf_file'] ?>" 
                                       class="btn btn-sm btn-success"
                                       download
                                       target="_blank">
                                        <i class="bi bi-download me-1"></i> Download PDF
                                    </a>
                                    <a href="read-book.php?id=<?= $book['id'] ?>" 
                                       class="btn btn-sm btn-info text-white"
                                       target="_blank">
                                        <i class="bi bi-book-half me-1"></i> Read Online
                                    </a>
                                <?php endif; ?>
                                
                                <!-- Write Review Button -->
                                <?php if ($book['has_reviewed'] > 0): ?>
                                    <a href="../book-detail.php?id=<?= $book['id'] ?>#reviews-section" 
                                       class="btn btn-sm btn-warning">
                                        <i class="bi bi-star-fill me-1"></i> View My Review
                                    </a>
                                <?php else: ?>
                                    <a href="../book-detail.php?id=<?= $book['id'] ?>#write-review" 
                                       class="btn btn-sm btn-primary">
                                        <i class="bi bi-star me-1"></i> Write Review
                                    </a>
                                <?php endif; ?>
                                
                                <a href="../book-detail.php?id=<?= $book['id'] ?>" 
                                   class="btn btn-sm btn-outline-secondary">
                                    <i class="bi bi-eye me-1"></i> View Details
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Statistics -->
            <div class="row mt-5">
                <div class="col-md-4">
                    <div class="bg-white rounded-3 p-4 shadow-sm text-center">
                        <i class="bi bi-book display-4 text-primary"></i>
                        <h3 class="mt-3"><?= count($books) ?></h3>
                        <p class="text-muted mb-0">Total Books Owned</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="bg-white rounded-3 p-4 shadow-sm text-center">
                        <i class="bi bi-star display-4 text-warning"></i>
                        <h3 class="mt-3"><?= count(array_filter($books, fn($b) => $b['has_reviewed'] > 0)) ?></h3>
                        <p class="text-muted mb-0">Books Reviewed</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="bg-white rounded-3 p-4 shadow-sm text-center">
                        <i class="bi bi-download display-4 text-success"></i>
                        <h3 class="mt-3"><?= count(array_filter($books, fn($b) => !empty($b['pdf_file']))) ?></h3>
                        <p class="text-muted mb-0">Available Downloads</p>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Track downloads (optional - for analytics)
        document.querySelectorAll('a[download]').forEach(link => {
            link.addEventListener('click', function() {
                console.log('Downloading:', this.href);
                // Send to analytics if needed
            });
        });

        // Smooth scroll to review section
        if (window.location.hash === '#write-review') {
            setTimeout(() => {
                const reviewSection = document.querySelector('#write-review');
                if (reviewSection) {
                    reviewSection.scrollIntoView({ behavior: 'smooth' });
                }
            }, 500);
        }
    </script>
</body>
</html>