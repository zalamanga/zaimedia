<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireLogin();

$conn = getDBConnection();
$customerId = $_SESSION['user_id'];
$user = getCurrentUser();

// Get customer orders
$stmt = $conn->prepare("
    SELECT o.*, COUNT(oi.id) as item_count
    FROM orders o
    LEFT JOIN order_items oi ON o.id = oi.order_id
    WHERE o.customer_id = ?
    GROUP BY o.id
    ORDER BY o.created_at DESC
");
$stmt->execute([$customerId]);
$orders = $stmt->fetchAll();

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders - ZaiMedia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: white;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            position: fixed;
            width: 250px;
        }
        .sidebar-header {
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .menu-item {
            padding: 12px 20px;
            color: #333;
            text-decoration: none;
            display: block;
            transition: all 0.3s;
        }
        .menu-item:hover,
        .menu-item.active {
            background: #f8f9fa;
            color: #667eea;
            border-left: 3px solid #667eea;
        }
        .content-area {
            margin-left: 250px;
            padding: 30px;
        }
        .order-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            transition: transform 0.3s;
        }
        .order-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0">Customer</h4>
            <small><?= htmlspecialchars($user['full_name']) ?></small>
        </div>
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a href="orders.php" class="menu-item active">
                <i class="bi bi-cart me-2"></i> My Orders
            </a>
            <a href="library.php" class="menu-item">
                <i class="bi bi-book me-2"></i> My Library
            </a>
            <a href="profile.php" class="menu-item">
                <i class="bi bi-person me-2"></i> Profile
            </a>
        </div>
        <div style="position: absolute; bottom: 20px; width: 100%;">
            <a href="../index.php" class="menu-item">
                <i class="bi bi-house me-2"></i> Homepage
            </a>
            <a href="../logout.php" class="menu-item">
                <i class="bi bi-box-arrow-left me-2"></i> LogOut
            </a>
        </div>
    </div>

    <!-- Content -->
    <div class="content-area">
        <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
            <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <h2 class="mb-4">
            <i class="bi bi-cart me-2"></i>My Orders
        </h2>

        <?php if (empty($orders)): ?>
            <div class="order-card text-center py-5">
                <i class="bi bi-cart-x display-1 text-muted"></i>
                <h4 class="mt-3">Belum Ada Order</h4>
                <p class="text-muted">Yuk mulai berbelanja sekarang!</p>
                <a href="../books.php" class="btn btn-primary mt-3">
                    <i class="bi bi-shop me-2"></i> Browse Books
                </a>
            </div>
        <?php else: ?>
            <?php foreach ($orders as $order): ?>
            <div class="order-card">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <div class="d-flex align-items-center mb-3">
                            <h5 class="mb-0 me-3"><?= htmlspecialchars($order['order_number']) ?></h5>
                            <?php
                            $statusClass = [
                                'pending' => 'secondary',
                                'processing' => 'info',
                                'shipped' => 'primary',
                                'delivered' => 'success',
                                'cancelled' => 'danger'
                            ];
                            $paymentClass = [
                                'pending' => 'warning',
                                'paid' => 'success',
                                'failed' => 'danger'
                            ];
                            ?>
                            <span class="badge bg-<?= $statusClass[$order['order_status']] ?>">
                                <?= ucfirst($order['order_status']) ?>
                            </span>
                            <span class="badge bg-<?= $paymentClass[$order['payment_status']] ?> ms-2">
                                Payment: <?= ucfirst($order['payment_status']) ?>
                            </span>
                        </div>
                        
                        <p class="text-muted mb-2">
                            <i class="bi bi-calendar me-2"></i>
                            <?= formatDateTimeIndo($order['created_at']) ?>
                        </p>
                        
                        <p class="text-muted mb-0">
                            <i class="bi bi-box-seam me-2"></i>
                            <?= $order['item_count'] ?> item(s)
                        </p>
                    </div>
                    
                    <div class="col-md-4 text-end">
                        <h4 class="text-primary mb-3"><?= formatRupiah($order['total']) ?></h4>
                        <div class="d-grid gap-2">
                            <a href="order-detail.php?id=<?= $order['id'] ?>" class="btn btn-outline-primary">
                                <i class="bi bi-eye me-2"></i> View Detail
                            </a>
                            <?php if ($order['payment_status'] === 'paid'): ?>
                                <a href="library.php" class="btn btn-success">
                                    <i class="bi bi-download me-2"></i> Download Books
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>